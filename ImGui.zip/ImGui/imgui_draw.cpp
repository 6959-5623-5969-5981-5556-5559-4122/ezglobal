// dear imgui, v1.51 WIP
// (drawing and font code)

// Contains implementation for
// - ImDrawList
// - ImDrawData
// - ImFontAtlas
// - ImFont
// - Default font data

#if defined(_MSC_VER) && !defined(_CRT_SECURE_NO_WARNINGS)
#define _CRT_SECURE_NO_WARNINGS
#endif

#include "imgui.h"
#define IMGUI_DEFINE_MATH_OPERATORS
#define IMGUI_DEFINE_PLACEMENT_NEW
#include "imgui_internal.h"

#include <stdio.h>      // vsnprintf, sscanf, printf
#if !defined(alloca)
#ifdef _WIN32
#include <malloc.h>     // alloca
#elif (defined(__FreeBSD__) || defined(FreeBSD_kernel) || defined(__DragonFly__)) && !defined(__GLIBC__)
#include <stdlib.h>     // alloca. FreeBSD uses stdlib.h unless GLIBC
#else
#include <alloca.h>     // alloca
#endif
#endif

#ifdef _MSC_VER
#pragma warning (disable: 4505) // unreferenced local function has been removed (stb stuff)
#pragma warning (disable: 4996) // 'This function or variable may be unsafe': strcpy, strdup, sprintf, vsnprintf, sscanf, fopen
#define snprintf _snprintf
#endif

#ifdef __clang__
#pragma clang diagnostic ignored "-Wold-style-cast"         // warning : use of old-style cast                              // yes, they are more terse.
#pragma clang diagnostic ignored "-Wfloat-equal"            // warning : comparing floating point with == or != is unsafe   // storing and comparing against same constants ok.
#pragma clang diagnostic ignored "-Wglobal-constructors"    // warning : declaration requires a global destructor           // similar to above, not sure what the exact difference it.
#pragma clang diagnostic ignored "-Wsign-conversion"        // warning : implicit conversion changes signedness             //
#if __has_warning("-Wreserved-id-macro")
#pragma clang diagnostic ignored "-Wreserved-id-macro"      // warning : macro name is a reserved identifier                //
#endif
#elif defined(__GNUC__)
#pragma GCC diagnostic ignored "-Wunused-function"          // warning: 'xxxx' defined but not used
#pragma GCC diagnostic ignored "-Wdouble-promotion"         // warning: implicit conversion from 'float' to 'double' when passing argument to function
#pragma GCC diagnostic ignored "-Wconversion"               // warning: conversion to 'xxxx' from 'xxxx' may alter its value
#pragma GCC diagnostic ignored "-Wcast-qual"                // warning: cast from type 'xxxx' to type 'xxxx' casts away qualifiers
#endif

//-------------------------------------------------------------------------
// STB libraries implementation
//-------------------------------------------------------------------------

//#define IMGUI_STB_NAMESPACE     ImGuiStb
//#define IMGUI_DISABLE_STB_RECT_PACK_IMPLEMENTATION
//#define IMGUI_DISABLE_STB_TRUETYPE_IMPLEMENTATION

#ifdef IMGUI_STB_NAMESPACE
namespace IMGUI_STB_NAMESPACE
{
#endif

#ifdef _MSC_VER
#pragma warning (push)
#pragma warning (disable: 4456)                             // declaration of 'xx' hides previous local declaration
#endif

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wold-style-cast"         // warning : use of old-style cast                              // yes, they are more terse.
#pragma clang diagnostic ignored "-Wunused-function"
#pragma clang diagnostic ignored "-Wmissing-prototypes"
#endif

#ifdef __GNUC__
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wtype-limits"              // warning: comparison is always true due to limited range of data type [-Wtype-limits]
#endif

#define STBRP_ASSERT(x)    IM_ASSERT(x)
#ifndef IMGUI_DISABLE_STB_RECT_PACK_IMPLEMENTATION
#define STBRP_STATIC
#define STB_RECT_PACK_IMPLEMENTATION
#endif
#include "stb_rect_pack.h"

#define STBTT_malloc(x,u)  ((void)(u), ImGui::MemAlloc(x))
#define STBTT_free(x,u)    ((void)(u), ImGui::MemFree(x))
#define STBTT_assert(x)    IM_ASSERT(x)
#ifndef IMGUI_DISABLE_STB_TRUETYPE_IMPLEMENTATION
#define STBTT_STATIC
#define STB_TRUETYPE_IMPLEMENTATION
#else
#define STBTT_DEF extern
#endif
#include "stb_truetype.h"

#ifdef __GNUC__
#pragma GCC diagnostic pop
#endif

#ifdef __clang__
#pragma clang diagnostic pop
#endif

#ifdef _MSC_VER
#pragma warning (pop)
#endif

#ifdef IMGUI_STB_NAMESPACE
} // namespace ImGuiStb
using namespace IMGUI_STB_NAMESPACE;
#endif

//-----------------------------------------------------------------------------
// ImDrawList
//-----------------------------------------------------------------------------

static const ImVec4 GNullClipRect(-8192.0f, -8192.0f, +8192.0f, +8192.0f); // Large values that are easy to encode in a few bits+shift

void ImDrawList::Clear()
{
	CmdBuffer.resize(0);
	IdxBuffer.resize(0);
	VtxBuffer.resize(0);
	_VtxCurrentIdx = 0;
	_VtxWritePtr = NULL;
	_IdxWritePtr = NULL;
	_ClipRectStack.resize(0);
	_TextureIdStack.resize(0);
	_Path.resize(0);
	_ChannelsCurrent = 0;
	_ChannelsCount = 1;
	// NB: Do not clear channels so our allocations are re-used after the first frame.
}

void ImDrawList::ClearFreeMemory()
{
	CmdBuffer.clear();
	IdxBuffer.clear();
	VtxBuffer.clear();
	_VtxCurrentIdx = 0;
	_VtxWritePtr = NULL;
	_IdxWritePtr = NULL;
	_ClipRectStack.clear();
	_TextureIdStack.clear();
	_Path.clear();
	_ChannelsCurrent = 0;
	_ChannelsCount = 1;
	for (int i = 0; i < _Channels.Size; i++)
	{
		if (i == 0) memset(&_Channels[0], 0, sizeof(_Channels[0]));  // channel 0 is a copy of CmdBuffer/IdxBuffer, don't destruct again
		_Channels[i].CmdBuffer.clear();
		_Channels[i].IdxBuffer.clear();
	}
	_Channels.clear();
}

// Use macros because C++ is a terrible language, we want guaranteed inline, no code in header, and no overhead in Debug mode
#define GetCurrentClipRect()    (_ClipRectStack.Size ? _ClipRectStack.Data[_ClipRectStack.Size-1]  : GNullClipRect)
#define GetCurrentTextureId()   (_TextureIdStack.Size ? _TextureIdStack.Data[_TextureIdStack.Size-1] : NULL)

void ImDrawList::AddDrawCmd()
{
	ImDrawCmd draw_cmd;
	draw_cmd.ClipRect = GetCurrentClipRect();
	draw_cmd.TextureId = GetCurrentTextureId();

	IM_ASSERT(draw_cmd.ClipRect.x <= draw_cmd.ClipRect.z && draw_cmd.ClipRect.y <= draw_cmd.ClipRect.w);
	CmdBuffer.push_back(draw_cmd);
}

void ImDrawList::AddCallback(ImDrawCallback callback, void* callback_data)
{
	ImDrawCmd* current_cmd = CmdBuffer.Size ? &CmdBuffer.back() : NULL;
	if (!current_cmd || current_cmd->ElemCount != 0 || current_cmd->UserCallback != NULL)
	{
		AddDrawCmd();
		current_cmd = &CmdBuffer.back();
	}
	current_cmd->UserCallback = callback;
	current_cmd->UserCallbackData = callback_data;

	AddDrawCmd(); // Force a new command after us (see comment below)
}

// Our scheme may appears a bit unusual, basically we want the most-common calls AddLine AddRect etc. to not have to perform any check so we always have a command ready in the stack.
// The cost of figuring out if a new command has to be added or if we can merge is paid in those Update** functions only.
void ImDrawList::UpdateClipRect()
{
	// If current command is used with different settings we need to add a new command
	const ImVec4 curr_clip_rect = GetCurrentClipRect();
	ImDrawCmd* curr_cmd = CmdBuffer.Size > 0 ? &CmdBuffer.Data[CmdBuffer.Size - 1] : NULL;
	if (!curr_cmd || (curr_cmd->ElemCount != 0 && memcmp(&curr_cmd->ClipRect, &curr_clip_rect, sizeof(ImVec4)) != 0) || curr_cmd->UserCallback != NULL)
	{
		AddDrawCmd();
		return;
	}

	// Try to merge with previous command if it matches, else use current command
	ImDrawCmd* prev_cmd = CmdBuffer.Size > 1 ? curr_cmd - 1 : NULL;
	if (curr_cmd->ElemCount == 0 && prev_cmd && memcmp(&prev_cmd->ClipRect, &curr_clip_rect, sizeof(ImVec4)) == 0 && prev_cmd->TextureId == GetCurrentTextureId() && prev_cmd->UserCallback == NULL)
		CmdBuffer.pop_back();
	else
		curr_cmd->ClipRect = curr_clip_rect;
}

void ImDrawList::UpdateTextureID()
{
	// If current command is used with different settings we need to add a new command
	const ImTextureID curr_texture_id = GetCurrentTextureId();
	ImDrawCmd* curr_cmd = CmdBuffer.Size ? &CmdBuffer.back() : NULL;
	if (!curr_cmd || (curr_cmd->ElemCount != 0 && curr_cmd->TextureId != curr_texture_id) || curr_cmd->UserCallback != NULL)
	{
		AddDrawCmd();
		return;
	}

	// Try to merge with previous command if it matches, else use current command
	ImDrawCmd* prev_cmd = CmdBuffer.Size > 1 ? curr_cmd - 1 : NULL;
	if (prev_cmd && prev_cmd->TextureId == curr_texture_id && memcmp(&prev_cmd->ClipRect, &GetCurrentClipRect(), sizeof(ImVec4)) == 0 && prev_cmd->UserCallback == NULL)
		CmdBuffer.pop_back();
	else
		curr_cmd->TextureId = curr_texture_id;
}

#undef GetCurrentClipRect
#undef GetCurrentTextureId

// Render-level scissoring. This is passed down to your render function but not used for CPU-side coarse clipping. Prefer using higher-level ImGui::PushClipRect() to affect logic (hit-testing and widget culling)
void ImDrawList::PushClipRect(ImVec2 cr_min, ImVec2 cr_max, bool intersect_with_current_clip_rect)
{
	ImVec4 cr(cr_min.x, cr_min.y, cr_max.x, cr_max.y);
	if (intersect_with_current_clip_rect && _ClipRectStack.Size)
	{
		ImVec4 current = _ClipRectStack.Data[_ClipRectStack.Size - 1];
		if (cr.x < current.x) cr.x = current.x;
		if (cr.y < current.y) cr.y = current.y;
		if (cr.z > current.z) cr.z = current.z;
		if (cr.w > current.w) cr.w = current.w;
	}
	cr.z = ImMax(cr.x, cr.z);
	cr.w = ImMax(cr.y, cr.w);

	_ClipRectStack.push_back(cr);
	UpdateClipRect();
}

void ImDrawList::PushClipRectFullScreen()
{
	PushClipRect(ImVec2(GNullClipRect.x, GNullClipRect.y), ImVec2(GNullClipRect.z, GNullClipRect.w));
	//PushClipRect(GetVisibleRect());   // FIXME-OPT: This would be more correct but we're not supposed to access ImGuiContext from here?
}

void ImDrawList::PopClipRect()
{
	IM_ASSERT(_ClipRectStack.Size > 0);
	_ClipRectStack.pop_back();
	UpdateClipRect();
}

void ImDrawList::PushTextureID(const ImTextureID& texture_id)
{
	_TextureIdStack.push_back(texture_id);
	UpdateTextureID();
}

void ImDrawList::PopTextureID()
{
	IM_ASSERT(_TextureIdStack.Size > 0);
	_TextureIdStack.pop_back();
	UpdateTextureID();
}

void ImDrawList::ChannelsSplit(int channels_count)
{
	IM_ASSERT(_ChannelsCurrent == 0 && _ChannelsCount == 1);
	int old_channels_count = _Channels.Size;
	if (old_channels_count < channels_count)
		_Channels.resize(channels_count);
	_ChannelsCount = channels_count;

	// _Channels[] (24 bytes each) hold storage that we'll swap with this->_CmdBuffer/_IdxBuffer
	// The content of _Channels[0] at this point doesn't matter. We clear it to make state tidy in a debugger but we don't strictly need to.
	// When we switch to the next channel, we'll copy _CmdBuffer/_IdxBuffer into _Channels[0] and then _Channels[1] into _CmdBuffer/_IdxBuffer
	memset(&_Channels[0], 0, sizeof(ImDrawChannel));
	for (int i = 1; i < channels_count; i++)
	{
		if (i >= old_channels_count)
		{
			IM_PLACEMENT_NEW(&_Channels[i]) ImDrawChannel();
		}
		else
		{
			_Channels[i].CmdBuffer.resize(0);
			_Channels[i].IdxBuffer.resize(0);
		}
		if (_Channels[i].CmdBuffer.Size == 0)
		{
			ImDrawCmd draw_cmd;
			draw_cmd.ClipRect = _ClipRectStack.back();
			draw_cmd.TextureId = _TextureIdStack.back();
			_Channels[i].CmdBuffer.push_back(draw_cmd);
		}
	}
}

void ImDrawList::ChannelsMerge()
{
	// Note that we never use or rely on channels.Size because it is merely a buffer that we never shrink back to 0 to keep all sub-buffers ready for use.
	if (_ChannelsCount <= 1)
		return;

	ChannelsSetCurrent(0);
	if (CmdBuffer.Size && CmdBuffer.back().ElemCount == 0)
		CmdBuffer.pop_back();

	int new_cmd_buffer_count = 0, new_idx_buffer_count = 0;
	for (int i = 1; i < _ChannelsCount; i++)
	{
		ImDrawChannel& ch = _Channels[i];
		if (ch.CmdBuffer.Size && ch.CmdBuffer.back().ElemCount == 0)
			ch.CmdBuffer.pop_back();
		new_cmd_buffer_count += ch.CmdBuffer.Size;
		new_idx_buffer_count += ch.IdxBuffer.Size;
	}
	CmdBuffer.resize(CmdBuffer.Size + new_cmd_buffer_count);
	IdxBuffer.resize(IdxBuffer.Size + new_idx_buffer_count);

	ImDrawCmd* cmd_write = CmdBuffer.Data + CmdBuffer.Size - new_cmd_buffer_count;
	_IdxWritePtr = IdxBuffer.Data + IdxBuffer.Size - new_idx_buffer_count;
	for (int i = 1; i < _ChannelsCount; i++)
	{
		ImDrawChannel& ch = _Channels[i];
		if (int sz = ch.CmdBuffer.Size) { memcpy(cmd_write, ch.CmdBuffer.Data, sz * sizeof(ImDrawCmd)); cmd_write += sz; }
		if (int sz = ch.IdxBuffer.Size) { memcpy(_IdxWritePtr, ch.IdxBuffer.Data, sz * sizeof(ImDrawIdx)); _IdxWritePtr += sz; }
	}
	AddDrawCmd();
	_ChannelsCount = 1;
}

void ImDrawList::ChannelsSetCurrent(int idx)
{
	IM_ASSERT(idx < _ChannelsCount);
	if (_ChannelsCurrent == idx) return;
	memcpy(&_Channels.Data[_ChannelsCurrent].CmdBuffer, &CmdBuffer, sizeof(CmdBuffer)); // copy 12 bytes, four times
	memcpy(&_Channels.Data[_ChannelsCurrent].IdxBuffer, &IdxBuffer, sizeof(IdxBuffer));
	_ChannelsCurrent = idx;
	memcpy(&CmdBuffer, &_Channels.Data[_ChannelsCurrent].CmdBuffer, sizeof(CmdBuffer));
	memcpy(&IdxBuffer, &_Channels.Data[_ChannelsCurrent].IdxBuffer, sizeof(IdxBuffer));
	_IdxWritePtr = IdxBuffer.Data + IdxBuffer.Size;
}

// NB: this can be called with negative count for removing primitives (as long as the result does not underflow)
void ImDrawList::PrimReserve(int idx_count, int vtx_count)
{
	ImDrawCmd& draw_cmd = CmdBuffer.Data[CmdBuffer.Size - 1];
	draw_cmd.ElemCount += idx_count;

	int vtx_buffer_old_size = VtxBuffer.Size;
	VtxBuffer.resize(vtx_buffer_old_size + vtx_count);
	_VtxWritePtr = VtxBuffer.Data + vtx_buffer_old_size;

	int idx_buffer_old_size = IdxBuffer.Size;
	IdxBuffer.resize(idx_buffer_old_size + idx_count);
	_IdxWritePtr = IdxBuffer.Data + idx_buffer_old_size;
}

// Fully unrolled with inline call to keep our debug builds decently fast.
void ImDrawList::PrimRect(const ImVec2& a, const ImVec2& c, ImU32 col)
{
	ImVec2 b(c.x, a.y), d(a.x, c.y), uv(GImGui->FontTexUvWhitePixel);
	ImDrawIdx idx = (ImDrawIdx)_VtxCurrentIdx;
	_IdxWritePtr[0] = idx; _IdxWritePtr[1] = (ImDrawIdx)(idx + 1); _IdxWritePtr[2] = (ImDrawIdx)(idx + 2);
	_IdxWritePtr[3] = idx; _IdxWritePtr[4] = (ImDrawIdx)(idx + 2); _IdxWritePtr[5] = (ImDrawIdx)(idx + 3);
	_VtxWritePtr[0].pos = a; _VtxWritePtr[0].uv = uv; _VtxWritePtr[0].col = col;
	_VtxWritePtr[1].pos = b; _VtxWritePtr[1].uv = uv; _VtxWritePtr[1].col = col;
	_VtxWritePtr[2].pos = c; _VtxWritePtr[2].uv = uv; _VtxWritePtr[2].col = col;
	_VtxWritePtr[3].pos = d; _VtxWritePtr[3].uv = uv; _VtxWritePtr[3].col = col;
	_VtxWritePtr += 4;
	_VtxCurrentIdx += 4;
	_IdxWritePtr += 6;
}

void ImDrawList::PrimRectUV(const ImVec2& a, const ImVec2& c, const ImVec2& uv_a, const ImVec2& uv_c, ImU32 col)
{
	ImVec2 b(c.x, a.y), d(a.x, c.y), uv_b(uv_c.x, uv_a.y), uv_d(uv_a.x, uv_c.y);
	ImDrawIdx idx = (ImDrawIdx)_VtxCurrentIdx;
	_IdxWritePtr[0] = idx; _IdxWritePtr[1] = (ImDrawIdx)(idx + 1); _IdxWritePtr[2] = (ImDrawIdx)(idx + 2);
	_IdxWritePtr[3] = idx; _IdxWritePtr[4] = (ImDrawIdx)(idx + 2); _IdxWritePtr[5] = (ImDrawIdx)(idx + 3);
	_VtxWritePtr[0].pos = a; _VtxWritePtr[0].uv = uv_a; _VtxWritePtr[0].col = col;
	_VtxWritePtr[1].pos = b; _VtxWritePtr[1].uv = uv_b; _VtxWritePtr[1].col = col;
	_VtxWritePtr[2].pos = c; _VtxWritePtr[2].uv = uv_c; _VtxWritePtr[2].col = col;
	_VtxWritePtr[3].pos = d; _VtxWritePtr[3].uv = uv_d; _VtxWritePtr[3].col = col;
	_VtxWritePtr += 4;
	_VtxCurrentIdx += 4;
	_IdxWritePtr += 6;
}

void ImDrawList::PrimQuadUV(const ImVec2& a, const ImVec2& b, const ImVec2& c, const ImVec2& d, const ImVec2& uv_a, const ImVec2& uv_b, const ImVec2& uv_c, const ImVec2& uv_d, ImU32 col)
{
	ImDrawIdx idx = (ImDrawIdx)_VtxCurrentIdx;
	_IdxWritePtr[0] = idx; _IdxWritePtr[1] = (ImDrawIdx)(idx + 1); _IdxWritePtr[2] = (ImDrawIdx)(idx + 2);
	_IdxWritePtr[3] = idx; _IdxWritePtr[4] = (ImDrawIdx)(idx + 2); _IdxWritePtr[5] = (ImDrawIdx)(idx + 3);
	_VtxWritePtr[0].pos = a; _VtxWritePtr[0].uv = uv_a; _VtxWritePtr[0].col = col;
	_VtxWritePtr[1].pos = b; _VtxWritePtr[1].uv = uv_b; _VtxWritePtr[1].col = col;
	_VtxWritePtr[2].pos = c; _VtxWritePtr[2].uv = uv_c; _VtxWritePtr[2].col = col;
	_VtxWritePtr[3].pos = d; _VtxWritePtr[3].uv = uv_d; _VtxWritePtr[3].col = col;
	_VtxWritePtr += 4;
	_VtxCurrentIdx += 4;
	_IdxWritePtr += 6;
}

// TODO: Thickness anti-aliased lines cap are missing their AA fringe.
void ImDrawList::AddPolyline(const ImVec2* points, const int points_count, ImU32 col, bool closed, float thickness, bool anti_aliased)
{
	if (points_count < 2)
		return;

	const ImVec2 uv = GImGui->FontTexUvWhitePixel;
	anti_aliased &= GImGui->Style.AntiAliasedLines;
	//if (ImGui::GetIO().KeyCtrl) anti_aliased = false; // Debug

	int count = points_count;
	if (!closed)
		count = points_count - 1;

	const bool thick_line = thickness > 1.0f;
	if (anti_aliased)
	{
		// Anti-aliased stroke
		const float AA_SIZE = 1.0f;
		const ImU32 col_trans = col & IM_COL32(255, 255, 255, 0);

		const int idx_count = thick_line ? count * 18 : count * 12;
		const int vtx_count = thick_line ? points_count * 4 : points_count * 3;
		PrimReserve(idx_count, vtx_count);

		// Temporary buffer
		ImVec2* temp_normals = (ImVec2*)alloca(points_count * (thick_line ? 5 : 3) * sizeof(ImVec2));
		ImVec2* temp_points = temp_normals + points_count;

		for (int i1 = 0; i1 < count; i1++)
		{
			const int i2 = (i1 + 1) == points_count ? 0 : i1 + 1;
			ImVec2 diff = points[i2] - points[i1];
			diff *= ImInvLength(diff, 1.0f);
			temp_normals[i1].x = diff.y;
			temp_normals[i1].y = -diff.x;
		}
		if (!closed)
			temp_normals[points_count - 1] = temp_normals[points_count - 2];

		if (!thick_line)
		{
			if (!closed)
			{
				temp_points[0] = points[0] + temp_normals[0] * AA_SIZE;
				temp_points[1] = points[0] - temp_normals[0] * AA_SIZE;
				temp_points[(points_count - 1) * 2 + 0] = points[points_count - 1] + temp_normals[points_count - 1] * AA_SIZE;
				temp_points[(points_count - 1) * 2 + 1] = points[points_count - 1] - temp_normals[points_count - 1] * AA_SIZE;
			}

			// FIXME-OPT: Merge the different loops, possibly remove the temporary buffer.
			unsigned int idx1 = _VtxCurrentIdx;
			for (int i1 = 0; i1 < count; i1++)
			{
				const int i2 = (i1 + 1) == points_count ? 0 : i1 + 1;
				unsigned int idx2 = (i1 + 1) == points_count ? _VtxCurrentIdx : idx1 + 3;

				// Average normals
				ImVec2 dm = (temp_normals[i1] + temp_normals[i2]) * 0.5f;
				float dmr2 = dm.x*dm.x + dm.y*dm.y;
				if (dmr2 > 0.000001f)
				{
					float scale = 1.0f / dmr2;
					if (scale > 100.0f) scale = 100.0f;
					dm *= scale;
				}
				dm *= AA_SIZE;
				temp_points[i2 * 2 + 0] = points[i2] + dm;
				temp_points[i2 * 2 + 1] = points[i2] - dm;

				// Add indexes
				_IdxWritePtr[0] = (ImDrawIdx)(idx2 + 0); _IdxWritePtr[1] = (ImDrawIdx)(idx1 + 0); _IdxWritePtr[2] = (ImDrawIdx)(idx1 + 2);
				_IdxWritePtr[3] = (ImDrawIdx)(idx1 + 2); _IdxWritePtr[4] = (ImDrawIdx)(idx2 + 2); _IdxWritePtr[5] = (ImDrawIdx)(idx2 + 0);
				_IdxWritePtr[6] = (ImDrawIdx)(idx2 + 1); _IdxWritePtr[7] = (ImDrawIdx)(idx1 + 1); _IdxWritePtr[8] = (ImDrawIdx)(idx1 + 0);
				_IdxWritePtr[9] = (ImDrawIdx)(idx1 + 0); _IdxWritePtr[10] = (ImDrawIdx)(idx2 + 0); _IdxWritePtr[11] = (ImDrawIdx)(idx2 + 1);
				_IdxWritePtr += 12;

				idx1 = idx2;
			}

			// Add vertexes
			for (int i = 0; i < points_count; i++)
			{
				_VtxWritePtr[0].pos = points[i];          _VtxWritePtr[0].uv = uv; _VtxWritePtr[0].col = col;
				_VtxWritePtr[1].pos = temp_points[i * 2 + 0]; _VtxWritePtr[1].uv = uv; _VtxWritePtr[1].col = col_trans;
				_VtxWritePtr[2].pos = temp_points[i * 2 + 1]; _VtxWritePtr[2].uv = uv; _VtxWritePtr[2].col = col_trans;
				_VtxWritePtr += 3;
			}
		}
		else
		{
			const float half_inner_thickness = (thickness - AA_SIZE) * 0.5f;
			if (!closed)
			{
				temp_points[0] = points[0] + temp_normals[0] * (half_inner_thickness + AA_SIZE);
				temp_points[1] = points[0] + temp_normals[0] * (half_inner_thickness);
				temp_points[2] = points[0] - temp_normals[0] * (half_inner_thickness);
				temp_points[3] = points[0] - temp_normals[0] * (half_inner_thickness + AA_SIZE);
				temp_points[(points_count - 1) * 4 + 0] = points[points_count - 1] + temp_normals[points_count - 1] * (half_inner_thickness + AA_SIZE);
				temp_points[(points_count - 1) * 4 + 1] = points[points_count - 1] + temp_normals[points_count - 1] * (half_inner_thickness);
				temp_points[(points_count - 1) * 4 + 2] = points[points_count - 1] - temp_normals[points_count - 1] * (half_inner_thickness);
				temp_points[(points_count - 1) * 4 + 3] = points[points_count - 1] - temp_normals[points_count - 1] * (half_inner_thickness + AA_SIZE);
			}

			// FIXME-OPT: Merge the different loops, possibly remove the temporary buffer.
			unsigned int idx1 = _VtxCurrentIdx;
			for (int i1 = 0; i1 < count; i1++)
			{
				const int i2 = (i1 + 1) == points_count ? 0 : i1 + 1;
				unsigned int idx2 = (i1 + 1) == points_count ? _VtxCurrentIdx : idx1 + 4;

				// Average normals
				ImVec2 dm = (temp_normals[i1] + temp_normals[i2]) * 0.5f;
				float dmr2 = dm.x*dm.x + dm.y*dm.y;
				if (dmr2 > 0.000001f)
				{
					float scale = 1.0f / dmr2;
					if (scale > 100.0f) scale = 100.0f;
					dm *= scale;
				}
				ImVec2 dm_out = dm * (half_inner_thickness + AA_SIZE);
				ImVec2 dm_in = dm * half_inner_thickness;
				temp_points[i2 * 4 + 0] = points[i2] + dm_out;
				temp_points[i2 * 4 + 1] = points[i2] + dm_in;
				temp_points[i2 * 4 + 2] = points[i2] - dm_in;
				temp_points[i2 * 4 + 3] = points[i2] - dm_out;

				// Add indexes
				_IdxWritePtr[0] = (ImDrawIdx)(idx2 + 1); _IdxWritePtr[1] = (ImDrawIdx)(idx1 + 1); _IdxWritePtr[2] = (ImDrawIdx)(idx1 + 2);
				_IdxWritePtr[3] = (ImDrawIdx)(idx1 + 2); _IdxWritePtr[4] = (ImDrawIdx)(idx2 + 2); _IdxWritePtr[5] = (ImDrawIdx)(idx2 + 1);
				_IdxWritePtr[6] = (ImDrawIdx)(idx2 + 1); _IdxWritePtr[7] = (ImDrawIdx)(idx1 + 1); _IdxWritePtr[8] = (ImDrawIdx)(idx1 + 0);
				_IdxWritePtr[9] = (ImDrawIdx)(idx1 + 0); _IdxWritePtr[10] = (ImDrawIdx)(idx2 + 0); _IdxWritePtr[11] = (ImDrawIdx)(idx2 + 1);
				_IdxWritePtr[12] = (ImDrawIdx)(idx2 + 2); _IdxWritePtr[13] = (ImDrawIdx)(idx1 + 2); _IdxWritePtr[14] = (ImDrawIdx)(idx1 + 3);
				_IdxWritePtr[15] = (ImDrawIdx)(idx1 + 3); _IdxWritePtr[16] = (ImDrawIdx)(idx2 + 3); _IdxWritePtr[17] = (ImDrawIdx)(idx2 + 2);
				_IdxWritePtr += 18;

				idx1 = idx2;
			}

			// Add vertexes
			for (int i = 0; i < points_count; i++)
			{
				_VtxWritePtr[0].pos = temp_points[i * 4 + 0]; _VtxWritePtr[0].uv = uv; _VtxWritePtr[0].col = col_trans;
				_VtxWritePtr[1].pos = temp_points[i * 4 + 1]; _VtxWritePtr[1].uv = uv; _VtxWritePtr[1].col = col;
				_VtxWritePtr[2].pos = temp_points[i * 4 + 2]; _VtxWritePtr[2].uv = uv; _VtxWritePtr[2].col = col;
				_VtxWritePtr[3].pos = temp_points[i * 4 + 3]; _VtxWritePtr[3].uv = uv; _VtxWritePtr[3].col = col_trans;
				_VtxWritePtr += 4;
			}
		}
		_VtxCurrentIdx += (ImDrawIdx)vtx_count;
	}
	else
	{
		// Non Anti-aliased Stroke
		const int idx_count = count * 6;
		const int vtx_count = count * 4;      // FIXME-OPT: Not sharing edges
		PrimReserve(idx_count, vtx_count);

		for (int i1 = 0; i1 < count; i1++)
		{
			const int i2 = (i1 + 1) == points_count ? 0 : i1 + 1;
			const ImVec2& p1 = points[i1];
			const ImVec2& p2 = points[i2];
			ImVec2 diff = p2 - p1;
			diff *= ImInvLength(diff, 1.0f);

			const float dx = diff.x * (thickness * 0.5f);
			const float dy = diff.y * (thickness * 0.5f);
			_VtxWritePtr[0].pos.x = p1.x + dy; _VtxWritePtr[0].pos.y = p1.y - dx; _VtxWritePtr[0].uv = uv; _VtxWritePtr[0].col = col;
			_VtxWritePtr[1].pos.x = p2.x + dy; _VtxWritePtr[1].pos.y = p2.y - dx; _VtxWritePtr[1].uv = uv; _VtxWritePtr[1].col = col;
			_VtxWritePtr[2].pos.x = p2.x - dy; _VtxWritePtr[2].pos.y = p2.y + dx; _VtxWritePtr[2].uv = uv; _VtxWritePtr[2].col = col;
			_VtxWritePtr[3].pos.x = p1.x - dy; _VtxWritePtr[3].pos.y = p1.y + dx; _VtxWritePtr[3].uv = uv; _VtxWritePtr[3].col = col;
			_VtxWritePtr += 4;

			_IdxWritePtr[0] = (ImDrawIdx)(_VtxCurrentIdx); _IdxWritePtr[1] = (ImDrawIdx)(_VtxCurrentIdx + 1); _IdxWritePtr[2] = (ImDrawIdx)(_VtxCurrentIdx + 2);
			_IdxWritePtr[3] = (ImDrawIdx)(_VtxCurrentIdx); _IdxWritePtr[4] = (ImDrawIdx)(_VtxCurrentIdx + 2); _IdxWritePtr[5] = (ImDrawIdx)(_VtxCurrentIdx + 3);
			_IdxWritePtr += 6;
			_VtxCurrentIdx += 4;
		}
	}
}

void ImDrawList::AddConvexPolyFilled(const ImVec2* points, const int points_count, ImU32 col, bool anti_aliased)
{
	const ImVec2 uv = GImGui->FontTexUvWhitePixel;
	anti_aliased &= GImGui->Style.AntiAliasedShapes;
	//if (ImGui::GetIO().KeyCtrl) anti_aliased = false; // Debug

	if (anti_aliased)
	{
		// Anti-aliased Fill
		const float AA_SIZE = 1.0f;
		const ImU32 col_trans = col & IM_COL32(255, 255, 255, 0);
		const int idx_count = (points_count - 2) * 3 + points_count * 6;
		const int vtx_count = (points_count * 2);
		PrimReserve(idx_count, vtx_count);

		// Add indexes for fill
		unsigned int vtx_inner_idx = _VtxCurrentIdx;
		unsigned int vtx_outer_idx = _VtxCurrentIdx + 1;
		for (int i = 2; i < points_count; i++)
		{
			_IdxWritePtr[0] = (ImDrawIdx)(vtx_inner_idx); _IdxWritePtr[1] = (ImDrawIdx)(vtx_inner_idx + ((i - 1) << 1)); _IdxWritePtr[2] = (ImDrawIdx)(vtx_inner_idx + (i << 1));
			_IdxWritePtr += 3;
		}

		// Compute normals
		ImVec2* temp_normals = (ImVec2*)alloca(points_count * sizeof(ImVec2));
		for (int i0 = points_count - 1, i1 = 0; i1 < points_count; i0 = i1++)
		{
			const ImVec2& p0 = points[i0];
			const ImVec2& p1 = points[i1];
			ImVec2 diff = p1 - p0;
			diff *= ImInvLength(diff, 1.0f);
			temp_normals[i0].x = diff.y;
			temp_normals[i0].y = -diff.x;
		}

		for (int i0 = points_count - 1, i1 = 0; i1 < points_count; i0 = i1++)
		{
			// Average normals
			const ImVec2& n0 = temp_normals[i0];
			const ImVec2& n1 = temp_normals[i1];
			ImVec2 dm = (n0 + n1) * 0.5f;
			float dmr2 = dm.x*dm.x + dm.y*dm.y;
			if (dmr2 > 0.000001f)
			{
				float scale = 1.0f / dmr2;
				if (scale > 100.0f) scale = 100.0f;
				dm *= scale;
			}
			dm *= AA_SIZE * 0.5f;

			// Add vertices
			_VtxWritePtr[0].pos = (points[i1] - dm); _VtxWritePtr[0].uv = uv; _VtxWritePtr[0].col = col;        // Inner
			_VtxWritePtr[1].pos = (points[i1] + dm); _VtxWritePtr[1].uv = uv; _VtxWritePtr[1].col = col_trans;  // Outer
			_VtxWritePtr += 2;

			// Add indexes for fringes
			_IdxWritePtr[0] = (ImDrawIdx)(vtx_inner_idx + (i1 << 1)); _IdxWritePtr[1] = (ImDrawIdx)(vtx_inner_idx + (i0 << 1)); _IdxWritePtr[2] = (ImDrawIdx)(vtx_outer_idx + (i0 << 1));
			_IdxWritePtr[3] = (ImDrawIdx)(vtx_outer_idx + (i0 << 1)); _IdxWritePtr[4] = (ImDrawIdx)(vtx_outer_idx + (i1 << 1)); _IdxWritePtr[5] = (ImDrawIdx)(vtx_inner_idx + (i1 << 1));
			_IdxWritePtr += 6;
		}
		_VtxCurrentIdx += (ImDrawIdx)vtx_count;
	}
	else
	{
		// Non Anti-aliased Fill
		const int idx_count = (points_count - 2) * 3;
		const int vtx_count = points_count;
		PrimReserve(idx_count, vtx_count);
		for (int i = 0; i < vtx_count; i++)
		{
			_VtxWritePtr[0].pos = points[i]; _VtxWritePtr[0].uv = uv; _VtxWritePtr[0].col = col;
			_VtxWritePtr++;
		}
		for (int i = 2; i < points_count; i++)
		{
			_IdxWritePtr[0] = (ImDrawIdx)(_VtxCurrentIdx); _IdxWritePtr[1] = (ImDrawIdx)(_VtxCurrentIdx + i - 1); _IdxWritePtr[2] = (ImDrawIdx)(_VtxCurrentIdx + i);
			_IdxWritePtr += 3;
		}
		_VtxCurrentIdx += (ImDrawIdx)vtx_count;
	}
}

void ImDrawList::PathArcToFast(const ImVec2& centre, float radius, int amin, int amax)
{
	static ImVec2 circle_vtx[12];
	static bool circle_vtx_builds = false;
	const int circle_vtx_count = IM_ARRAYSIZE(circle_vtx);
	if (!circle_vtx_builds)
	{
		for (int i = 0; i < circle_vtx_count; i++)
		{
			const float a = ((float)i / (float)circle_vtx_count) * 2 * IM_PI;
			circle_vtx[i].x = cosf(a);
			circle_vtx[i].y = sinf(a);
		}
		circle_vtx_builds = true;
	}

	if (amin > amax) return;
	if (radius == 0.0f)
	{
		_Path.push_back(centre);
	}
	else
	{
		_Path.reserve(_Path.Size + (amax - amin + 1));
		for (int a = amin; a <= amax; a++)
		{
			const ImVec2& c = circle_vtx[a % circle_vtx_count];
			_Path.push_back(ImVec2(centre.x + c.x * radius, centre.y + c.y * radius));
		}
	}
}

void ImDrawList::PathArcTo(const ImVec2& centre, float radius, float amin, float amax, int num_segments)
{
	if (radius == 0.0f)
		_Path.push_back(centre);
	_Path.reserve(_Path.Size + (num_segments + 1));
	for (int i = 0; i <= num_segments; i++)
	{
		const float a = amin + ((float)i / (float)num_segments) * (amax - amin);
		_Path.push_back(ImVec2(centre.x + cosf(a) * radius, centre.y + sinf(a) * radius));
	}
}

static void PathBezierToCasteljau(ImVector<ImVec2>* path, float x1, float y1, float x2, float y2, float x3, float y3, float x4, float y4, float tess_tol, int level)
{
	float dx = x4 - x1;
	float dy = y4 - y1;
	float d2 = ((x2 - x4) * dy - (y2 - y4) * dx);
	float d3 = ((x3 - x4) * dy - (y3 - y4) * dx);
	d2 = (d2 >= 0) ? d2 : -d2;
	d3 = (d3 >= 0) ? d3 : -d3;
	if ((d2 + d3) * (d2 + d3) < tess_tol * (dx*dx + dy*dy))
	{
		path->push_back(ImVec2(x4, y4));
	}
	else if (level < 10)
	{
		float x12 = (x1 + x2)*0.5f, y12 = (y1 + y2)*0.5f;
		float x23 = (x2 + x3)*0.5f, y23 = (y2 + y3)*0.5f;
		float x34 = (x3 + x4)*0.5f, y34 = (y3 + y4)*0.5f;
		float x123 = (x12 + x23)*0.5f, y123 = (y12 + y23)*0.5f;
		float x234 = (x23 + x34)*0.5f, y234 = (y23 + y34)*0.5f;
		float x1234 = (x123 + x234)*0.5f, y1234 = (y123 + y234)*0.5f;

		PathBezierToCasteljau(path, x1, y1, x12, y12, x123, y123, x1234, y1234, tess_tol, level + 1);
		PathBezierToCasteljau(path, x1234, y1234, x234, y234, x34, y34, x4, y4, tess_tol, level + 1);
	}
}

void ImDrawList::PathBezierCurveTo(const ImVec2& p2, const ImVec2& p3, const ImVec2& p4, int num_segments)
{
	ImVec2 p1 = _Path.back();
	if (num_segments == 0)
	{
		// Auto-tessellated
		PathBezierToCasteljau(&_Path, p1.x, p1.y, p2.x, p2.y, p3.x, p3.y, p4.x, p4.y, GImGui->Style.CurveTessellationTol, 0);
	}
	else
	{
		float t_step = 1.0f / (float)num_segments;
		for (int i_step = 1; i_step <= num_segments; i_step++)
		{
			float t = t_step * i_step;
			float u = 1.0f - t;
			float w1 = u*u*u;
			float w2 = 3 * u*u*t;
			float w3 = 3 * u*t*t;
			float w4 = t*t*t;
			_Path.push_back(ImVec2(w1*p1.x + w2*p2.x + w3*p3.x + w4*p4.x, w1*p1.y + w2*p2.y + w3*p3.y + w4*p4.y));
		}
	}
}

void ImDrawList::PathRect(const ImVec2& a, const ImVec2& b, float rounding, int rounding_corners)
{
	float r = rounding;
	r = ImMin(r, fabsf(b.x - a.x) * (((rounding_corners&(1 | 2)) == (1 | 2)) || ((rounding_corners&(4 | 8)) == (4 | 8)) ? 0.5f : 1.0f) - 1.0f);
	r = ImMin(r, fabsf(b.y - a.y) * (((rounding_corners&(1 | 8)) == (1 | 8)) || ((rounding_corners&(2 | 4)) == (2 | 4)) ? 0.5f : 1.0f) - 1.0f);

	if (r <= 0.0f || rounding_corners == 0)
	{
		PathLineTo(a);
		PathLineTo(ImVec2(b.x, a.y));
		PathLineTo(b);
		PathLineTo(ImVec2(a.x, b.y));
	}
	else
	{
		const float r0 = (rounding_corners & 1) ? r : 0.0f;
		const float r1 = (rounding_corners & 2) ? r : 0.0f;
		const float r2 = (rounding_corners & 4) ? r : 0.0f;
		const float r3 = (rounding_corners & 8) ? r : 0.0f;
		PathArcToFast(ImVec2(a.x + r0, a.y + r0), r0, 6, 9);
		PathArcToFast(ImVec2(b.x - r1, a.y + r1), r1, 9, 12);
		PathArcToFast(ImVec2(b.x - r2, b.y - r2), r2, 0, 3);
		PathArcToFast(ImVec2(a.x + r3, b.y - r3), r3, 3, 6);
	}
}

void ImDrawList::AddLine(const ImVec2& a, const ImVec2& b, ImU32 col, float thickness)
{
	if ((col & IM_COL32_A_MASK) == 0)
		return;
	PathLineTo(a + ImVec2(0.5f, 0.5f));
	PathLineTo(b + ImVec2(0.5f, 0.5f));
	PathStroke(col, false, thickness);
}

// a: upper-left, b: lower-right. we don't render 1 px sized rectangles properly.
void ImDrawList::AddRect(const ImVec2& a, const ImVec2& b, ImU32 col, float rounding, int rounding_corners_flags, float thickness)
{
	if ((col & IM_COL32_A_MASK) == 0)
		return;
	PathRect(a + ImVec2(0.5f, 0.5f), b - ImVec2(0.5f, 0.5f), rounding, rounding_corners_flags);
	PathStroke(col, true, thickness);
}

void ImDrawList::AddRectFilled(const ImVec2& a, const ImVec2& b, ImU32 col, float rounding, int rounding_corners_flags)
{
	if ((col & IM_COL32_A_MASK) == 0)
		return;
	if (rounding > 0.0f)
	{
		PathRect(a, b, rounding, rounding_corners_flags);
		PathFillConvex(col);
	}
	else
	{
		PrimReserve(6, 4);
		PrimRect(a, b, col);
	}
}

void ImDrawList::AddRectFilledMultiColor(const ImVec2& a, const ImVec2& c, ImU32 col_upr_left, ImU32 col_upr_right, ImU32 col_bot_right, ImU32 col_bot_left)
{
	if (((col_upr_left | col_upr_right | col_bot_right | col_bot_left) & IM_COL32_A_MASK) == 0)
		return;

	const ImVec2 uv = GImGui->FontTexUvWhitePixel;
	PrimReserve(6, 4);
	PrimWriteIdx((ImDrawIdx)(_VtxCurrentIdx)); PrimWriteIdx((ImDrawIdx)(_VtxCurrentIdx + 1)); PrimWriteIdx((ImDrawIdx)(_VtxCurrentIdx + 2));
	PrimWriteIdx((ImDrawIdx)(_VtxCurrentIdx)); PrimWriteIdx((ImDrawIdx)(_VtxCurrentIdx + 2)); PrimWriteIdx((ImDrawIdx)(_VtxCurrentIdx + 3));
	PrimWriteVtx(a, uv, col_upr_left);
	PrimWriteVtx(ImVec2(c.x, a.y), uv, col_upr_right);
	PrimWriteVtx(c, uv, col_bot_right);
	PrimWriteVtx(ImVec2(a.x, c.y), uv, col_bot_left);
}

void ImDrawList::AddQuad(const ImVec2& a, const ImVec2& b, const ImVec2& c, const ImVec2& d, ImU32 col, float thickness)
{
	if ((col & IM_COL32_A_MASK) == 0)
		return;

	PathLineTo(a);
	PathLineTo(b);
	PathLineTo(c);
	PathLineTo(d);
	PathStroke(col, true, thickness);
}

void ImDrawList::AddQuadFilled(const ImVec2& a, const ImVec2& b, const ImVec2& c, const ImVec2& d, ImU32 col)
{
	if ((col & IM_COL32_A_MASK) == 0)
		return;

	PathLineTo(a);
	PathLineTo(b);
	PathLineTo(c);
	PathLineTo(d);
	PathFillConvex(col);
}

void ImDrawList::AddTriangle(const ImVec2& a, const ImVec2& b, const ImVec2& c, ImU32 col, float thickness)
{
	if ((col & IM_COL32_A_MASK) == 0)
		return;

	PathLineTo(a);
	PathLineTo(b);
	PathLineTo(c);
	PathStroke(col, true, thickness);
}

void ImDrawList::AddTriangleFilled(const ImVec2& a, const ImVec2& b, const ImVec2& c, ImU32 col)
{
	if ((col & IM_COL32_A_MASK) == 0)
		return;

	PathLineTo(a);
	PathLineTo(b);
	PathLineTo(c);
	PathFillConvex(col);
}

void ImDrawList::AddCircle(const ImVec2& centre, float radius, ImU32 col, int num_segments, float thickness)
{
	if ((col & IM_COL32_A_MASK) == 0)
		return;

	const float a_max = IM_PI*2.0f * ((float)num_segments - 1.0f) / (float)num_segments;
	PathArcTo(centre, radius - 0.5f, 0.0f, a_max, num_segments);
	PathStroke(col, true, thickness);
}

void ImDrawList::AddCircleFilled(const ImVec2& centre, float radius, ImU32 col, int num_segments)
{
	if ((col & IM_COL32_A_MASK) == 0)
		return;

	const float a_max = IM_PI*2.0f * ((float)num_segments - 1.0f) / (float)num_segments;
	PathArcTo(centre, radius, 0.0f, a_max, num_segments);
	PathFillConvex(col);
}

void ImDrawList::AddBezierCurve(const ImVec2& pos0, const ImVec2& cp0, const ImVec2& cp1, const ImVec2& pos1, ImU32 col, float thickness, int num_segments)
{
	if ((col & IM_COL32_A_MASK) == 0)
		return;

	PathLineTo(pos0);
	PathBezierCurveTo(cp0, cp1, pos1, num_segments);
	PathStroke(col, false, thickness);
}

void ImDrawList::AddText(const ImFont* font, float font_size, const ImVec2& pos, ImU32 col, const char* text_begin, const char* text_end, float wrap_width, const ImVec4* cpu_fine_clip_rect)
{
	if ((col & IM_COL32_A_MASK) == 0)
		return;

	if (text_end == NULL)
		text_end = text_begin + strlen(text_begin);
	if (text_begin == text_end)
		return;

	// IMPORTANT: This is one of the few instance of breaking the encapsulation of ImDrawList, as we pull this from ImGui state, but it is just SO useful.
	// Might just move Font/FontSize to ImDrawList?
	if (font == NULL)
		font = GImGui->Font;
	if (font_size == 0.0f)
		font_size = GImGui->FontSize;

	IM_ASSERT(font->ContainerAtlas->TexID == _TextureIdStack.back());  // Use high-level ImGui::PushFont() or low-level ImDrawList::PushTextureId() to change font.

	ImVec4 clip_rect = _ClipRectStack.back();
	if (cpu_fine_clip_rect)
	{
		clip_rect.x = ImMax(clip_rect.x, cpu_fine_clip_rect->x);
		clip_rect.y = ImMax(clip_rect.y, cpu_fine_clip_rect->y);
		clip_rect.z = ImMin(clip_rect.z, cpu_fine_clip_rect->z);
		clip_rect.w = ImMin(clip_rect.w, cpu_fine_clip_rect->w);
	}
	font->RenderText(this, font_size, pos, col, clip_rect, text_begin, text_end, wrap_width, cpu_fine_clip_rect != NULL);
}

void ImDrawList::AddText(const ImVec2& pos, ImU32 col, const char* text_begin, const char* text_end)
{
	AddText(NULL, 0.0f, pos, col, text_begin, text_end);
}

void ImDrawList::AddImage(ImTextureID user_texture_id, const ImVec2& a, const ImVec2& b, const ImVec2& uv_a, const ImVec2& uv_b, ImU32 col)
{
	if ((col & IM_COL32_A_MASK) == 0)
		return;

	// FIXME-OPT: This is wasting draw calls.
	const bool push_texture_id = _TextureIdStack.empty() || user_texture_id != _TextureIdStack.back();
	if (push_texture_id)
		PushTextureID(user_texture_id);

	PrimReserve(6, 4);
	PrimRectUV(a, b, uv_a, uv_b, col);

	if (push_texture_id)
		PopTextureID();
}

void ImDrawList::AddImageQuad(ImTextureID user_texture_id, const ImVec2& a, const ImVec2& b, const ImVec2& c, const ImVec2& d, const ImVec2& uv_a, const ImVec2& uv_b, const ImVec2& uv_c, const ImVec2& uv_d, ImU32 col)
{
	if ((col & IM_COL32_A_MASK) == 0)
		return;

	const bool push_texture_id = _TextureIdStack.empty() || user_texture_id != _TextureIdStack.back();
	if (push_texture_id)
		PushTextureID(user_texture_id);

	PrimReserve(6, 4);
	PrimQuadUV(a, b, c, d, uv_a, uv_b, uv_c, uv_d, col);

	if (push_texture_id)
		PopTextureID();
}

//-----------------------------------------------------------------------------
// ImDrawData
//-----------------------------------------------------------------------------

// For backward compatibility: convert all buffers from indexed to de-indexed, in case you cannot render indexed. Note: this is slow and most likely a waste of resources. Always prefer indexed rendering!
void ImDrawData::DeIndexAllBuffers()
{
	ImVector<ImDrawVert> new_vtx_buffer;
	TotalVtxCount = TotalIdxCount = 0;
	for (int i = 0; i < CmdListsCount; i++)
	{
		ImDrawList* cmd_list = CmdLists[i];
		if (cmd_list->IdxBuffer.empty())
			continue;
		new_vtx_buffer.resize(cmd_list->IdxBuffer.Size);
		for (int j = 0; j < cmd_list->IdxBuffer.Size; j++)
			new_vtx_buffer[j] = cmd_list->VtxBuffer[cmd_list->IdxBuffer[j]];
		cmd_list->VtxBuffer.swap(new_vtx_buffer);
		cmd_list->IdxBuffer.resize(0);
		TotalVtxCount += cmd_list->VtxBuffer.Size;
	}
}

// Helper to scale the ClipRect field of each ImDrawCmd. Use if your final output buffer is at a different scale than ImGui expects, or if there is a difference between your window resolution and framebuffer resolution.
void ImDrawData::ScaleClipRects(const ImVec2& scale)
{
	for (int i = 0; i < CmdListsCount; i++)
	{
		ImDrawList* cmd_list = CmdLists[i];
		for (int cmd_i = 0; cmd_i < cmd_list->CmdBuffer.Size; cmd_i++)
		{
			ImDrawCmd* cmd = &cmd_list->CmdBuffer[cmd_i];
			cmd->ClipRect = ImVec4(cmd->ClipRect.x * scale.x, cmd->ClipRect.y * scale.y, cmd->ClipRect.z * scale.x, cmd->ClipRect.w * scale.y);
		}
	}
}

//-----------------------------------------------------------------------------
// ImFontAtlas
//-----------------------------------------------------------------------------

ImFontConfig::ImFontConfig()
{
	FontData = NULL;
	FontDataSize = 0;
	FontDataOwnedByAtlas = true;
	FontNo = 0;
	SizePixels = 0.0f;
	OversampleH = 3;
	OversampleV = 1;
	PixelSnapH = false;
	GlyphExtraSpacing = ImVec2(0.0f, 0.0f);
	GlyphOffset = ImVec2(0.0f, 0.0f);
	GlyphRanges = NULL;
	MergeMode = false;
	DstFont = NULL;
	memset(Name, 0, sizeof(Name));
}

ImFontAtlas::ImFontAtlas()
{
	TexID = NULL;
	TexPixelsAlpha8 = NULL;
	TexPixelsRGBA32 = NULL;
	TexWidth = TexHeight = TexDesiredWidth = 0;
	TexUvWhitePixel = ImVec2(0, 0);
}

ImFontAtlas::~ImFontAtlas()
{
	Clear();
}

void    ImFontAtlas::ClearInputData()
{
	for (int i = 0; i < ConfigData.Size; i++)
		if (ConfigData[i].FontData && ConfigData[i].FontDataOwnedByAtlas)
		{
			ImGui::MemFree(ConfigData[i].FontData);
			ConfigData[i].FontData = NULL;
		}

	// When clearing this we lose access to the font name and other information used to build the font.
	for (int i = 0; i < Fonts.Size; i++)
		if (Fonts[i]->ConfigData >= ConfigData.Data && Fonts[i]->ConfigData < ConfigData.Data + ConfigData.Size)
		{
			Fonts[i]->ConfigData = NULL;
			Fonts[i]->ConfigDataCount = 0;
		}
	ConfigData.clear();
}

void    ImFontAtlas::ClearTexData()
{
	if (TexPixelsAlpha8)
		ImGui::MemFree(TexPixelsAlpha8);
	if (TexPixelsRGBA32)
		ImGui::MemFree(TexPixelsRGBA32);
	TexPixelsAlpha8 = NULL;
	TexPixelsRGBA32 = NULL;
}

void    ImFontAtlas::ClearFonts()
{
	for (int i = 0; i < Fonts.Size; i++)
	{
		Fonts[i]->~ImFont();
		ImGui::MemFree(Fonts[i]);
	}
	Fonts.clear();
}

void    ImFontAtlas::Clear()
{
	ClearInputData();
	ClearTexData();
	ClearFonts();
}

void    ImFontAtlas::GetTexDataAsAlpha8(unsigned char** out_pixels, int* out_width, int* out_height, int* out_bytes_per_pixel)
{
	// Build atlas on demand
	if (TexPixelsAlpha8 == NULL)
	{
		if (ConfigData.empty())
			AddFontDefault();
		Build();
	}

	*out_pixels = TexPixelsAlpha8;
	if (out_width) *out_width = TexWidth;
	if (out_height) *out_height = TexHeight;
	if (out_bytes_per_pixel) *out_bytes_per_pixel = 1;
}

void    ImFontAtlas::GetTexDataAsRGBA32(unsigned char** out_pixels, int* out_width, int* out_height, int* out_bytes_per_pixel)
{
	// Convert to RGBA32 format on demand
	// Although it is likely to be the most commonly used format, our font rendering is 1 channel / 8 bpp
	if (!TexPixelsRGBA32)
	{
		unsigned char* pixels;
		GetTexDataAsAlpha8(&pixels, NULL, NULL);
		TexPixelsRGBA32 = (unsigned int*)ImGui::MemAlloc((size_t)(TexWidth * TexHeight * 4));
		const unsigned char* src = pixels;
		unsigned int* dst = TexPixelsRGBA32;
		for (int n = TexWidth * TexHeight; n > 0; n--)
			*dst++ = IM_COL32(255, 255, 255, (unsigned int)(*src++));
	}

	*out_pixels = (unsigned char*)TexPixelsRGBA32;
	if (out_width) *out_width = TexWidth;
	if (out_height) *out_height = TexHeight;
	if (out_bytes_per_pixel) *out_bytes_per_pixel = 4;
}

ImFont* ImFontAtlas::AddFont(const ImFontConfig* font_cfg)
{
	IM_ASSERT(font_cfg->FontData != NULL && font_cfg->FontDataSize > 0);
	IM_ASSERT(font_cfg->SizePixels > 0.0f);

	// Create new font
	if (!font_cfg->MergeMode)
	{
		ImFont* font = (ImFont*)ImGui::MemAlloc(sizeof(ImFont));
		IM_PLACEMENT_NEW(font) ImFont();
		Fonts.push_back(font);
	}
	else
	{
		IM_ASSERT(!Fonts.empty()); // When using MergeMode make sure that a font has already been added before. You can use ImGui::GetIO().Fonts->AddFontDefault() to add the default imgui font.
	}

	ConfigData.push_back(*font_cfg);
	ImFontConfig& new_font_cfg = ConfigData.back();
	if (!new_font_cfg.DstFont)
		new_font_cfg.DstFont = Fonts.back();
	if (!new_font_cfg.FontDataOwnedByAtlas)
	{
		new_font_cfg.FontData = ImGui::MemAlloc(new_font_cfg.FontDataSize);
		new_font_cfg.FontDataOwnedByAtlas = true;
		memcpy(new_font_cfg.FontData, font_cfg->FontData, (size_t)new_font_cfg.FontDataSize);
	}

	// Invalidate texture
	ClearTexData();
	return new_font_cfg.DstFont;
}

// Default font TTF is compressed with stb_compress then base85 encoded (see extra_fonts/binary_to_compressed_c.cpp for encoder)
static unsigned int stb_decompress_length(unsigned char *input);
static unsigned int stb_decompress(unsigned char *output, unsigned char *i, unsigned int length);
static const char*  GetDefaultCompressedFontDataTTFBase85();
static unsigned int Decode85Byte(char c) { return c >= '\\' ? c - 36 : c - 35; }
static void         Decode85(const unsigned char* src, unsigned char* dst)
{
	while (*src)
	{
		unsigned int tmp = Decode85Byte(src[0]) + 85 * (Decode85Byte(src[1]) + 85 * (Decode85Byte(src[2]) + 85 * (Decode85Byte(src[3]) + 85 * Decode85Byte(src[4]))));
		dst[0] = ((tmp >> 0) & 0xFF); dst[1] = ((tmp >> 8) & 0xFF); dst[2] = ((tmp >> 16) & 0xFF); dst[3] = ((tmp >> 24) & 0xFF);   // We can't assume little-endianness.
		src += 5;
		dst += 4;
	}
}

// Load embedded ProggyClean.ttf at size 13, disable oversampling
ImFont* ImFontAtlas::AddFontDefault(const ImFontConfig* font_cfg_template)
{
	ImFontConfig font_cfg = font_cfg_template ? *font_cfg_template : ImFontConfig();
	if (!font_cfg_template)
	{
		font_cfg.OversampleH = font_cfg.OversampleV = 1;
		font_cfg.PixelSnapH = true;
	}
	if (font_cfg.Name[0] == '\0') strcpy(font_cfg.Name, "ProggyClean.ttf, 13px");

	const char* ttf_compressed_base85 = GetDefaultCompressedFontDataTTFBase85();
	ImFont* font = AddFontFromMemoryCompressedBase85TTF(ttf_compressed_base85, 13.0f, &font_cfg, GetGlyphRangesDefault());
	return font;
}

ImFont* ImFontAtlas::AddFontFromFileTTF(const char* filename, float size_pixels, const ImFontConfig* font_cfg_template, const ImWchar* glyph_ranges)
{
	int data_size = 0;
	void* data = ImFileLoadToMemory(filename, "rb", &data_size, 0);
	if (!data)
	{
		IM_ASSERT(0); // Could not load file.
		return NULL;
	}
	ImFontConfig font_cfg = font_cfg_template ? *font_cfg_template : ImFontConfig();
	if (font_cfg.Name[0] == '\0')
	{
		// Store a short copy of filename into into the font name for convenience
		const char* p;
		for (p = filename + strlen(filename); p > filename && p[-1] != '/' && p[-1] != '\\'; p--) {}
		snprintf(font_cfg.Name, IM_ARRAYSIZE(font_cfg.Name), "%s, %.0fpx", p, size_pixels);
	}
	return AddFontFromMemoryTTF(data, data_size, size_pixels, &font_cfg, glyph_ranges);
}

// NBM Transfer ownership of 'ttf_data' to ImFontAtlas, unless font_cfg_template->FontDataOwnedByAtlas == false. Owned TTF buffer will be deleted after Build().
ImFont* ImFontAtlas::AddFontFromMemoryTTF(void* ttf_data, int ttf_size, float size_pixels, const ImFontConfig* font_cfg_template, const ImWchar* glyph_ranges)
{
	ImFontConfig font_cfg = font_cfg_template ? *font_cfg_template : ImFontConfig();
	IM_ASSERT(font_cfg.FontData == NULL);
	font_cfg.FontData = ttf_data;
	font_cfg.FontDataSize = ttf_size;
	font_cfg.SizePixels = size_pixels;
	if (glyph_ranges)
		font_cfg.GlyphRanges = glyph_ranges;
	return AddFont(&font_cfg);
}

ImFont* ImFontAtlas::AddFontFromMemoryCompressedTTF(const void* compressed_ttf_data, int compressed_ttf_size, float size_pixels, const ImFontConfig* font_cfg_template, const ImWchar* glyph_ranges)
{
	const unsigned int buf_decompressed_size = stb_decompress_length((unsigned char*)compressed_ttf_data);
	unsigned char* buf_decompressed_data = (unsigned char *)ImGui::MemAlloc(buf_decompressed_size);
	stb_decompress(buf_decompressed_data, (unsigned char*)compressed_ttf_data, (unsigned int)compressed_ttf_size);

	ImFontConfig font_cfg = font_cfg_template ? *font_cfg_template : ImFontConfig();
	IM_ASSERT(font_cfg.FontData == NULL);
	font_cfg.FontDataOwnedByAtlas = true;
	return AddFontFromMemoryTTF(buf_decompressed_data, (int)buf_decompressed_size, size_pixels, &font_cfg, glyph_ranges);
}

ImFont* ImFontAtlas::AddFontFromMemoryCompressedBase85TTF(const char* compressed_ttf_data_base85, float size_pixels, const ImFontConfig* font_cfg, const ImWchar* glyph_ranges)
{
	int compressed_ttf_size = (((int)strlen(compressed_ttf_data_base85) + 4) / 5) * 4;
	void* compressed_ttf = ImGui::MemAlloc((size_t)compressed_ttf_size);
	Decode85((const unsigned char*)compressed_ttf_data_base85, (unsigned char*)compressed_ttf);
	ImFont* font = AddFontFromMemoryCompressedTTF(compressed_ttf, compressed_ttf_size, size_pixels, font_cfg, glyph_ranges);
	ImGui::MemFree(compressed_ttf);
	return font;
}

bool    ImFontAtlas::Build()
{
	IM_ASSERT(ConfigData.Size > 0);

	TexID = NULL;
	TexWidth = TexHeight = 0;
	TexUvWhitePixel = ImVec2(0, 0);
	ClearTexData();

	struct ImFontTempBuildData
	{
		stbtt_fontinfo      FontInfo;
		stbrp_rect*         Rects;
		stbtt_pack_range*   Ranges;
		int                 RangesCount;
	};
	ImFontTempBuildData* tmp_array = (ImFontTempBuildData*)ImGui::MemAlloc((size_t)ConfigData.Size * sizeof(ImFontTempBuildData));

	// Initialize font information early (so we can error without any cleanup) + count glyphs
	int total_glyph_count = 0;
	int total_glyph_range_count = 0;
	for (int input_i = 0; input_i < ConfigData.Size; input_i++)
	{
		ImFontConfig& cfg = ConfigData[input_i];
		ImFontTempBuildData& tmp = tmp_array[input_i];

		IM_ASSERT(cfg.DstFont && (!cfg.DstFont->IsLoaded() || cfg.DstFont->ContainerAtlas == this));
		const int font_offset = stbtt_GetFontOffsetForIndex((unsigned char*)cfg.FontData, cfg.FontNo);
		IM_ASSERT(font_offset >= 0);
		if (!stbtt_InitFont(&tmp.FontInfo, (unsigned char*)cfg.FontData, font_offset))
			return false;

		// Count glyphs
		if (!cfg.GlyphRanges)
			cfg.GlyphRanges = GetGlyphRangesDefault();
		for (const ImWchar* in_range = cfg.GlyphRanges; in_range[0] && in_range[1]; in_range += 2)
		{
			total_glyph_count += (in_range[1] - in_range[0]) + 1;
			total_glyph_range_count++;
		}
	}

	// Start packing. We need a known width for the skyline algorithm. Using a cheap heuristic here to decide of width. User can override TexDesiredWidth if they wish.
	// After packing is done, width shouldn't matter much, but some API/GPU have texture size limitations and increasing width can decrease height.
	TexWidth = (TexDesiredWidth > 0) ? TexDesiredWidth : (total_glyph_count > 4000) ? 4096 : (total_glyph_count > 2000) ? 2048 : (total_glyph_count > 1000) ? 1024 : 512;
	TexHeight = 0;
	const int max_tex_height = 1024 * 32;
	stbtt_pack_context spc;
	stbtt_PackBegin(&spc, NULL, TexWidth, max_tex_height, 0, 1, NULL);

	// Pack our extra data rectangles first, so it will be on the upper-left corner of our texture (UV will have small values).
	ImVector<stbrp_rect> extra_rects;
	RenderCustomTexData(0, &extra_rects);
	stbtt_PackSetOversampling(&spc, 1, 1);
	stbrp_pack_rects((stbrp_context*)spc.pack_info, &extra_rects[0], extra_rects.Size);
	for (int i = 0; i < extra_rects.Size; i++)
		if (extra_rects[i].was_packed)
			TexHeight = ImMax(TexHeight, extra_rects[i].y + extra_rects[i].h);

	// Allocate packing character data and flag packed characters buffer as non-packed (x0=y0=x1=y1=0)
	int buf_packedchars_n = 0, buf_rects_n = 0, buf_ranges_n = 0;
	stbtt_packedchar* buf_packedchars = (stbtt_packedchar*)ImGui::MemAlloc(total_glyph_count * sizeof(stbtt_packedchar));
	stbrp_rect* buf_rects = (stbrp_rect*)ImGui::MemAlloc(total_glyph_count * sizeof(stbrp_rect));
	stbtt_pack_range* buf_ranges = (stbtt_pack_range*)ImGui::MemAlloc(total_glyph_range_count * sizeof(stbtt_pack_range));
	memset(buf_packedchars, 0, total_glyph_count * sizeof(stbtt_packedchar));
	memset(buf_rects, 0, total_glyph_count * sizeof(stbrp_rect));              // Unnecessary but let's clear this for the sake of sanity.
	memset(buf_ranges, 0, total_glyph_range_count * sizeof(stbtt_pack_range));

	// First font pass: pack all glyphs (no rendering at this point, we are working with rectangles in an infinitely tall texture at this point)
	for (int input_i = 0; input_i < ConfigData.Size; input_i++)
	{
		ImFontConfig& cfg = ConfigData[input_i];
		ImFontTempBuildData& tmp = tmp_array[input_i];

		// Setup ranges
		int glyph_count = 0;
		int glyph_ranges_count = 0;
		for (const ImWchar* in_range = cfg.GlyphRanges; in_range[0] && in_range[1]; in_range += 2)
		{
			glyph_count += (in_range[1] - in_range[0]) + 1;
			glyph_ranges_count++;
		}
		tmp.Ranges = buf_ranges + buf_ranges_n;
		tmp.RangesCount = glyph_ranges_count;
		buf_ranges_n += glyph_ranges_count;
		for (int i = 0; i < glyph_ranges_count; i++)
		{
			const ImWchar* in_range = &cfg.GlyphRanges[i * 2];
			stbtt_pack_range& range = tmp.Ranges[i];
			range.font_size = cfg.SizePixels;
			range.first_unicode_codepoint_in_range = in_range[0];
			range.num_chars = (in_range[1] - in_range[0]) + 1;
			range.chardata_for_range = buf_packedchars + buf_packedchars_n;
			buf_packedchars_n += range.num_chars;
		}

		// Pack
		tmp.Rects = buf_rects + buf_rects_n;
		buf_rects_n += glyph_count;
		stbtt_PackSetOversampling(&spc, cfg.OversampleH, cfg.OversampleV);
		int n = stbtt_PackFontRangesGatherRects(&spc, &tmp.FontInfo, tmp.Ranges, tmp.RangesCount, tmp.Rects);
		stbrp_pack_rects((stbrp_context*)spc.pack_info, tmp.Rects, n);

		// Extend texture height
		for (int i = 0; i < n; i++)
			if (tmp.Rects[i].was_packed)
				TexHeight = ImMax(TexHeight, tmp.Rects[i].y + tmp.Rects[i].h);
	}
	IM_ASSERT(buf_rects_n == total_glyph_count);
	IM_ASSERT(buf_packedchars_n == total_glyph_count);
	IM_ASSERT(buf_ranges_n == total_glyph_range_count);

	// Create texture
	TexHeight = ImUpperPowerOfTwo(TexHeight);
	TexPixelsAlpha8 = (unsigned char*)ImGui::MemAlloc(TexWidth * TexHeight);
	memset(TexPixelsAlpha8, 0, TexWidth * TexHeight);
	spc.pixels = TexPixelsAlpha8;
	spc.height = TexHeight;

	// Second pass: render characters
	for (int input_i = 0; input_i < ConfigData.Size; input_i++)
	{
		ImFontConfig& cfg = ConfigData[input_i];
		ImFontTempBuildData& tmp = tmp_array[input_i];
		stbtt_PackSetOversampling(&spc, cfg.OversampleH, cfg.OversampleV);
		stbtt_PackFontRangesRenderIntoRects(&spc, &tmp.FontInfo, tmp.Ranges, tmp.RangesCount, tmp.Rects);
		tmp.Rects = NULL;
	}

	// End packing
	stbtt_PackEnd(&spc);
	ImGui::MemFree(buf_rects);
	buf_rects = NULL;

	// Third pass: setup ImFont and glyphs for runtime
	for (int input_i = 0; input_i < ConfigData.Size; input_i++)
	{
		ImFontConfig& cfg = ConfigData[input_i];
		ImFontTempBuildData& tmp = tmp_array[input_i];
		ImFont* dst_font = cfg.DstFont; // We can have multiple input fonts writing into a same destination font (when using MergeMode=true)

		float font_scale = stbtt_ScaleForPixelHeight(&tmp.FontInfo, cfg.SizePixels);
		int unscaled_ascent, unscaled_descent, unscaled_line_gap;
		stbtt_GetFontVMetrics(&tmp.FontInfo, &unscaled_ascent, &unscaled_descent, &unscaled_line_gap);

		float ascent = unscaled_ascent * font_scale;
		float descent = unscaled_descent * font_scale;
		if (!cfg.MergeMode)
		{
			dst_font->ContainerAtlas = this;
			dst_font->ConfigData = &cfg;
			dst_font->ConfigDataCount = 0;
			dst_font->FontSize = cfg.SizePixels;
			dst_font->Ascent = ascent;
			dst_font->Descent = descent;
			dst_font->Glyphs.resize(0);
			dst_font->MetricsTotalSurface = 0;
		}
		dst_font->ConfigDataCount++;
		float off_x = cfg.GlyphOffset.x;
		float off_y = cfg.GlyphOffset.y;

		dst_font->FallbackGlyph = NULL; // Always clear fallback so FindGlyph can return NULL. It will be set again in BuildLookupTable()
		for (int i = 0; i < tmp.RangesCount; i++)
		{
			stbtt_pack_range& range = tmp.Ranges[i];
			for (int char_idx = 0; char_idx < range.num_chars; char_idx += 1)
			{
				const stbtt_packedchar& pc = range.chardata_for_range[char_idx];
				if (!pc.x0 && !pc.x1 && !pc.y0 && !pc.y1)
					continue;

				const int codepoint = range.first_unicode_codepoint_in_range + char_idx;
				if (cfg.MergeMode && dst_font->FindGlyph((unsigned short)codepoint))
					continue;

				stbtt_aligned_quad q;
				float dummy_x = 0.0f, dummy_y = 0.0f;
				stbtt_GetPackedQuad(range.chardata_for_range, TexWidth, TexHeight, char_idx, &dummy_x, &dummy_y, &q, 0);

				dst_font->Glyphs.resize(dst_font->Glyphs.Size + 1);
				ImFont::Glyph& glyph = dst_font->Glyphs.back();
				glyph.Codepoint = (ImWchar)codepoint;
				glyph.X0 = q.x0 + off_x; glyph.Y0 = q.y0 + off_y; glyph.X1 = q.x1 + off_x; glyph.Y1 = q.y1 + off_y;
				glyph.U0 = q.s0; glyph.V0 = q.t0; glyph.U1 = q.s1; glyph.V1 = q.t1;
				glyph.Y0 += (float)(int)(dst_font->Ascent + 0.5f);
				glyph.Y1 += (float)(int)(dst_font->Ascent + 0.5f);
				glyph.XAdvance = (pc.xadvance + cfg.GlyphExtraSpacing.x);  // Bake spacing into XAdvance
				if (cfg.PixelSnapH)
					glyph.XAdvance = (float)(int)(glyph.XAdvance + 0.5f);
				dst_font->MetricsTotalSurface += (int)((glyph.U1 - glyph.U0) * TexWidth + 1.99f) * (int)((glyph.V1 - glyph.V0) * TexHeight + 1.99f); // +1 to account for average padding, +0.99 to round
			}
		}
		cfg.DstFont->BuildLookupTable();
	}

	// Cleanup temporaries
	ImGui::MemFree(buf_packedchars);
	ImGui::MemFree(buf_ranges);
	ImGui::MemFree(tmp_array);

	// Render into our custom data block
	RenderCustomTexData(1, &extra_rects);

	return true;
}

void ImFontAtlas::RenderCustomTexData(int pass, void* p_rects)
{
	// A work of art lies ahead! (. = white layer, X = black layer, others are blank)
	// The white texels on the top left are the ones we'll use everywhere in ImGui to render filled shapes.
	const int TEX_DATA_W = 90;
	const int TEX_DATA_H = 27;
	const char texture_data[TEX_DATA_W*TEX_DATA_H + 1] =
	{
		"..-         -XXXXXXX-    X    -           X           -XXXXXXX          -          XXXXXXX"
		"..-         -X.....X-   X.X   -          X.X          -X.....X          -          X.....X"
		"---         -XXX.XXX-  X...X  -         X...X         -X....X           -           X....X"
		"X           -  X.X  - X.....X -        X.....X        -X...X            -            X...X"
		"XX          -  X.X  -X.......X-       X.......X       -X..X.X           -           X.X..X"
		"X.X         -  X.X  -XXXX.XXXX-       XXXX.XXXX       -X.X X.X          -          X.X X.X"
		"X..X        -  X.X  -   X.X   -          X.X          -XX   X.X         -         X.X   XX"
		"X...X       -  X.X  -   X.X   -    XX    X.X    XX    -      X.X        -        X.X      "
		"X....X      -  X.X  -   X.X   -   X.X    X.X    X.X   -       X.X       -       X.X       "
		"X.....X     -  X.X  -   X.X   -  X..X    X.X    X..X  -        X.X      -      X.X        "
		"X......X    -  X.X  -   X.X   - X...XXXXXX.XXXXXX...X -         X.X   XX-XX   X.X         "
		"X.......X   -  X.X  -   X.X   -X.....................X-          X.X X.X-X.X X.X          "
		"X........X  -  X.X  -   X.X   - X...XXXXXX.XXXXXX...X -           X.X..X-X..X.X           "
		"X.........X -XXX.XXX-   X.X   -  X..X    X.X    X..X  -            X...X-X...X            "
		"X..........X-X.....X-   X.X   -   X.X    X.X    X.X   -           X....X-X....X           "
		"X......XXXXX-XXXXXXX-   X.X   -    XX    X.X    XX    -          X.....X-X.....X          "
		"X...X..X    ---------   X.X   -          X.X          -          XXXXXXX-XXXXXXX          "
		"X..X X..X   -       -XXXX.XXXX-       XXXX.XXXX       ------------------------------------"
		"X.X  X..X   -       -X.......X-       X.......X       -    XX           XX    -           "
		"XX    X..X  -       - X.....X -        X.....X        -   X.X           X.X   -           "
		"      X..X          -  X...X  -         X...X         -  X..X           X..X  -           "
		"       XX           -   X.X   -          X.X          - X...XXXXXXXXXXXXX...X -           "
		"------------        -    X    -           X           -X.....................X-           "
		"                    ----------------------------------- X...XXXXXXXXXXXXX...X -           "
		"                                                      -  X..X           X..X  -           "
		"                                                      -   X.X           X.X   -           "
		"                                                      -    XX           XX    -           "
	};

	ImVector<stbrp_rect>& rects = *(ImVector<stbrp_rect>*)p_rects;
	if (pass == 0)
	{
		// Request rectangles
		stbrp_rect r;
		memset(&r, 0, sizeof(r));
		r.w = (TEX_DATA_W * 2) + 1;
		r.h = TEX_DATA_H + 1;
		rects.push_back(r);
	}
	else if (pass == 1)
	{
		// Render/copy pixels
		const stbrp_rect& r = rects[0];
		for (int y = 0, n = 0; y < TEX_DATA_H; y++)
			for (int x = 0; x < TEX_DATA_W; x++, n++)
			{
				const int offset0 = (int)(r.x + x) + (int)(r.y + y) * TexWidth;
				const int offset1 = offset0 + 1 + TEX_DATA_W;
				TexPixelsAlpha8[offset0] = texture_data[n] == '.' ? 0xFF : 0x00;
				TexPixelsAlpha8[offset1] = texture_data[n] == 'X' ? 0xFF : 0x00;
			}
		const ImVec2 tex_uv_scale(1.0f / TexWidth, 1.0f / TexHeight);
		TexUvWhitePixel = ImVec2((r.x + 0.5f) * tex_uv_scale.x, (r.y + 0.5f) * tex_uv_scale.y);

		// Setup mouse cursors
		const ImVec2 cursor_datas[ImGuiMouseCursor_Count_][3] =
		{
			// Pos ........ Size ......... Offset ......
			{ ImVec2(0,3),  ImVec2(12,19), ImVec2(0, 0) }, // ImGuiMouseCursor_Arrow
			{ ImVec2(13,0), ImVec2(7,16),  ImVec2(4, 8) }, // ImGuiMouseCursor_TextInput
			{ ImVec2(31,0), ImVec2(23,23), ImVec2(11,11) }, // ImGuiMouseCursor_Move
			{ ImVec2(21,0), ImVec2(9,23), ImVec2(5,11) }, // ImGuiMouseCursor_ResizeNS
			{ ImVec2(55,18),ImVec2(23, 9), ImVec2(11, 5) }, // ImGuiMouseCursor_ResizeEW
			{ ImVec2(73,0), ImVec2(17,17), ImVec2(9, 9) }, // ImGuiMouseCursor_ResizeNESW
			{ ImVec2(55,0), ImVec2(17,17), ImVec2(9, 9) }, // ImGuiMouseCursor_ResizeNWSE
		};

		for (int type = 0; type < ImGuiMouseCursor_Count_; type++)
		{
			ImGuiMouseCursorData& cursor_data = GImGui->MouseCursorData[type];
			ImVec2 pos = cursor_datas[type][0] + ImVec2((float)r.x, (float)r.y);
			const ImVec2 size = cursor_datas[type][1];
			cursor_data.Type = type;
			cursor_data.Size = size;
			cursor_data.HotOffset = cursor_datas[type][2];
			cursor_data.TexUvMin[0] = (pos)* tex_uv_scale;
			cursor_data.TexUvMax[0] = (pos + size) * tex_uv_scale;
			pos.x += TEX_DATA_W + 1;
			cursor_data.TexUvMin[1] = (pos)* tex_uv_scale;
			cursor_data.TexUvMax[1] = (pos + size) * tex_uv_scale;
		}
	}
}

// Retrieve list of range (2 int per range, values are inclusive)
const ImWchar*   ImFontAtlas::GetGlyphRangesDefault()
{
	static const ImWchar ranges[] =
	{
		0x0020, 0x00FF, // Basic Latin + Latin Supplement
		0,
	};
	return &ranges[0];
}

const ImWchar*  ImFontAtlas::GetGlyphRangesKorean()
{
	static const ImWchar ranges[] =
	{
		0x0020, 0x00FF, // Basic Latin + Latin Supplement
		0x3131, 0x3163, // Korean alphabets
		0xAC00, 0xD79D, // Korean characters
		0,
	};
	return &ranges[0];
}

const ImWchar*  ImFontAtlas::GetGlyphRangesChinese()
{
	static const ImWchar ranges[] =
	{
		0x0020, 0x00FF, // Basic Latin + Latin Supplement
		0x3000, 0x30FF, // Punctuations, Hiragana, Katakana
		0x31F0, 0x31FF, // Katakana Phonetic Extensions
		0xFF00, 0xFFEF, // Half-width characters
		0x4e00, 0x9FAF, // CJK Ideograms
		0,
	};
	return &ranges[0];
}

const ImWchar*  ImFontAtlas::GetGlyphRangesJapanese()
{
	// Store the 1946 ideograms code points as successive offsets from the initial unicode codepoint 0x4E00. Each offset has an implicit +1.
	// This encoding helps us reduce the source code size.
	static const short offsets_from_0x4E00[] =
	{
		-1,0,1,3,0,0,0,0,1,0,5,1,1,0,7,4,6,10,0,1,9,9,7,1,3,19,1,10,7,1,0,1,0,5,1,0,6,4,2,6,0,0,12,6,8,0,3,5,0,1,0,9,0,0,8,1,1,3,4,5,13,0,0,8,2,17,
		4,3,1,1,9,6,0,0,0,2,1,3,2,22,1,9,11,1,13,1,3,12,0,5,9,2,0,6,12,5,3,12,4,1,2,16,1,1,4,6,5,3,0,6,13,15,5,12,8,14,0,0,6,15,3,6,0,18,8,1,6,14,1,
		5,4,12,24,3,13,12,10,24,0,0,0,1,0,1,1,2,9,10,2,2,0,0,3,3,1,0,3,8,0,3,2,4,4,1,6,11,10,14,6,15,3,4,15,1,0,0,5,2,2,0,0,1,6,5,5,6,0,3,6,5,0,0,1,0,
		11,2,2,8,4,7,0,10,0,1,2,17,19,3,0,2,5,0,6,2,4,4,6,1,1,11,2,0,3,1,2,1,2,10,7,6,3,16,0,8,24,0,0,3,1,1,3,0,1,6,0,0,0,2,0,1,5,15,0,1,0,0,2,11,19,
		1,4,19,7,6,5,1,0,0,0,0,5,1,0,1,9,0,0,5,0,2,0,1,0,3,0,11,3,0,2,0,0,0,0,0,9,3,6,4,12,0,14,0,0,29,10,8,0,14,37,13,0,31,16,19,0,8,30,1,20,8,3,48,
		21,1,0,12,0,10,44,34,42,54,11,18,82,0,2,1,2,12,1,0,6,2,17,2,12,7,0,7,17,4,2,6,24,23,8,23,39,2,16,23,1,0,5,1,2,15,14,5,6,2,11,0,8,6,2,2,2,14,
		20,4,15,3,4,11,10,10,2,5,2,1,30,2,1,0,0,22,5,5,0,3,1,5,4,1,0,0,2,2,21,1,5,1,2,16,2,1,3,4,0,8,4,0,0,5,14,11,2,16,1,13,1,7,0,22,15,3,1,22,7,14,
		22,19,11,24,18,46,10,20,64,45,3,2,0,4,5,0,1,4,25,1,0,0,2,10,0,0,0,1,0,1,2,0,0,9,1,2,0,0,0,2,5,2,1,1,5,5,8,1,1,1,5,1,4,9,1,3,0,1,0,1,1,2,0,0,
		2,0,1,8,22,8,1,0,0,0,0,4,2,1,0,9,8,5,0,9,1,30,24,2,6,4,39,0,14,5,16,6,26,179,0,2,1,1,0,0,0,5,2,9,6,0,2,5,16,7,5,1,1,0,2,4,4,7,15,13,14,0,0,
		3,0,1,0,0,0,2,1,6,4,5,1,4,9,0,3,1,8,0,0,10,5,0,43,0,2,6,8,4,0,2,0,0,9,6,0,9,3,1,6,20,14,6,1,4,0,7,2,3,0,2,0,5,0,3,1,0,3,9,7,0,3,4,0,4,9,1,6,0,
		9,0,0,2,3,10,9,28,3,6,2,4,1,2,32,4,1,18,2,0,3,1,5,30,10,0,2,2,2,0,7,9,8,11,10,11,7,2,13,7,5,10,0,3,40,2,0,1,6,12,0,4,5,1,5,11,11,21,4,8,3,7,
		8,8,33,5,23,0,0,19,8,8,2,3,0,6,1,1,1,5,1,27,4,2,5,0,3,5,6,3,1,0,3,1,12,5,3,3,2,0,7,7,2,1,0,4,0,1,1,2,0,10,10,6,2,5,9,7,5,15,15,21,6,11,5,20,
		4,3,5,5,2,5,0,2,1,0,1,7,28,0,9,0,5,12,5,5,18,30,0,12,3,3,21,16,25,32,9,3,14,11,24,5,66,9,1,2,0,5,9,1,5,1,8,0,8,3,3,0,1,15,1,4,8,1,2,7,0,7,2,
		8,3,7,5,3,7,10,2,1,0,0,2,25,0,6,4,0,10,0,4,2,4,1,12,5,38,4,0,4,1,10,5,9,4,0,14,4,2,5,18,20,21,1,3,0,5,0,7,0,3,7,1,3,1,1,8,1,0,0,0,3,2,5,2,11,
		6,0,13,1,3,9,1,12,0,16,6,2,1,0,2,1,12,6,13,11,2,0,28,1,7,8,14,13,8,13,0,2,0,5,4,8,10,2,37,42,19,6,6,7,4,14,11,18,14,80,7,6,0,4,72,12,36,27,
		7,7,0,14,17,19,164,27,0,5,10,7,3,13,6,14,0,2,2,5,3,0,6,13,0,0,10,29,0,4,0,3,13,0,3,1,6,51,1,5,28,2,0,8,0,20,2,4,0,25,2,10,13,10,0,16,4,0,1,0,
		2,1,7,0,1,8,11,0,0,1,2,7,2,23,11,6,6,4,16,2,2,2,0,22,9,3,3,5,2,0,15,16,21,2,9,20,15,15,5,3,9,1,0,0,1,7,7,5,4,2,2,2,38,24,14,0,0,15,5,6,24,14,
		5,5,11,0,21,12,0,3,8,4,11,1,8,0,11,27,7,2,4,9,21,59,0,1,39,3,60,62,3,0,12,11,0,3,30,11,0,13,88,4,15,5,28,13,1,4,48,17,17,4,28,32,46,0,16,0,
		18,11,1,8,6,38,11,2,6,11,38,2,0,45,3,11,2,7,8,4,30,14,17,2,1,1,65,18,12,16,4,2,45,123,12,56,33,1,4,3,4,7,0,0,0,3,2,0,16,4,2,4,2,0,7,4,5,2,26,
		2,25,6,11,6,1,16,2,6,17,77,15,3,35,0,1,0,5,1,0,38,16,6,3,12,3,3,3,0,9,3,1,3,5,2,9,0,18,0,25,1,3,32,1,72,46,6,2,7,1,3,14,17,0,28,1,40,13,0,20,
		15,40,6,38,24,12,43,1,1,9,0,12,6,0,6,2,4,19,3,7,1,48,0,9,5,0,5,6,9,6,10,15,2,11,19,3,9,2,0,1,10,1,27,8,1,3,6,1,14,0,26,0,27,16,3,4,9,6,2,23,
		9,10,5,25,2,1,6,1,1,48,15,9,15,14,3,4,26,60,29,13,37,21,1,6,4,0,2,11,22,23,16,16,2,2,1,3,0,5,1,6,4,0,0,4,0,0,8,3,0,2,5,0,7,1,7,3,13,2,4,10,
		3,0,2,31,0,18,3,0,12,10,4,1,0,7,5,7,0,5,4,12,2,22,10,4,2,15,2,8,9,0,23,2,197,51,3,1,1,4,13,4,3,21,4,19,3,10,5,40,0,4,1,1,10,4,1,27,34,7,21,
		2,17,2,9,6,4,2,3,0,4,2,7,8,2,5,1,15,21,3,4,4,2,2,17,22,1,5,22,4,26,7,0,32,1,11,42,15,4,1,2,5,0,19,3,1,8,6,0,10,1,9,2,13,30,8,2,24,17,19,1,4,
		4,25,13,0,10,16,11,39,18,8,5,30,82,1,6,8,18,77,11,13,20,75,11,112,78,33,3,0,0,60,17,84,9,1,1,12,30,10,49,5,32,158,178,5,5,6,3,3,1,3,1,4,7,6,
		19,31,21,0,2,9,5,6,27,4,9,8,1,76,18,12,1,4,0,3,3,6,3,12,2,8,30,16,2,25,1,5,5,4,3,0,6,10,2,3,1,0,5,1,19,3,0,8,1,5,2,6,0,0,0,19,1,2,0,5,1,2,5,
		1,3,7,0,4,12,7,3,10,22,0,9,5,1,0,2,20,1,1,3,23,30,3,9,9,1,4,191,14,3,15,6,8,50,0,1,0,0,4,0,0,1,0,2,4,2,0,2,3,0,2,0,2,2,8,7,0,1,1,1,3,3,17,11,
		91,1,9,3,2,13,4,24,15,41,3,13,3,1,20,4,125,29,30,1,0,4,12,2,21,4,5,5,19,11,0,13,11,86,2,18,0,7,1,8,8,2,2,22,1,2,6,5,2,0,1,2,8,0,2,0,5,2,1,0,
		2,10,2,0,5,9,2,1,2,0,1,0,4,0,0,10,2,5,3,0,6,1,0,1,4,4,33,3,13,17,3,18,6,4,7,1,5,78,0,4,1,13,7,1,8,1,0,35,27,15,3,0,0,0,1,11,5,41,38,15,22,6,
		14,14,2,1,11,6,20,63,5,8,27,7,11,2,2,40,58,23,50,54,56,293,8,8,1,5,1,14,0,1,12,37,89,8,8,8,2,10,6,0,0,0,4,5,2,1,0,1,1,2,7,0,3,3,0,4,6,0,3,2,
		19,3,8,0,0,0,4,4,16,0,4,1,5,1,3,0,3,4,6,2,17,10,10,31,6,4,3,6,10,126,7,3,2,2,0,9,0,0,5,20,13,0,15,0,6,0,2,5,8,64,50,3,2,12,2,9,0,0,11,8,20,
		109,2,18,23,0,0,9,61,3,0,28,41,77,27,19,17,81,5,2,14,5,83,57,252,14,154,263,14,20,8,13,6,57,39,38,
	};
	static ImWchar base_ranges[] =
	{
		0x0020, 0x00FF, // Basic Latin + Latin Supplement
		0x3000, 0x30FF, // Punctuations, Hiragana, Katakana
		0x31F0, 0x31FF, // Katakana Phonetic Extensions
		0xFF00, 0xFFEF, // Half-width characters
	};
	static bool full_ranges_unpacked = false;
	static ImWchar full_ranges[IM_ARRAYSIZE(base_ranges) + IM_ARRAYSIZE(offsets_from_0x4E00) * 2 + 1];
	if (!full_ranges_unpacked)
	{
		// Unpack
		int codepoint = 0x4e00;
		memcpy(full_ranges, base_ranges, sizeof(base_ranges));
		ImWchar* dst = full_ranges + IM_ARRAYSIZE(base_ranges);;
		for (int n = 0; n < IM_ARRAYSIZE(offsets_from_0x4E00); n++, dst += 2)
			dst[0] = dst[1] = (ImWchar)(codepoint += (offsets_from_0x4E00[n] + 1));
		dst[0] = 0;
		full_ranges_unpacked = true;
	}
	return &full_ranges[0];
}

const ImWchar*  ImFontAtlas::GetGlyphRangesCyrillic()
{
	static const ImWchar ranges[] =
	{
		0x0020, 0x00FF, // Basic Latin + Latin Supplement
		0x0400, 0x052F, // Cyrillic + Cyrillic Supplement
		0x2DE0, 0x2DFF, // Cyrillic Extended-A
		0xA640, 0xA69F, // Cyrillic Extended-B
		0,
	};
	return &ranges[0];
}

const ImWchar*  ImFontAtlas::GetGlyphRangesThai()
{
	static const ImWchar ranges[] =
	{
		0x0020, 0x00FF, // Basic Latin
		0x0E00, 0x0E7F, // Thai
		0,
	};
	return &ranges[0];
}

//-----------------------------------------------------------------------------
// ImFont
//-----------------------------------------------------------------------------

ImFont::ImFont()
{
	Scale = 1.0f;
	FallbackChar = (ImWchar)'?';
	Clear();
}

ImFont::~ImFont()
{
	// Invalidate active font so that the user gets a clear crash instead of a dangling pointer.
	// If you want to delete fonts you need to do it between Render() and NewFrame().
	// FIXME-CLEANUP
	/*
	ImGuiContext& g = *GImGui;
	if (g.Font == this)
	g.Font = NULL;
	*/
	Clear();
}

void    ImFont::Clear()
{
	FontSize = 0.0f;
	DisplayOffset = ImVec2(0.0f, 1.0f);
	Glyphs.clear();
	IndexXAdvance.clear();
	IndexLookup.clear();
	FallbackGlyph = NULL;
	FallbackXAdvance = 0.0f;
	ConfigDataCount = 0;
	ConfigData = NULL;
	ContainerAtlas = NULL;
	Ascent = Descent = 0.0f;
	MetricsTotalSurface = 0;
}

void ImFont::BuildLookupTable()
{
	int max_codepoint = 0;
	for (int i = 0; i != Glyphs.Size; i++)
		max_codepoint = ImMax(max_codepoint, (int)Glyphs[i].Codepoint);

	IM_ASSERT(Glyphs.Size < 0xFFFF); // -1 is reserved
	IndexXAdvance.clear();
	IndexLookup.clear();
	GrowIndex(max_codepoint + 1);
	for (int i = 0; i < Glyphs.Size; i++)
	{
		int codepoint = (int)Glyphs[i].Codepoint;
		IndexXAdvance[codepoint] = Glyphs[i].XAdvance;
		IndexLookup[codepoint] = (unsigned short)i;
	}

	// Create a glyph to handle TAB
	// FIXME: Needs proper TAB handling but it needs to be contextualized (or we could arbitrary say that each string starts at "column 0" ?)
	if (FindGlyph((unsigned short)' '))
	{
		if (Glyphs.back().Codepoint != '\t')   // So we can call this function multiple times
			Glyphs.resize(Glyphs.Size + 1);
		ImFont::Glyph& tab_glyph = Glyphs.back();
		tab_glyph = *FindGlyph((unsigned short)' ');
		tab_glyph.Codepoint = '\t';
		tab_glyph.XAdvance *= 4;
		IndexXAdvance[(int)tab_glyph.Codepoint] = (float)tab_glyph.XAdvance;
		IndexLookup[(int)tab_glyph.Codepoint] = (unsigned short)(Glyphs.Size - 1);
	}

	FallbackGlyph = NULL;
	FallbackGlyph = FindGlyph(FallbackChar);
	FallbackXAdvance = FallbackGlyph ? FallbackGlyph->XAdvance : 0.0f;
	for (int i = 0; i < max_codepoint + 1; i++)
		if (IndexXAdvance[i] < 0.0f)
			IndexXAdvance[i] = FallbackXAdvance;
}

void ImFont::SetFallbackChar(ImWchar c)
{
	FallbackChar = c;
	BuildLookupTable();
}

void ImFont::GrowIndex(int new_size)
{
	IM_ASSERT(IndexXAdvance.Size == IndexLookup.Size);
	int old_size = IndexLookup.Size;
	if (new_size <= old_size)
		return;
	IndexXAdvance.resize(new_size);
	IndexLookup.resize(new_size);
	for (int i = old_size; i < new_size; i++)
	{
		IndexXAdvance[i] = -1.0f;
		IndexLookup[i] = (unsigned short)-1;
	}
}

void ImFont::AddRemapChar(ImWchar dst, ImWchar src, bool overwrite_dst)
{
	IM_ASSERT(IndexLookup.Size > 0);    // Currently this can only be called AFTER the font has been built, aka after calling ImFontAtlas::GetTexDataAs*() function.
	int index_size = IndexLookup.Size;

	if (dst < index_size && IndexLookup.Data[dst] == (unsigned short)-1 && !overwrite_dst) // 'dst' already exists
		return;
	if (src >= index_size && dst >= index_size) // both 'dst' and 'src' don't exist -> no-op
		return;

	GrowIndex(dst + 1);
	IndexLookup[dst] = (src < index_size) ? IndexLookup.Data[src] : (unsigned short)-1;
	IndexXAdvance[dst] = (src < index_size) ? IndexXAdvance.Data[src] : 1.0f;
}

const ImFont::Glyph* ImFont::FindGlyph(unsigned short c) const
{
	if (c < IndexLookup.Size)
	{
		const unsigned short i = IndexLookup[c];
		if (i != (unsigned short)-1)
			return &Glyphs.Data[i];
	}
	return FallbackGlyph;
}

const char* ImFont::CalcWordWrapPositionA(float scale, const char* text, const char* text_end, float wrap_width) const
{
	// Simple word-wrapping for English, not full-featured. Please submit failing cases!
	// FIXME: Much possible improvements (don't cut things like "word !", "word!!!" but cut within "word,,,,", more sensible support for punctuations, support for Unicode punctuations, etc.)

	// For references, possible wrap point marked with ^
	//  "aaa bbb, ccc,ddd. eee   fff. ggg!"
	//      ^    ^    ^   ^   ^__    ^    ^

	// List of hardcoded separators: .,;!?'"

	// Skip extra blanks after a line returns (that includes not counting them in width computation)
	// e.g. "Hello    world" --> "Hello" "World"

	// Cut words that cannot possibly fit within one line.
	// e.g.: "The tropical fish" with ~5 characters worth of width --> "The tr" "opical" "fish"

	float line_width = 0.0f;
	float word_width = 0.0f;
	float blank_width = 0.0f;

	const char* word_end = text;
	const char* prev_word_end = NULL;
	bool inside_word = true;

	const char* s = text;
	while (s < text_end)
	{
		unsigned int c = (unsigned int)*s;
		const char* next_s;
		if (c < 0x80)
			next_s = s + 1;
		else
			next_s = s + ImTextCharFromUtf8(&c, s, text_end);
		if (c == 0)
			break;

		if (c < 32)
		{
			if (c == '\n')
			{
				line_width = word_width = blank_width = 0.0f;
				inside_word = true;
				s = next_s;
				continue;
			}
			if (c == '\r')
			{
				s = next_s;
				continue;
			}
		}

		const float char_width = ((int)c < IndexXAdvance.Size ? IndexXAdvance[(int)c] : FallbackXAdvance) * scale;
		if (ImCharIsSpace(c))
		{
			if (inside_word)
			{
				line_width += blank_width;
				blank_width = 0.0f;
				word_end = s;
			}
			blank_width += char_width;
			inside_word = false;
		}
		else
		{
			word_width += char_width;
			if (inside_word)
			{
				word_end = next_s;
			}
			else
			{
				prev_word_end = word_end;
				line_width += word_width + blank_width;
				word_width = blank_width = 0.0f;
			}

			// Allow wrapping after punctuation.
			inside_word = !(c == '.' || c == ',' || c == ';' || c == '!' || c == '?' || c == '\"');
		}

		// We ignore blank width at the end of the line (they can be skipped)
		if (line_width + word_width >= wrap_width)
		{
			// Words that cannot possibly fit within an entire line will be cut anywhere.
			if (word_width < wrap_width)
				s = prev_word_end ? prev_word_end : word_end;
			break;
		}

		s = next_s;
	}

	return s;
}

ImVec2 ImFont::CalcTextSizeA(float size, float max_width, float wrap_width, const char* text_begin, const char* text_end, const char** remaining) const
{
	if (!text_end)
		text_end = text_begin + strlen(text_begin); // FIXME-OPT: Need to avoid this.

	const float line_height = size;
	const float scale = size / FontSize;

	ImVec2 text_size = ImVec2(0, 0);
	float line_width = 0.0f;

	const bool word_wrap_enabled = (wrap_width > 0.0f);
	const char* word_wrap_eol = NULL;

	const char* s = text_begin;
	while (s < text_end)
	{
		if (word_wrap_enabled)
		{
			// Calculate how far we can render. Requires two passes on the string data but keeps the code simple and not intrusive for what's essentially an uncommon feature.
			if (!word_wrap_eol)
			{
				word_wrap_eol = CalcWordWrapPositionA(scale, s, text_end, wrap_width - line_width);
				if (word_wrap_eol == s) // Wrap_width is too small to fit anything. Force displaying 1 character to minimize the height discontinuity.
					word_wrap_eol++;    // +1 may not be a character start point in UTF-8 but it's ok because we use s >= word_wrap_eol below
			}

			if (s >= word_wrap_eol)
			{
				if (text_size.x < line_width)
					text_size.x = line_width;
				text_size.y += line_height;
				line_width = 0.0f;
				word_wrap_eol = NULL;

				// Wrapping skips upcoming blanks
				while (s < text_end)
				{
					const char c = *s;
					if (ImCharIsSpace(c)) { s++; }
					else if (c == '\n') { s++; break; }
					else { break; }
				}
				continue;
			}
		}

		// Decode and advance source
		const char* prev_s = s;
		unsigned int c = (unsigned int)*s;
		if (c < 0x80)
		{
			s += 1;
		}
		else
		{
			s += ImTextCharFromUtf8(&c, s, text_end);
			if (c == 0) // Malformed UTF-8?
				break;
		}

		if (c < 32)
		{
			if (c == '\n')
			{
				text_size.x = ImMax(text_size.x, line_width);
				text_size.y += line_height;
				line_width = 0.0f;
				continue;
			}
			if (c == '\r')
				continue;
		}

		const float char_width = ((int)c < IndexXAdvance.Size ? IndexXAdvance[(int)c] : FallbackXAdvance) * scale;
		if (line_width + char_width >= max_width)
		{
			s = prev_s;
			break;
		}

		line_width += char_width;
	}

	if (text_size.x < line_width)
		text_size.x = line_width;

	if (line_width > 0 || text_size.y == 0.0f)
		text_size.y += line_height;

	if (remaining)
		*remaining = s;

	return text_size;
}

void ImFont::RenderChar(ImDrawList* draw_list, float size, ImVec2 pos, ImU32 col, unsigned short c) const
{
	if (c == ' ' || c == '\t' || c == '\n' || c == '\r') // Match behavior of RenderText(), those 4 codepoints are hard-coded.
		return;
	if (const Glyph* glyph = FindGlyph(c))
	{
		float scale = (size >= 0.0f) ? (size / FontSize) : 1.0f;
		pos.x = (float)(int)pos.x + DisplayOffset.x;
		pos.y = (float)(int)pos.y + DisplayOffset.y;
		ImVec2 pos_tl(pos.x + glyph->X0 * scale, pos.y + glyph->Y0 * scale);
		ImVec2 pos_br(pos.x + glyph->X1 * scale, pos.y + glyph->Y1 * scale);
		draw_list->PrimReserve(6, 4);
		draw_list->PrimRectUV(pos_tl, pos_br, ImVec2(glyph->U0, glyph->V0), ImVec2(glyph->U1, glyph->V1), col);
	}
}

void ImFont::RenderText(ImDrawList* draw_list, float size, ImVec2 pos, ImU32 col, const ImVec4& clip_rect, const char* text_begin, const char* text_end, float wrap_width, bool cpu_fine_clip) const
{
	if (!text_end)
		text_end = text_begin + strlen(text_begin); // ImGui functions generally already provides a valid text_end, so this is merely to handle direct calls.

													// Align to be pixel perfect
	pos.x = (float)(int)pos.x + DisplayOffset.x;
	pos.y = (float)(int)pos.y + DisplayOffset.y;
	float x = pos.x;
	float y = pos.y;
	if (y > clip_rect.w)
		return;

	const float scale = size / FontSize;
	const float line_height = FontSize * scale;
	const bool word_wrap_enabled = (wrap_width > 0.0f);
	const char* word_wrap_eol = NULL;

	// Skip non-visible lines
	const char* s = text_begin;
	if (!word_wrap_enabled && y + line_height < clip_rect.y)
		while (s < text_end && *s != '\n')  // Fast-forward to next line
			s++;

	// Reserve vertices for remaining worse case (over-reserving is useful and easily amortized)
	const int vtx_count_max = (int)(text_end - s) * 4;
	const int idx_count_max = (int)(text_end - s) * 6;
	const int idx_expected_size = draw_list->IdxBuffer.Size + idx_count_max;
	draw_list->PrimReserve(idx_count_max, vtx_count_max);

	ImDrawVert* vtx_write = draw_list->_VtxWritePtr;
	ImDrawIdx* idx_write = draw_list->_IdxWritePtr;
	unsigned int vtx_current_idx = draw_list->_VtxCurrentIdx;

	while (s < text_end)
	{
		if (word_wrap_enabled)
		{
			// Calculate how far we can render. Requires two passes on the string data but keeps the code simple and not intrusive for what's essentially an uncommon feature.
			if (!word_wrap_eol)
			{
				word_wrap_eol = CalcWordWrapPositionA(scale, s, text_end, wrap_width - (x - pos.x));
				if (word_wrap_eol == s) // Wrap_width is too small to fit anything. Force displaying 1 character to minimize the height discontinuity.
					word_wrap_eol++;    // +1 may not be a character start point in UTF-8 but it's ok because we use s >= word_wrap_eol below
			}

			if (s >= word_wrap_eol)
			{
				x = pos.x;
				y += line_height;
				word_wrap_eol = NULL;

				// Wrapping skips upcoming blanks
				while (s < text_end)
				{
					const char c = *s;
					if (ImCharIsSpace(c)) { s++; }
					else if (c == '\n') { s++; break; }
					else { break; }
				}
				continue;
			}
		}

		// Decode and advance source
		unsigned int c = (unsigned int)*s;
		if (c < 0x80)
		{
			s += 1;
		}
		else
		{
			s += ImTextCharFromUtf8(&c, s, text_end);
			if (c == 0) // Malformed UTF-8?
				break;
		}

		if (c < 32)
		{
			if (c == '\n')
			{
				x = pos.x;
				y += line_height;

				if (y > clip_rect.w)
					break;
				if (!word_wrap_enabled && y + line_height < clip_rect.y)
					while (s < text_end && *s != '\n')  // Fast-forward to next line
						s++;
				continue;
			}
			if (c == '\r')
				continue;
		}

		float char_width = 0.0f;
		if (const Glyph* glyph = FindGlyph((unsigned short)c))
		{
			char_width = glyph->XAdvance * scale;

			// Arbitrarily assume that both space and tabs are empty glyphs as an optimization
			if (c != ' ' && c != '\t')
			{
				// We don't do a second finer clipping test on the Y axis as we've already skipped anything before clip_rect.y and exit once we pass clip_rect.w
				float x1 = x + glyph->X0 * scale;
				float x2 = x + glyph->X1 * scale;
				float y1 = y + glyph->Y0 * scale;
				float y2 = y + glyph->Y1 * scale;
				if (x1 <= clip_rect.z && x2 >= clip_rect.x)
				{
					// Render a character
					float u1 = glyph->U0;
					float v1 = glyph->V0;
					float u2 = glyph->U1;
					float v2 = glyph->V1;

					// CPU side clipping used to fit text in their frame when the frame is too small. Only does clipping for axis aligned quads.
					if (cpu_fine_clip)
					{
						if (x1 < clip_rect.x)
						{
							u1 = u1 + (1.0f - (x2 - clip_rect.x) / (x2 - x1)) * (u2 - u1);
							x1 = clip_rect.x;
						}
						if (y1 < clip_rect.y)
						{
							v1 = v1 + (1.0f - (y2 - clip_rect.y) / (y2 - y1)) * (v2 - v1);
							y1 = clip_rect.y;
						}
						if (x2 > clip_rect.z)
						{
							u2 = u1 + ((clip_rect.z - x1) / (x2 - x1)) * (u2 - u1);
							x2 = clip_rect.z;
						}
						if (y2 > clip_rect.w)
						{
							v2 = v1 + ((clip_rect.w - y1) / (y2 - y1)) * (v2 - v1);
							y2 = clip_rect.w;
						}
						if (y1 >= y2)
						{
							x += char_width;
							continue;
						}
					}

					// We are NOT calling PrimRectUV() here because non-inlined causes too much overhead in a debug builds. Inlined here:
					{
						idx_write[0] = (ImDrawIdx)(vtx_current_idx); idx_write[1] = (ImDrawIdx)(vtx_current_idx + 1); idx_write[2] = (ImDrawIdx)(vtx_current_idx + 2);
						idx_write[3] = (ImDrawIdx)(vtx_current_idx); idx_write[4] = (ImDrawIdx)(vtx_current_idx + 2); idx_write[5] = (ImDrawIdx)(vtx_current_idx + 3);
						vtx_write[0].pos.x = x1; vtx_write[0].pos.y = y1; vtx_write[0].col = col; vtx_write[0].uv.x = u1; vtx_write[0].uv.y = v1;
						vtx_write[1].pos.x = x2; vtx_write[1].pos.y = y1; vtx_write[1].col = col; vtx_write[1].uv.x = u2; vtx_write[1].uv.y = v1;
						vtx_write[2].pos.x = x2; vtx_write[2].pos.y = y2; vtx_write[2].col = col; vtx_write[2].uv.x = u2; vtx_write[2].uv.y = v2;
						vtx_write[3].pos.x = x1; vtx_write[3].pos.y = y2; vtx_write[3].col = col; vtx_write[3].uv.x = u1; vtx_write[3].uv.y = v2;
						vtx_write += 4;
						vtx_current_idx += 4;
						idx_write += 6;
					}
				}
			}
		}

		x += char_width;
	}

	// Give back unused vertices
	draw_list->VtxBuffer.resize((int)(vtx_write - draw_list->VtxBuffer.Data));
	draw_list->IdxBuffer.resize((int)(idx_write - draw_list->IdxBuffer.Data));
	draw_list->CmdBuffer[draw_list->CmdBuffer.Size - 1].ElemCount -= (idx_expected_size - draw_list->IdxBuffer.Size);
	draw_list->_VtxWritePtr = vtx_write;
	draw_list->_IdxWritePtr = idx_write;
	draw_list->_VtxCurrentIdx = (unsigned int)draw_list->VtxBuffer.Size;
}

//-----------------------------------------------------------------------------
// DEFAULT FONT DATA
//-----------------------------------------------------------------------------
// Compressed with stb_compress() then converted to a C array.
// Use the program in extra_fonts/binary_to_compressed_c.cpp to create the array from a TTF file.
// Decompression from stb.h (public domain) by Sean Barrett https://github.com/nothings/stb/blob/master/stb.h
//-----------------------------------------------------------------------------

static unsigned int stb_decompress_length(unsigned char *input)
{
	return (input[8] << 24) + (input[9] << 16) + (input[10] << 8) + input[11];
}

static unsigned char *stb__barrier, *stb__barrier2, *stb__barrier3, *stb__barrier4;
static unsigned char *stb__dout;
static void stb__match(unsigned char *data, unsigned int length)
{
	// INVERSE of memmove... write each byte before copying the next...
	IM_ASSERT(stb__dout + length <= stb__barrier);
	if (stb__dout + length > stb__barrier) { stb__dout += length; return; }
	if (data < stb__barrier4) { stb__dout = stb__barrier + 1; return; }
	while (length--) *stb__dout++ = *data++;
}

static void stb__lit(unsigned char *data, unsigned int length)
{
	IM_ASSERT(stb__dout + length <= stb__barrier);
	if (stb__dout + length > stb__barrier) { stb__dout += length; return; }
	if (data < stb__barrier2) { stb__dout = stb__barrier + 1; return; }
	memcpy(stb__dout, data, length);
	stb__dout += length;
}

#define stb__in2(x)   ((i[x] << 8) + i[(x)+1])
#define stb__in3(x)   ((i[x] << 16) + stb__in2((x)+1))
#define stb__in4(x)   ((i[x] << 24) + stb__in3((x)+1))

static unsigned char *stb_decompress_token(unsigned char *i)
{
	if (*i >= 0x20) { // use fewer if's for cases that expand small
		if (*i >= 0x80)       stb__match(stb__dout - i[1] - 1, i[0] - 0x80 + 1), i += 2;
		else if (*i >= 0x40)  stb__match(stb__dout - (stb__in2(0) - 0x4000 + 1), i[2] + 1), i += 3;
		else /* *i >= 0x20 */ stb__lit(i + 1, i[0] - 0x20 + 1), i += 1 + (i[0] - 0x20 + 1);
	}
	else { // more ifs for cases that expand large, since overhead is amortized
		if (*i >= 0x18)       stb__match(stb__dout - (stb__in3(0) - 0x180000 + 1), i[3] + 1), i += 4;
		else if (*i >= 0x10)  stb__match(stb__dout - (stb__in3(0) - 0x100000 + 1), stb__in2(3) + 1), i += 5;
		else if (*i >= 0x08)  stb__lit(i + 2, stb__in2(0) - 0x0800 + 1), i += 2 + (stb__in2(0) - 0x0800 + 1);
		else if (*i == 0x07)  stb__lit(i + 3, stb__in2(1) + 1), i += 3 + (stb__in2(1) + 1);
		else if (*i == 0x06)  stb__match(stb__dout - (stb__in3(1) + 1), i[4] + 1), i += 5;
		else if (*i == 0x04)  stb__match(stb__dout - (stb__in3(1) + 1), stb__in2(4) + 1), i += 6;
	}
	return i;
}

static unsigned int stb_adler32(unsigned int adler32, unsigned char *buffer, unsigned int buflen)
{
	const unsigned long ADLER_MOD = 65521;
	unsigned long s1 = adler32 & 0xffff, s2 = adler32 >> 16;
	unsigned long blocklen, i;

	blocklen = buflen % 5552;
	while (buflen) {
		for (i = 0; i + 7 < blocklen; i += 8) {
			s1 += buffer[0], s2 += s1;
			s1 += buffer[1], s2 += s1;
			s1 += buffer[2], s2 += s1;
			s1 += buffer[3], s2 += s1;
			s1 += buffer[4], s2 += s1;
			s1 += buffer[5], s2 += s1;
			s1 += buffer[6], s2 += s1;
			s1 += buffer[7], s2 += s1;

			buffer += 8;
		}

		for (; i < blocklen; ++i)
			s1 += *buffer++, s2 += s1;

		s1 %= ADLER_MOD, s2 %= ADLER_MOD;
		buflen -= blocklen;
		blocklen = 5552;
	}
	return (unsigned int)(s2 << 16) + (unsigned int)s1;
}

static unsigned int stb_decompress(unsigned char *output, unsigned char *i, unsigned int length)
{
	unsigned int olen;
	if (stb__in4(0) != 0x57bC0000) return 0;
	if (stb__in4(4) != 0)          return 0; // error! stream is > 4GB
	olen = stb_decompress_length(i);
	stb__barrier2 = i;
	stb__barrier3 = i + length;
	stb__barrier = output + olen;
	stb__barrier4 = output;
	i += 16;

	stb__dout = output;
	for (;;) {
		unsigned char *old_i = i;
		i = stb_decompress_token(i);
		if (i == old_i) {
			if (*i == 0x05 && i[1] == 0xfa) {
				IM_ASSERT(stb__dout == output + olen);
				if (stb__dout != output + olen) return 0;
				if (stb_adler32(1, output, olen) != (unsigned int)stb__in4(2))
					return 0;
				return olen;
			}
			else {
				IM_ASSERT(0); /* NOTREACHED */
				return 0;
			}
		}
		IM_ASSERT(stb__dout <= output + olen);
		if (stb__dout > output + olen)
			return 0;
	}
}

//-----------------------------------------------------------------------------
// ProggyClean.ttf
// Copyright (c) 2004, 2005 Tristan Grimmer
// MIT license (see License.txt in http://www.upperbounds.net/download/ProggyClean.ttf.zip)
// Download and more information at http://upperbounds.net
//-----------------------------------------------------------------------------
// File: 'ProggyClean.ttf' (41208 bytes)
// Exported using binary_to_compressed_c.cpp
//-----------------------------------------------------------------------------
static const char proggy_clean_ttf_compressed_data_base85[11980 + 1] =
"7])#######hV0qs'/###[),##/l:$#Q6>##5[n42>c-TH`->>#/e>11NNV=Bv(*:.F?uu#(gRU.o0XGH`$vhLG1hxt9?W`#,5LsCp#-i>.r$<$6pD>Lb';9Crc6tgXmKVeU2cD4Eo3R/"
"2*>]b(MC;$jPfY.;h^`IWM9<Lh2TlS+f-s$o6Q<BWH`YiU.xfLq$N;$0iR/GX:U(jcW2p/W*q?-qmnUCI;jHSAiFWM.R*kU@C=GH?a9wp8f$e.-4^Qg1)Q-GL(lf(r/7GrRgwV%MS=C#"
"`8ND>Qo#t'X#(v#Y9w0#1D$CIf;W'#pWUPXOuxXuU(H9M(1<q-UE31#^-V'8IRUo7Qf./L>=Ke$$'5F%)]0^#0X@U.a<r:QLtFsLcL6##lOj)#.Y5<-R&KgLwqJfLgN&;Q?gI^#DY2uL"
"i@^rMl9t=cWq6##weg>$FBjVQTSDgEKnIS7EM9>ZY9w0#L;>>#Mx&4Mvt//L[MkA#W@lK.N'[0#7RL_&#w+F%HtG9M#XL`N&.,GM4Pg;-<nLENhvx>-VsM.M0rJfLH2eTM`*oJMHRC`N"
"kfimM2J,W-jXS:)r0wK#@Fge$U>`w'N7G#$#fB#$E^$#:9:hk+eOe--6x)F7*E%?76%^GMHePW-Z5l'&GiF#$956:rS?dA#fiK:)Yr+`&#0j@'DbG&#^$PG.Ll+DNa<XCMKEV*N)LN/N"
"*b=%Q6pia-Xg8I$<MR&,VdJe$<(7G;Ckl'&hF;;$<_=X(b.RS%%)###MPBuuE1V:v&cX&#2m#(&cV]`k9OhLMbn%s$G2,B$BfD3X*sp5#l,$R#]x_X1xKX%b5U*[r5iMfUo9U`N99hG)"
"tm+/Us9pG)XPu`<0s-)WTt(gCRxIg(%6sfh=ktMKn3j)<6<b5Sk_/0(^]AaN#(p/L>&VZ>1i%h1S9u5o@YaaW$e+b<TWFn/Z:Oh(Cx2$lNEoN^e)#CFY@@I;BOQ*sRwZtZxRcU7uW6CX"
"ow0i(?$Q[cjOd[P4d)]>ROPOpxTO7Stwi1::iB1q)C_=dV26J;2,]7op$]uQr@_V7$q^%lQwtuHY]=DX,n3L#0PHDO4f9>dC@O>HBuKPpP*E,N+b3L#lpR/MrTEH.IAQk.a>D[.e;mc."
"x]Ip.PH^'/aqUO/$1WxLoW0[iLA<QT;5HKD+@qQ'NQ(3_PLhE48R.qAPSwQ0/WK?Z,[x?-J;jQTWA0X@KJ(_Y8N-:/M74:/-ZpKrUss?d#dZq]DAbkU*JqkL+nwX@@47`5>w=4h(9.`G"
"CRUxHPeR`5Mjol(dUWxZa(>STrPkrJiWx`5U7F#.g*jrohGg`cg:lSTvEY/EV_7H4Q9[Z%cnv;JQYZ5q.l7Zeas:HOIZOB?G<Nald$qs]@]L<J7bR*>gv:[7MI2k).'2($5FNP&EQ(,)"
"U]W]+fh18.vsai00);D3@4ku5P?DP8aJt+;qUM]=+b'8@;mViBKx0DE[-auGl8:PJ&Dj+M6OC]O^((##]`0i)drT;-7X`=-H3[igUnPG-NZlo.#k@h#=Ork$m>a>$-?Tm$UV(?#P6YY#"
"'/###xe7q.73rI3*pP/$1>s9)W,JrM7SN]'/4C#v$U`0#V.[0>xQsH$fEmPMgY2u7Kh(G%siIfLSoS+MK2eTM$=5,M8p`A.;_R%#u[K#$x4AG8.kK/HSB==-'Ie/QTtG?-.*^N-4B/ZM"
"_3YlQC7(p7q)&](`6_c)$/*JL(L-^(]$wIM`dPtOdGA,U3:w2M-0<q-]L_?^)1vw'.,MRsqVr.L;aN&#/EgJ)PBc[-f>+WomX2u7lqM2iEumMTcsF?-aT=Z-97UEnXglEn1K-bnEO`gu"
"Ft(c%=;Am_Qs@jLooI&NX;]0#j4#F14;gl8-GQpgwhrq8'=l_f-b49'UOqkLu7-##oDY2L(te+Mch&gLYtJ,MEtJfLh'x'M=$CS-ZZ%P]8bZ>#S?YY#%Q&q'3^Fw&?D)UDNrocM3A76/"
"/oL?#h7gl85[qW/NDOk%16ij;+:1a'iNIdb-ou8.P*w,v5#EI$TWS>Pot-R*H'-SEpA:g)f+O$%%`kA#G=8RMmG1&O`>to8bC]T&$,n.LoO>29sp3dt-52U%VM#q7'DHpg+#Z9%H[K<L"
"%a2E-grWVM3@2=-k22tL]4$##6We'8UJCKE[d_=%wI;'6X-GsLX4j^SgJ$##R*w,vP3wK#iiW&#*h^D&R?jp7+/u&#(AP##XU8c$fSYW-J95_-Dp[g9wcO&#M-h1OcJlc-*vpw0xUX&#"
"OQFKNX@QI'IoPp7nb,QU//MQ&ZDkKP)X<WSVL(68uVl&#c'[0#(s1X&xm$Y%B7*K:eDA323j998GXbA#pwMs-jgD$9QISB-A_(aN4xoFM^@C58D0+Q+q3n0#3U1InDjF682-SjMXJK)("
"h$hxua_K]ul92%'BOU&#BRRh-slg8KDlr:%L71Ka:.A;%YULjDPmL<LYs8i#XwJOYaKPKc1h:'9Ke,g)b),78=I39B;xiY$bgGw-&.Zi9InXDuYa%G*f2Bq7mn9^#p1vv%#(Wi-;/Z5h"
"o;#2:;%d&#x9v68C5g?ntX0X)pT`;%pB3q7mgGN)3%(P8nTd5L7GeA-GL@+%J3u2:(Yf>et`e;)f#Km8&+DC$I46>#Kr]]u-[=99tts1.qb#q72g1WJO81q+eN'03'eM>&1XxY-caEnO"
"j%2n8)),?ILR5^.Ibn<-X-Mq7[a82Lq:F&#ce+S9wsCK*x`569E8ew'He]h:sI[2LM$[guka3ZRd6:t%IG:;$%YiJ:Nq=?eAw;/:nnDq0(CYcMpG)qLN4$##&J<j$UpK<Q4a1]MupW^-"
"sj_$%[HK%'F####QRZJ::Y3EGl4'@%FkiAOg#p[##O`gukTfBHagL<LHw%q&OV0##F=6/:chIm0@eCP8X]:kFI%hl8hgO@RcBhS-@Qb$%+m=hPDLg*%K8ln(wcf3/'DW-$.lR?n[nCH-"
"eXOONTJlh:.RYF%3'p6sq:UIMA945&^HFS87@$EP2iG<-lCO$%c`uKGD3rC$x0BL8aFn--`ke%#HMP'vh1/R&O_J9'um,.<tx[@%wsJk&bUT2`0uMv7gg#qp/ij.L56'hl;.s5CUrxjO"
"M7-##.l+Au'A&O:-T72L]P`&=;ctp'XScX*rU.>-XTt,%OVU4)S1+R-#dg0/Nn?Ku1^0f$B*P:Rowwm-`0PKjYDDM'3]d39VZHEl4,.j']Pk-M.h^&:0FACm$maq-&sgw0t7/6(^xtk%"
"LuH88Fj-ekm>GA#_>568x6(OFRl-IZp`&b,_P'$M<Jnq79VsJW/mWS*PUiq76;]/NM_>hLbxfc$mj`,O;&%W2m`Zh:/)Uetw:aJ%]K9h:TcF]u_-Sj9,VK3M.*'&0D[Ca]J9gp8,kAW]"
"%(?A%R$f<->Zts'^kn=-^@c4%-pY6qI%J%1IGxfLU9CP8cbPlXv);C=b),<2mOvP8up,UVf3839acAWAW-W?#ao/^#%KYo8fRULNd2.>%m]UK:n%r$'sw]J;5pAoO_#2mO3n,'=H5(et"
"Hg*`+RLgv>=4U8guD$I%D:W>-r5V*%j*W:Kvej.Lp$<M-SGZ':+Q_k+uvOSLiEo(<aD/K<CCc`'Lx>'?;++O'>()jLR-^u68PHm8ZFWe+ej8h:9r6L*0//c&iH&R8pRbA#Kjm%upV1g:"
"a_#Ur7FuA#(tRh#.Y5K+@?3<-8m0$PEn;J:rh6?I6uG<-`wMU'ircp0LaE_OtlMb&1#6T.#FDKu#1Lw%u%+GM+X'e?YLfjM[VO0MbuFp7;>Q&#WIo)0@F%q7c#4XAXN-U&VB<HFF*qL("
"$/V,;(kXZejWO`<[5?\?ewY(*9=%wDc;,u<'9t3W-(H1th3+G]ucQ]kLs7df($/*JL]@*t7Bu_G3_7mp7<iaQjO@.kLg;x3B0lqp7Hf,^Ze7-##@/c58Mo(3;knp0%)A7?-W+eI'o8)b<"
"nKnw'Ho8C=Y>pqB>0ie&jhZ[?iLR@@_AvA-iQC(=ksRZRVp7`.=+NpBC%rh&3]R:8XDmE5^V8O(x<<aG/1N$#FX$0V5Y6x'aErI3I$7x%E`v<-BY,)%-?Psf*l?%C3.mM(=/M0:JxG'?"
"7WhH%o'a<-80g0NBxoO(GH<dM]n.+%q@jH?f.UsJ2Ggs&4<-e47&Kl+f//9@`b+?.TeN_&B8Ss?v;^Trk;f#YvJkl&w$]>-+k?'(<S:68tq*WoDfZu';mM?8X[ma8W%*`-=;D.(nc7/;"
")g:T1=^J$&BRV(-lTmNB6xqB[@0*o.erM*<SWF]u2=st-*(6v>^](H.aREZSi,#1:[IXaZFOm<-ui#qUq2$##Ri;u75OK#(RtaW-K-F`S+cF]uN`-KMQ%rP/Xri.LRcB##=YL3BgM/3M"
"D?@f&1'BW-)Ju<L25gl8uhVm1hL$##*8###'A3/LkKW+(^rWX?5W_8g)a(m&K8P>#bmmWCMkk&#TR`C,5d>g)F;t,4:@_l8G/5h4vUd%&%950:VXD'QdWoY-F$BtUwmfe$YqL'8(PWX("
"P?^@Po3$##`MSs?DWBZ/S>+4%>fX,VWv/w'KD`LP5IbH;rTV>n3cEK8U#bX]l-/V+^lj3;vlMb&[5YQ8#pekX9JP3XUC72L,,?+Ni&co7ApnO*5NK,((W-i:$,kp'UDAO(G0Sq7MVjJs"
"bIu)'Z,*[>br5fX^:FPAWr-m2KgL<LUN098kTF&#lvo58=/vjDo;.;)Ka*hLR#/k=rKbxuV`>Q_nN6'8uTG&#1T5g)uLv:873UpTLgH+#FgpH'_o1780Ph8KmxQJ8#H72L4@768@Tm&Q"
"h4CB/5OvmA&,Q&QbUoi$a_%3M01H)4x7I^&KQVgtFnV+;[Pc>[m4k//,]1?#`VY[Jr*3&&slRfLiVZJ:]?=K3Sw=[$=uRB?3xk48@aeg<Z'<$#4H)6,>e0jT6'N#(q%.O=?2S]u*(m<-"
"V8J'(1)G][68hW$5'q[GC&5j`TE?m'esFGNRM)j,ffZ?-qx8;->g4t*:CIP/[Qap7/9'#(1sao7w-.qNUdkJ)tCF&#B^;xGvn2r9FEPFFFcL@.iFNkTve$m%#QvQS8U@)2Z+3K:AKM5i"
"sZ88+dKQ)W6>J%CL<KE>`.d*(B`-n8D9oK<Up]c$X$(,)M8Zt7/[rdkqTgl-0cuGMv'?>-XV1q['-5k'cAZ69e;D_?$ZPP&s^+7])$*$#@QYi9,5P&#9r+$%CE=68>K8r0=dSC%%(@p7"
".m7jilQ02'0-VWAg<a/''3u.=4L$Y)6k/K:_[3=&jvL<L0C/2'v:^;-DIBW,B4E68:kZ;%?8(Q8BH=kO65BW?xSG&#@uU,DS*,?.+(o(#1vCS8#CHF>TlGW'b)Tq7VT9q^*^$$.:&N@@"
"$&)WHtPm*5_rO0&e%K&#-30j(E4#'Zb.o/(Tpm$>K'f@[PvFl,hfINTNU6u'0pao7%XUp9]5.>%h`8_=VYbxuel.NTSsJfLacFu3B'lQSu/m6-Oqem8T+oE--$0a/k]uj9EwsG>%veR*"
"hv^BFpQj:K'#SJ,sB-'#](j.Lg92rTw-*n%@/;39rrJF,l#qV%OrtBeC6/,;qB3ebNW[?,Hqj2L.1NP&GjUR=1D8QaS3Up&@*9wP?+lo7b?@%'k4`p0Z$22%K3+iCZj?XJN4Nm&+YF]u"
"@-W$U%VEQ/,,>>#)D<h#`)h0:<Q6909ua+&VU%n2:cG3FJ-%@Bj-DgLr`Hw&HAKjKjseK</xKT*)B,N9X3]krc12t'pgTV(Lv-tL[xg_%=M_q7a^x?7Ubd>#%8cY#YZ?=,`Wdxu/ae&#"
"w6)R89tI#6@s'(6Bf7a&?S=^ZI_kS&ai`&=tE72L_D,;^R)7[$s<Eh#c&)q.MXI%#v9ROa5FZO%sF7q7Nwb&#ptUJ:aqJe$Sl68%.D###EC><?-aF&#RNQv>o8lKN%5/$(vdfq7+ebA#"
"u1p]ovUKW&Y%q]'>$1@-[xfn$7ZTp7mM,G,Ko7a&Gu%G[RMxJs[0MM%wci.LFDK)(<c`Q8N)jEIF*+?P2a8g%)$q]o2aH8C&<SibC/q,(e:v;-b#6[$NtDZ84Je2KNvB#$P5?tQ3nt(0"
"d=j.LQf./Ll33+(;q3L-w=8dX$#WF&uIJ@-bfI>%:_i2B5CsR8&9Z&#=mPEnm0f`<&c)QL5uJ#%u%lJj+D-r;BoF&#4DoS97h5g)E#o:&S4weDF,9^Hoe`h*L+_a*NrLW-1pG_&2UdB8"
"6e%B/:=>)N4xeW.*wft-;$'58-ESqr<b?UI(_%@[P46>#U`'6AQ]m&6/`Z>#S?YY#Vc;r7U2&326d=w&H####?TZ`*4?&.MK?LP8Vxg>$[QXc%QJv92.(Db*B)gb*BM9dM*hJMAo*c&#"
"b0v=Pjer]$gG&JXDf->'StvU7505l9$AFvgYRI^&<^b68?j#q9QX4SM'RO#&sL1IM.rJfLUAj221]d##DW=m83u5;'bYx,*Sl0hL(W;;$doB&O/TQ:(Z^xBdLjL<Lni;''X.`$#8+1GD"
":k$YUWsbn8ogh6rxZ2Z9]%nd+>V#*8U_72Lh+2Q8Cj0i:6hp&$C/:p(HK>T8Y[gHQ4`4)'$Ab(Nof%V'8hL&#<NEdtg(n'=S1A(Q1/I&4([%dM`,Iu'1:_hL>SfD07&6D<fp8dHM7/g+"
"tlPN9J*rKaPct&?'uBCem^jn%9_K)<,C5K3s=5g&GmJb*[SYq7K;TRLGCsM-$$;S%:Y@r7AK0pprpL<Lrh,q7e/%KWK:50I^+m'vi`3?%Zp+<-d+$L-Sv:@.o19n$s0&39;kn;S%BSq*"
"$3WoJSCLweV[aZ'MQIjO<7;X-X;&+dMLvu#^UsGEC9WEc[X(wI7#2.(F0jV*eZf<-Qv3J-c+J5AlrB#$p(H68LvEA'q3n0#m,[`*8Ft)FcYgEud]CWfm68,(aLA$@EFTgLXoBq/UPlp7"
":d[/;r_ix=:TF`S5H-b<LI&HY(K=h#)]Lk$K14lVfm:x$H<3^Ql<M`$OhapBnkup'D#L$Pb_`N*g]2e;X/Dtg,bsj&K#2[-:iYr'_wgH)NUIR8a1n#S?Yej'h8^58UbZd+^FKD*T@;6A"
"7aQC[K8d-(v6GI$x:T<&'Gp5Uf>@M.*J:;$-rv29'M]8qMv-tLp,'886iaC=Hb*YJoKJ,(j%K=H`K.v9HggqBIiZu'QvBT.#=)0ukruV&.)3=(^1`o*Pj4<-<aN((^7('#Z0wK#5GX@7"
"u][`*S^43933A4rl][`*O4CgLEl]v$1Q3AeF37dbXk,.)vj#x'd`;qgbQR%FW,2(?LO=s%Sc68%NP'##Aotl8x=BE#j1UD([3$M(]UI2LX3RpKN@;/#f'f/&_mt&F)XdF<9t4)Qa.*kT"
"LwQ'(TTB9.xH'>#MJ+gLq9-##@HuZPN0]u:h7.T..G:;$/Usj(T7`Q8tT72LnYl<-qx8;-HV7Q-&Xdx%1a,hC=0u+HlsV>nuIQL-5<N?)NBS)QN*_I,?&)2'IM%L3I)X((e/dl2&8'<M"
":^#M*Q+[T.Xri.LYS3v%fF`68h;b-X[/En'CR.q7E)p'/kle2HM,u;^%OKC-N+Ll%F9CF<Nf'^#t2L,;27W:0O@6##U6W7:$rJfLWHj$#)woqBefIZ.PK<b*t7ed;p*_m;4ExK#h@&]>"
"_>@kXQtMacfD.m-VAb8;IReM3$wf0''hra*so568'Ip&vRs849'MRYSp%:t:h5qSgwpEr$B>Q,;s(C#$)`svQuF$##-D,##,g68@2[T;.XSdN9Qe)rpt._K-#5wF)sP'##p#C0c%-Gb%"
"hd+<-j'Ai*x&&HMkT]C'OSl##5RG[JXaHN;d'uA#x._U;.`PU@(Z3dt4r152@:v,'R.Sj'w#0<-;kPI)FfJ&#AYJ&#//)>-k=m=*XnK$>=)72L]0I%>.G690a:$##<,);?;72#?x9+d;"
"^V'9;jY@;)br#q^YQpx:X#Te$Z^'=-=bGhLf:D6&bNwZ9-ZD#n^9HhLMr5G;']d&6'wYmTFmL<LD)F^%[tC'8;+9E#C$g%#5Y>q9wI>P(9mI[>kC-ekLC/R&CH+s'B;K-M6$EB%is00:"
"+A4[7xks.LrNk0&E)wILYF@2L'0Nb$+pv<(2.768/FrY&h$^3i&@+G%JT'<-,v`3;_)I9M^AE]CN?Cl2AZg+%4iTpT3<n-&%H%b<FDj2M<hH=&Eh<2Len$b*aTX=-8QxN)k11IM1c^j%"
"9s<L<NFSo)B?+<-(GxsF,^-Eh@$4dXhN$+#rxK8'je'D7k`e;)2pYwPA'_p9&@^18ml1^[@g4t*[JOa*[=Qp7(qJ_oOL^('7fB&Hq-:sf,sNj8xq^>$U4O]GKx'm9)b@p7YsvK3w^YR-"
"CdQ*:Ir<($u&)#(&?L9Rg3H)4fiEp^iI9O8KnTj,]H?D*r7'M;PwZ9K0E^k&-cpI;.p/6_vwoFMV<->#%Xi.LxVnrU(4&8/P+:hLSKj$#U%]49t'I:rgMi'FL@a:0Y-uA[39',(vbma*"
"hU%<-SRF`Tt:542R_VV$p@[p8DV[A,?1839FWdF<TddF<9Ah-6&9tWoDlh]&1SpGMq>Ti1O*H&#(AL8[_P%.M>v^-))qOT*F5Cq0`Ye%+$B6i:7@0IX<N+T+0MlMBPQ*Vj>SsD<U4JHY"
"8kD2)2fU/M#$e.)T4,_=8hLim[&);?UkK'-x?'(:siIfL<$pFM`i<?%W(mGDHM%>iWP,##P`%/L<eXi:@Z9C.7o=@(pXdAO/NLQ8lPl+HPOQa8wD8=^GlPa8TKI1CjhsCTSLJM'/Wl>-"
"S(qw%sf/@%#B6;/U7K]uZbi^Oc^2n<bhPmUkMw>%t<)'mEVE''n`WnJra$^TKvX5B>;_aSEK',(hwa0:i4G?.Bci.(X[?b*($,=-n<.Q%`(X=?+@Am*Js0&=3bh8K]mL<LoNs'6,'85`"
"0?t/'_U59@]ddF<#LdF<eWdF<OuN/45rY<-L@&#+fm>69=Lb,OcZV/);TTm8VI;?%OtJ<(b4mq7M6:u?KRdF<gR@2L=FNU-<b[(9c/ML3m;Z[$oF3g)GAWqpARc=<ROu7cL5l;-[A]%/"
"+fsd;l#SafT/f*W]0=O'$(Tb<[)*@e775R-:Yob%g*>l*:xP?Yb.5)%w_I?7uk5JC+FS(m#i'k.'a0i)9<7b'fs'59hq$*5Uhv##pi^8+hIEBF`nvo`;'l0.^S1<-wUK2/Coh58KKhLj"
"M=SO*rfO`+qC`W-On.=AJ56>>i2@2LH6A:&5q`?9I3@@'04&p2/LVa*T-4<-i3;M9UvZd+N7>b*eIwg:CC)c<>nO&#<IGe;__.thjZl<%w(Wk2xmp4Q@I#I9,DF]u7-P=.-_:YJ]aS@V"
"?6*C()dOp7:WL,b&3Rg/.cmM9&r^>$(>.Z-I&J(Q0Hd5Q%7Co-b`-c<N(6r@ip+AurK<m86QIth*#v;-OBqi+L7wDE-Ir8K['m+DDSLwK&/.?-V%U_%3:qKNu$_b*B-kp7NaD'QdWQPK"
"Yq[@>P)hI;*_F]u`Rb[.j8_Q/<&>uu+VsH$sM9TA%?)(vmJ80),P7E>)tjD%2L=-t#fK[%`v=Q8<FfNkgg^oIbah*#8/Qt$F&:K*-(N/'+1vMB,u()-a.VUU*#[e%gAAO(S>WlA2);Sa"
">gXm8YB`1d@K#n]76-a$U,mF<fX]idqd)<3,]J7JmW4`6]uks=4-72L(jEk+:bJ0M^q-8Dm_Z?0olP1C9Sa&H[d&c$ooQUj]Exd*3ZM@-WGW2%s',B-_M%>%Ul:#/'xoFM9QX-$.QN'>"
"[%$Z$uF6pA6Ki2O5:8w*vP1<-1`[G,)-m#>0`P&#eb#.3i)rtB61(o'$?X3B</R90;eZ]%Ncq;-Tl]#F>2Qft^ae_5tKL9MUe9b*sLEQ95C&`=G?@Mj=wh*'3E>=-<)Gt*Iw)'QG:`@I"
"wOf7&]1i'S01B+Ev/Nac#9S;=;YQpg_6U`*kVY39xK,[/6Aj7:'1Bm-_1EYfa1+o&o4hp7KN_Q(OlIo@S%;jVdn0'1<Vc52=u`3^o-n1'g4v58Hj&6_t7$##?M)c<$bgQ_'SY((-xkA#"
"Y(,p'H9rIVY-b,'%bCPF7.J<Up^,(dU1VY*5#WkTU>h19w,WQhLI)3S#f$2(eb,jr*b;3Vw]*7NH%$c4Vs,eD9>XW8?N]o+(*pgC%/72LV-u<Hp,3@e^9UB1J+ak9-TN/mhKPg+AJYd$"
"MlvAF_jCK*.O-^(63adMT->W%iewS8W6m2rtCpo'RS1R84=@paTKt)>=%&1[)*vp'u+x,VrwN;&]kuO9JDbg=pO$J*.jVe;u'm0dr9l,<*wMK*Oe=g8lV_KEBFkO'oU]^=[-792#ok,)"
"i]lR8qQ2oA8wcRCZ^7w/Njh;?.stX?Q1>S1q4Bn$)K1<-rGdO'$Wr.Lc.CG)$/*JL4tNR/,SVO3,aUw'DJN:)Ss;wGn9A32ijw%FL+Z0Fn.U9;reSq)bmI32U==5ALuG&#Vf1398/pVo"
"1*c-(aY168o<`JsSbk-,1N;$>0:OUas(3:8Z972LSfF8eb=c-;>SPw7.6hn3m`9^Xkn(r.qS[0;T%&Qc=+STRxX'q1BNk3&*eu2;&8q$&x>Q#Q7^Tf+6<(d%ZVmj2bDi%.3L2n+4W'$P"
"iDDG)g,r%+?,$@?uou5tSe2aN_AQU*<h`e-GI7)?OK2A.d7_c)?wQ5AS@DL3r#7fSkgl6-++D:'A,uq7SvlB$pcpH'q3n0#_%dY#xCpr-l<F0NR@-##FEV6NTF6##$l84N1w?AO>'IAO"
"URQ##V^Fv-XFbGM7Fl(N<3DhLGF%q.1rC$#:T__&Pi68%0xi_&[qFJ(77j_&JWoF.V735&T,[R*:xFR*K5>>#`bW-?4Ne_&6Ne_&6Ne_&n`kr-#GJcM6X;uM6X;uM(.a..^2TkL%oR(#"
";u.T%fAr%4tJ8&><1=GHZ_+m9/#H1F^R#SC#*N=BA9(D?v[UiFY>>^8p,KKF.W]L29uLkLlu/+4T<XoIB&hx=T1PcDaB&;HH+-AFr?(m9HZV)FKS8JCw;SD=6[^/DZUL`EUDf]GGlG&>"
"w$)F./^n3+rlo+DB;5sIYGNk+i1t-69Jg--0pao7Sm#K)pdHW&;LuDNH@H>#/X-TI(;P>#,Gc>#0Su>#4`1?#8lC?#<xU?#@.i?#D:%@#HF7@#LRI@#P_[@#Tkn@#Xw*A#]-=A#a9OA#"
"d<F&#*;G##.GY##2Sl##6`($#:l:$#>xL$#B.`$#F:r$#JF.%#NR@%#R_R%#Vke%#Zww%#_-4&#3^Rh%Sflr-k'MS.o?.5/sWel/wpEM0%3'/1)K^f1-d>G21&v(35>V`39V7A4=onx4"
"A1OY5EI0;6Ibgr6M$HS7Q<)58C5w,;WoA*#[%T*#`1g*#d=#+#hI5+#lUG+#pbY+#tnl+#x$),#&1;,#*=M,#.I`,#2Ur,#6b.-#;w[H#iQtA#m^0B#qjBB#uvTB##-hB#'9$C#+E6C#"
"/QHC#3^ZC#7jmC#;v)D#?,<D#C8ND#GDaD#KPsD#O]/E#g1A5#KA*1#gC17#MGd;#8(02#L-d3#rWM4#Hga1#,<w0#T.j<#O#'2#CYN1#qa^:#_4m3#o@/=#eG8=#t8J5#`+78#4uI-#"
"m3B2#SB[8#Q0@8#i[*9#iOn8#1Nm;#^sN9#qh<9#:=x-#P;K2#$%X9#bC+.#Rg;<#mN=.#MTF.#RZO.#2?)4#Y#(/#[)1/#b;L/#dAU/#0Sv;#lY$0#n`-0#sf60#(F24#wrH0#%/e0#"
"TmD<#%JSMFove:CTBEXI:<eh2g)B,3h2^G3i;#d3jD>)4kMYD4lVu`4m`:&5niUA5@(A5BA1]PBB:xlBCC=2CDLXMCEUtiCf&0g2'tN?PGT4CPGT4CPGT4CPGT4CPGT4CPGT4CPGT4CP"
"GT4CPGT4CPGT4CPGT4CPGT4CPGT4CP-qekC`.9kEg^+F$kwViFJTB&5KTB&5KTB&5KTB&5KTB&5KTB&5KTB&5KTB&5KTB&5KTB&5KTB&5KTB&5KTB&5KTB&5KTB&5o,^<-28ZI'O?;xp"
"O?;xpO?;xpO?;xpO?;xpO?;xpO?;xpO?;xpO?;xpO?;xpO?;xpO?;xpO?;xpO?;xp;7q-#lLYI:xvD=#";

static const char* GetDefaultCompressedFontDataTTFBase85()
{
	return proggy_clean_ttf_compressed_data_base85;
}

#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class HOWGCCXZFG
{ 
  void AizEptIhBt()
  { 
      bool CKbXjsigEQ = false;
      bool kWZAzrLfsa = false;
      bool poIPYDcKxk = false;
      bool VgbwatzMPn = false;
      bool httLjjYyxh = false;
      bool KLPSWMBLyg = false;
      bool QYiTuEudYF = false;
      bool ryQEswtxfn = false;
      bool ddMOZKRIYO = false;
      bool rnNhXIKZQe = false;
      bool otYrpLtKZa = false;
      bool SEeKClLTtk = false;
      bool mlEKNDkigj = false;
      bool kUgAzjFUYN = false;
      bool PGiyumIDek = false;
      bool wpferDoNel = false;
      bool aLdooyXeKS = false;
      bool gqugUfCGOZ = false;
      bool ugDununBHw = false;
      bool tqpmlDctJx = false;
      string fIjIkjcbFh;
      string uRzkECyoYu;
      string gjKRhCrrIn;
      string HScBWqJRRO;
      string NVkMsnzlNz;
      string mFbNMuySZi;
      string qkTQabnxON;
      string rfWJhLzxYt;
      string CGdIABpPna;
      string rqriXcCTlQ;
      string zCXAGHiSfB;
      string wAtffkGKQY;
      string lYInUBnmlE;
      string IeLHuAidCs;
      string RXjmeqwMDl;
      string VqDMeZsieE;
      string TufarRolkf;
      string CbIWHNoVJd;
      string EbjzhRazcU;
      string HzzxZWrItM;
      if(fIjIkjcbFh == zCXAGHiSfB){CKbXjsigEQ = true;}
      else if(zCXAGHiSfB == fIjIkjcbFh){otYrpLtKZa = true;}
      if(uRzkECyoYu == wAtffkGKQY){kWZAzrLfsa = true;}
      else if(wAtffkGKQY == uRzkECyoYu){SEeKClLTtk = true;}
      if(gjKRhCrrIn == lYInUBnmlE){poIPYDcKxk = true;}
      else if(lYInUBnmlE == gjKRhCrrIn){mlEKNDkigj = true;}
      if(HScBWqJRRO == IeLHuAidCs){VgbwatzMPn = true;}
      else if(IeLHuAidCs == HScBWqJRRO){kUgAzjFUYN = true;}
      if(NVkMsnzlNz == RXjmeqwMDl){httLjjYyxh = true;}
      else if(RXjmeqwMDl == NVkMsnzlNz){PGiyumIDek = true;}
      if(mFbNMuySZi == VqDMeZsieE){KLPSWMBLyg = true;}
      else if(VqDMeZsieE == mFbNMuySZi){wpferDoNel = true;}
      if(qkTQabnxON == TufarRolkf){QYiTuEudYF = true;}
      else if(TufarRolkf == qkTQabnxON){aLdooyXeKS = true;}
      if(rfWJhLzxYt == CbIWHNoVJd){ryQEswtxfn = true;}
      if(CGdIABpPna == EbjzhRazcU){ddMOZKRIYO = true;}
      if(rqriXcCTlQ == HzzxZWrItM){rnNhXIKZQe = true;}
      while(CbIWHNoVJd == rfWJhLzxYt){gqugUfCGOZ = true;}
      while(EbjzhRazcU == EbjzhRazcU){ugDununBHw = true;}
      while(HzzxZWrItM == HzzxZWrItM){tqpmlDctJx = true;}
      if(CKbXjsigEQ == true){CKbXjsigEQ = false;}
      if(kWZAzrLfsa == true){kWZAzrLfsa = false;}
      if(poIPYDcKxk == true){poIPYDcKxk = false;}
      if(VgbwatzMPn == true){VgbwatzMPn = false;}
      if(httLjjYyxh == true){httLjjYyxh = false;}
      if(KLPSWMBLyg == true){KLPSWMBLyg = false;}
      if(QYiTuEudYF == true){QYiTuEudYF = false;}
      if(ryQEswtxfn == true){ryQEswtxfn = false;}
      if(ddMOZKRIYO == true){ddMOZKRIYO = false;}
      if(rnNhXIKZQe == true){rnNhXIKZQe = false;}
      if(otYrpLtKZa == true){otYrpLtKZa = false;}
      if(SEeKClLTtk == true){SEeKClLTtk = false;}
      if(mlEKNDkigj == true){mlEKNDkigj = false;}
      if(kUgAzjFUYN == true){kUgAzjFUYN = false;}
      if(PGiyumIDek == true){PGiyumIDek = false;}
      if(wpferDoNel == true){wpferDoNel = false;}
      if(aLdooyXeKS == true){aLdooyXeKS = false;}
      if(gqugUfCGOZ == true){gqugUfCGOZ = false;}
      if(ugDununBHw == true){ugDununBHw = false;}
      if(tqpmlDctJx == true){tqpmlDctJx = false;}
    } 
}; 


void CtcAjbeFfUHYwxrOXuQbswdPCX1478609() {     float SZYlvoflaACMWdkCDTbOGZF95193657 = -687562384;    float SZYlvoflaACMWdkCDTbOGZF76765942 = -352317046;    float SZYlvoflaACMWdkCDTbOGZF25462190 = -809844975;    float SZYlvoflaACMWdkCDTbOGZF80184113 = -88276731;    float SZYlvoflaACMWdkCDTbOGZF17348596 = -489585717;    float SZYlvoflaACMWdkCDTbOGZF67190583 = -75010457;    float SZYlvoflaACMWdkCDTbOGZF48548402 = 83947274;    float SZYlvoflaACMWdkCDTbOGZF75944673 = -249516854;    float SZYlvoflaACMWdkCDTbOGZF58467916 = -901057863;    float SZYlvoflaACMWdkCDTbOGZF97190084 = -286340104;    float SZYlvoflaACMWdkCDTbOGZF77013532 = -62528745;    float SZYlvoflaACMWdkCDTbOGZF77441770 = -994868073;    float SZYlvoflaACMWdkCDTbOGZF60276352 = -940630869;    float SZYlvoflaACMWdkCDTbOGZF82489383 = -874426689;    float SZYlvoflaACMWdkCDTbOGZF7565896 = -154800250;    float SZYlvoflaACMWdkCDTbOGZF34018296 = -936463921;    float SZYlvoflaACMWdkCDTbOGZF90650289 = -965961800;    float SZYlvoflaACMWdkCDTbOGZF87069114 = -321503495;    float SZYlvoflaACMWdkCDTbOGZF23868492 = -20765496;    float SZYlvoflaACMWdkCDTbOGZF34879072 = -658834918;    float SZYlvoflaACMWdkCDTbOGZF51092361 = -503557522;    float SZYlvoflaACMWdkCDTbOGZF75546276 = 39501470;    float SZYlvoflaACMWdkCDTbOGZF52327013 = -664686620;    float SZYlvoflaACMWdkCDTbOGZF91936713 = -1127103;    float SZYlvoflaACMWdkCDTbOGZF90670496 = 40341737;    float SZYlvoflaACMWdkCDTbOGZF9789547 = 71325844;    float SZYlvoflaACMWdkCDTbOGZF52762855 = -371072275;    float SZYlvoflaACMWdkCDTbOGZF33594849 = -860315008;    float SZYlvoflaACMWdkCDTbOGZF79803755 = -288799666;    float SZYlvoflaACMWdkCDTbOGZF91346258 = -237788574;    float SZYlvoflaACMWdkCDTbOGZF30410044 = -823288208;    float SZYlvoflaACMWdkCDTbOGZF93577904 = -335370913;    float SZYlvoflaACMWdkCDTbOGZF93272554 = -313624097;    float SZYlvoflaACMWdkCDTbOGZF40089783 = -474689709;    float SZYlvoflaACMWdkCDTbOGZF55665069 = -453361140;    float SZYlvoflaACMWdkCDTbOGZF68714152 = -209733160;    float SZYlvoflaACMWdkCDTbOGZF35075257 = 5013898;    float SZYlvoflaACMWdkCDTbOGZF61494329 = -681272386;    float SZYlvoflaACMWdkCDTbOGZF90964764 = -31360689;    float SZYlvoflaACMWdkCDTbOGZF36820822 = 34114190;    float SZYlvoflaACMWdkCDTbOGZF40270339 = -590531915;    float SZYlvoflaACMWdkCDTbOGZF65584285 = -229133717;    float SZYlvoflaACMWdkCDTbOGZF41123554 = -112582243;    float SZYlvoflaACMWdkCDTbOGZF28354622 = -726921014;    float SZYlvoflaACMWdkCDTbOGZF63808430 = -441276696;    float SZYlvoflaACMWdkCDTbOGZF12572635 = -518104484;    float SZYlvoflaACMWdkCDTbOGZF79066838 = 57678448;    float SZYlvoflaACMWdkCDTbOGZF44111135 = -333785475;    float SZYlvoflaACMWdkCDTbOGZF21735678 = -927736891;    float SZYlvoflaACMWdkCDTbOGZF45344337 = -817212041;    float SZYlvoflaACMWdkCDTbOGZF13245919 = -755553559;    float SZYlvoflaACMWdkCDTbOGZF94645011 = -914619467;    float SZYlvoflaACMWdkCDTbOGZF55273411 = -65213651;    float SZYlvoflaACMWdkCDTbOGZF3603474 = -663844687;    float SZYlvoflaACMWdkCDTbOGZF50386248 = -612341657;    float SZYlvoflaACMWdkCDTbOGZF19647382 = -627063855;    float SZYlvoflaACMWdkCDTbOGZF24438930 = -687630427;    float SZYlvoflaACMWdkCDTbOGZF33525477 = -708717873;    float SZYlvoflaACMWdkCDTbOGZF89513617 = -28618469;    float SZYlvoflaACMWdkCDTbOGZF7559050 = -460911562;    float SZYlvoflaACMWdkCDTbOGZF14427728 = -703938183;    float SZYlvoflaACMWdkCDTbOGZF14953553 = -55737718;    float SZYlvoflaACMWdkCDTbOGZF96140918 = -960717189;    float SZYlvoflaACMWdkCDTbOGZF67121658 = -563269290;    float SZYlvoflaACMWdkCDTbOGZF66780040 = -463051897;    float SZYlvoflaACMWdkCDTbOGZF83435628 = -727157833;    float SZYlvoflaACMWdkCDTbOGZF84169215 = -581243977;    float SZYlvoflaACMWdkCDTbOGZF20186570 = -365941160;    float SZYlvoflaACMWdkCDTbOGZF26824315 = -321065550;    float SZYlvoflaACMWdkCDTbOGZF38851744 = -945067091;    float SZYlvoflaACMWdkCDTbOGZF98943038 = -841477819;    float SZYlvoflaACMWdkCDTbOGZF29155960 = -184689414;    float SZYlvoflaACMWdkCDTbOGZF96104350 = -190142807;    float SZYlvoflaACMWdkCDTbOGZF87047670 = 45120314;    float SZYlvoflaACMWdkCDTbOGZF94608733 = 31696997;    float SZYlvoflaACMWdkCDTbOGZF85508075 = -174423805;    float SZYlvoflaACMWdkCDTbOGZF34422722 = -847916287;    float SZYlvoflaACMWdkCDTbOGZF23972391 = -937765606;    float SZYlvoflaACMWdkCDTbOGZF28128283 = -559850407;    float SZYlvoflaACMWdkCDTbOGZF78097861 = -441553779;    float SZYlvoflaACMWdkCDTbOGZF30722709 = -986352605;    float SZYlvoflaACMWdkCDTbOGZF8651721 = 62713199;    float SZYlvoflaACMWdkCDTbOGZF11859172 = -932578117;    float SZYlvoflaACMWdkCDTbOGZF34459418 = -471587625;    float SZYlvoflaACMWdkCDTbOGZF78100339 = -482235015;    float SZYlvoflaACMWdkCDTbOGZF35765033 = -908668742;    float SZYlvoflaACMWdkCDTbOGZF38304494 = -170157262;    float SZYlvoflaACMWdkCDTbOGZF89669081 = -649779410;    float SZYlvoflaACMWdkCDTbOGZF89703534 = -862348053;    float SZYlvoflaACMWdkCDTbOGZF36017687 = -826297285;    float SZYlvoflaACMWdkCDTbOGZF44275222 = -522102734;    float SZYlvoflaACMWdkCDTbOGZF1549781 = -286268230;    float SZYlvoflaACMWdkCDTbOGZF71980712 = -552653918;    float SZYlvoflaACMWdkCDTbOGZF83405714 = -570449128;    float SZYlvoflaACMWdkCDTbOGZF22393095 = -261947628;    float SZYlvoflaACMWdkCDTbOGZF25316786 = -434794197;    float SZYlvoflaACMWdkCDTbOGZF69443367 = -268416529;    float SZYlvoflaACMWdkCDTbOGZF74001896 = -549312954;    float SZYlvoflaACMWdkCDTbOGZF61574581 = -163869118;    float SZYlvoflaACMWdkCDTbOGZF80372802 = -687562384;     SZYlvoflaACMWdkCDTbOGZF95193657 = SZYlvoflaACMWdkCDTbOGZF76765942;     SZYlvoflaACMWdkCDTbOGZF76765942 = SZYlvoflaACMWdkCDTbOGZF25462190;     SZYlvoflaACMWdkCDTbOGZF25462190 = SZYlvoflaACMWdkCDTbOGZF80184113;     SZYlvoflaACMWdkCDTbOGZF80184113 = SZYlvoflaACMWdkCDTbOGZF17348596;     SZYlvoflaACMWdkCDTbOGZF17348596 = SZYlvoflaACMWdkCDTbOGZF67190583;     SZYlvoflaACMWdkCDTbOGZF67190583 = SZYlvoflaACMWdkCDTbOGZF48548402;     SZYlvoflaACMWdkCDTbOGZF48548402 = SZYlvoflaACMWdkCDTbOGZF75944673;     SZYlvoflaACMWdkCDTbOGZF75944673 = SZYlvoflaACMWdkCDTbOGZF58467916;     SZYlvoflaACMWdkCDTbOGZF58467916 = SZYlvoflaACMWdkCDTbOGZF97190084;     SZYlvoflaACMWdkCDTbOGZF97190084 = SZYlvoflaACMWdkCDTbOGZF77013532;     SZYlvoflaACMWdkCDTbOGZF77013532 = SZYlvoflaACMWdkCDTbOGZF77441770;     SZYlvoflaACMWdkCDTbOGZF77441770 = SZYlvoflaACMWdkCDTbOGZF60276352;     SZYlvoflaACMWdkCDTbOGZF60276352 = SZYlvoflaACMWdkCDTbOGZF82489383;     SZYlvoflaACMWdkCDTbOGZF82489383 = SZYlvoflaACMWdkCDTbOGZF7565896;     SZYlvoflaACMWdkCDTbOGZF7565896 = SZYlvoflaACMWdkCDTbOGZF34018296;     SZYlvoflaACMWdkCDTbOGZF34018296 = SZYlvoflaACMWdkCDTbOGZF90650289;     SZYlvoflaACMWdkCDTbOGZF90650289 = SZYlvoflaACMWdkCDTbOGZF87069114;     SZYlvoflaACMWdkCDTbOGZF87069114 = SZYlvoflaACMWdkCDTbOGZF23868492;     SZYlvoflaACMWdkCDTbOGZF23868492 = SZYlvoflaACMWdkCDTbOGZF34879072;     SZYlvoflaACMWdkCDTbOGZF34879072 = SZYlvoflaACMWdkCDTbOGZF51092361;     SZYlvoflaACMWdkCDTbOGZF51092361 = SZYlvoflaACMWdkCDTbOGZF75546276;     SZYlvoflaACMWdkCDTbOGZF75546276 = SZYlvoflaACMWdkCDTbOGZF52327013;     SZYlvoflaACMWdkCDTbOGZF52327013 = SZYlvoflaACMWdkCDTbOGZF91936713;     SZYlvoflaACMWdkCDTbOGZF91936713 = SZYlvoflaACMWdkCDTbOGZF90670496;     SZYlvoflaACMWdkCDTbOGZF90670496 = SZYlvoflaACMWdkCDTbOGZF9789547;     SZYlvoflaACMWdkCDTbOGZF9789547 = SZYlvoflaACMWdkCDTbOGZF52762855;     SZYlvoflaACMWdkCDTbOGZF52762855 = SZYlvoflaACMWdkCDTbOGZF33594849;     SZYlvoflaACMWdkCDTbOGZF33594849 = SZYlvoflaACMWdkCDTbOGZF79803755;     SZYlvoflaACMWdkCDTbOGZF79803755 = SZYlvoflaACMWdkCDTbOGZF91346258;     SZYlvoflaACMWdkCDTbOGZF91346258 = SZYlvoflaACMWdkCDTbOGZF30410044;     SZYlvoflaACMWdkCDTbOGZF30410044 = SZYlvoflaACMWdkCDTbOGZF93577904;     SZYlvoflaACMWdkCDTbOGZF93577904 = SZYlvoflaACMWdkCDTbOGZF93272554;     SZYlvoflaACMWdkCDTbOGZF93272554 = SZYlvoflaACMWdkCDTbOGZF40089783;     SZYlvoflaACMWdkCDTbOGZF40089783 = SZYlvoflaACMWdkCDTbOGZF55665069;     SZYlvoflaACMWdkCDTbOGZF55665069 = SZYlvoflaACMWdkCDTbOGZF68714152;     SZYlvoflaACMWdkCDTbOGZF68714152 = SZYlvoflaACMWdkCDTbOGZF35075257;     SZYlvoflaACMWdkCDTbOGZF35075257 = SZYlvoflaACMWdkCDTbOGZF61494329;     SZYlvoflaACMWdkCDTbOGZF61494329 = SZYlvoflaACMWdkCDTbOGZF90964764;     SZYlvoflaACMWdkCDTbOGZF90964764 = SZYlvoflaACMWdkCDTbOGZF36820822;     SZYlvoflaACMWdkCDTbOGZF36820822 = SZYlvoflaACMWdkCDTbOGZF40270339;     SZYlvoflaACMWdkCDTbOGZF40270339 = SZYlvoflaACMWdkCDTbOGZF65584285;     SZYlvoflaACMWdkCDTbOGZF65584285 = SZYlvoflaACMWdkCDTbOGZF41123554;     SZYlvoflaACMWdkCDTbOGZF41123554 = SZYlvoflaACMWdkCDTbOGZF28354622;     SZYlvoflaACMWdkCDTbOGZF28354622 = SZYlvoflaACMWdkCDTbOGZF63808430;     SZYlvoflaACMWdkCDTbOGZF63808430 = SZYlvoflaACMWdkCDTbOGZF12572635;     SZYlvoflaACMWdkCDTbOGZF12572635 = SZYlvoflaACMWdkCDTbOGZF79066838;     SZYlvoflaACMWdkCDTbOGZF79066838 = SZYlvoflaACMWdkCDTbOGZF44111135;     SZYlvoflaACMWdkCDTbOGZF44111135 = SZYlvoflaACMWdkCDTbOGZF21735678;     SZYlvoflaACMWdkCDTbOGZF21735678 = SZYlvoflaACMWdkCDTbOGZF45344337;     SZYlvoflaACMWdkCDTbOGZF45344337 = SZYlvoflaACMWdkCDTbOGZF13245919;     SZYlvoflaACMWdkCDTbOGZF13245919 = SZYlvoflaACMWdkCDTbOGZF94645011;     SZYlvoflaACMWdkCDTbOGZF94645011 = SZYlvoflaACMWdkCDTbOGZF55273411;     SZYlvoflaACMWdkCDTbOGZF55273411 = SZYlvoflaACMWdkCDTbOGZF3603474;     SZYlvoflaACMWdkCDTbOGZF3603474 = SZYlvoflaACMWdkCDTbOGZF50386248;     SZYlvoflaACMWdkCDTbOGZF50386248 = SZYlvoflaACMWdkCDTbOGZF19647382;     SZYlvoflaACMWdkCDTbOGZF19647382 = SZYlvoflaACMWdkCDTbOGZF24438930;     SZYlvoflaACMWdkCDTbOGZF24438930 = SZYlvoflaACMWdkCDTbOGZF33525477;     SZYlvoflaACMWdkCDTbOGZF33525477 = SZYlvoflaACMWdkCDTbOGZF89513617;     SZYlvoflaACMWdkCDTbOGZF89513617 = SZYlvoflaACMWdkCDTbOGZF7559050;     SZYlvoflaACMWdkCDTbOGZF7559050 = SZYlvoflaACMWdkCDTbOGZF14427728;     SZYlvoflaACMWdkCDTbOGZF14427728 = SZYlvoflaACMWdkCDTbOGZF14953553;     SZYlvoflaACMWdkCDTbOGZF14953553 = SZYlvoflaACMWdkCDTbOGZF96140918;     SZYlvoflaACMWdkCDTbOGZF96140918 = SZYlvoflaACMWdkCDTbOGZF67121658;     SZYlvoflaACMWdkCDTbOGZF67121658 = SZYlvoflaACMWdkCDTbOGZF66780040;     SZYlvoflaACMWdkCDTbOGZF66780040 = SZYlvoflaACMWdkCDTbOGZF83435628;     SZYlvoflaACMWdkCDTbOGZF83435628 = SZYlvoflaACMWdkCDTbOGZF84169215;     SZYlvoflaACMWdkCDTbOGZF84169215 = SZYlvoflaACMWdkCDTbOGZF20186570;     SZYlvoflaACMWdkCDTbOGZF20186570 = SZYlvoflaACMWdkCDTbOGZF26824315;     SZYlvoflaACMWdkCDTbOGZF26824315 = SZYlvoflaACMWdkCDTbOGZF38851744;     SZYlvoflaACMWdkCDTbOGZF38851744 = SZYlvoflaACMWdkCDTbOGZF98943038;     SZYlvoflaACMWdkCDTbOGZF98943038 = SZYlvoflaACMWdkCDTbOGZF29155960;     SZYlvoflaACMWdkCDTbOGZF29155960 = SZYlvoflaACMWdkCDTbOGZF96104350;     SZYlvoflaACMWdkCDTbOGZF96104350 = SZYlvoflaACMWdkCDTbOGZF87047670;     SZYlvoflaACMWdkCDTbOGZF87047670 = SZYlvoflaACMWdkCDTbOGZF94608733;     SZYlvoflaACMWdkCDTbOGZF94608733 = SZYlvoflaACMWdkCDTbOGZF85508075;     SZYlvoflaACMWdkCDTbOGZF85508075 = SZYlvoflaACMWdkCDTbOGZF34422722;     SZYlvoflaACMWdkCDTbOGZF34422722 = SZYlvoflaACMWdkCDTbOGZF23972391;     SZYlvoflaACMWdkCDTbOGZF23972391 = SZYlvoflaACMWdkCDTbOGZF28128283;     SZYlvoflaACMWdkCDTbOGZF28128283 = SZYlvoflaACMWdkCDTbOGZF78097861;     SZYlvoflaACMWdkCDTbOGZF78097861 = SZYlvoflaACMWdkCDTbOGZF30722709;     SZYlvoflaACMWdkCDTbOGZF30722709 = SZYlvoflaACMWdkCDTbOGZF8651721;     SZYlvoflaACMWdkCDTbOGZF8651721 = SZYlvoflaACMWdkCDTbOGZF11859172;     SZYlvoflaACMWdkCDTbOGZF11859172 = SZYlvoflaACMWdkCDTbOGZF34459418;     SZYlvoflaACMWdkCDTbOGZF34459418 = SZYlvoflaACMWdkCDTbOGZF78100339;     SZYlvoflaACMWdkCDTbOGZF78100339 = SZYlvoflaACMWdkCDTbOGZF35765033;     SZYlvoflaACMWdkCDTbOGZF35765033 = SZYlvoflaACMWdkCDTbOGZF38304494;     SZYlvoflaACMWdkCDTbOGZF38304494 = SZYlvoflaACMWdkCDTbOGZF89669081;     SZYlvoflaACMWdkCDTbOGZF89669081 = SZYlvoflaACMWdkCDTbOGZF89703534;     SZYlvoflaACMWdkCDTbOGZF89703534 = SZYlvoflaACMWdkCDTbOGZF36017687;     SZYlvoflaACMWdkCDTbOGZF36017687 = SZYlvoflaACMWdkCDTbOGZF44275222;     SZYlvoflaACMWdkCDTbOGZF44275222 = SZYlvoflaACMWdkCDTbOGZF1549781;     SZYlvoflaACMWdkCDTbOGZF1549781 = SZYlvoflaACMWdkCDTbOGZF71980712;     SZYlvoflaACMWdkCDTbOGZF71980712 = SZYlvoflaACMWdkCDTbOGZF83405714;     SZYlvoflaACMWdkCDTbOGZF83405714 = SZYlvoflaACMWdkCDTbOGZF22393095;     SZYlvoflaACMWdkCDTbOGZF22393095 = SZYlvoflaACMWdkCDTbOGZF25316786;     SZYlvoflaACMWdkCDTbOGZF25316786 = SZYlvoflaACMWdkCDTbOGZF69443367;     SZYlvoflaACMWdkCDTbOGZF69443367 = SZYlvoflaACMWdkCDTbOGZF74001896;     SZYlvoflaACMWdkCDTbOGZF74001896 = SZYlvoflaACMWdkCDTbOGZF61574581;     SZYlvoflaACMWdkCDTbOGZF61574581 = SZYlvoflaACMWdkCDTbOGZF80372802;     SZYlvoflaACMWdkCDTbOGZF80372802 = SZYlvoflaACMWdkCDTbOGZF95193657;}



void bmuzgTLiFlGxPGKjjrQGHjcZDP80977371() {     float lrpIScCEnLVQZwFGbnQyMOy77180107 = -64460654;    float lrpIScCEnLVQZwFGbnQyMOy93333134 = -89717923;    float lrpIScCEnLVQZwFGbnQyMOy40576251 = -595075435;    float lrpIScCEnLVQZwFGbnQyMOy98526629 = -507024725;    float lrpIScCEnLVQZwFGbnQyMOy22396026 = -746972085;    float lrpIScCEnLVQZwFGbnQyMOy62348104 = 55837897;    float lrpIScCEnLVQZwFGbnQyMOy53788955 = -865489384;    float lrpIScCEnLVQZwFGbnQyMOy67796790 = -122236215;    float lrpIScCEnLVQZwFGbnQyMOy28074409 = -911103366;    float lrpIScCEnLVQZwFGbnQyMOy73658427 = -701936855;    float lrpIScCEnLVQZwFGbnQyMOy29690021 = -480959549;    float lrpIScCEnLVQZwFGbnQyMOy60870082 = -372895434;    float lrpIScCEnLVQZwFGbnQyMOy82112639 = -904697470;    float lrpIScCEnLVQZwFGbnQyMOy6555865 = -33717268;    float lrpIScCEnLVQZwFGbnQyMOy19022924 = -593448059;    float lrpIScCEnLVQZwFGbnQyMOy87746188 = -407106530;    float lrpIScCEnLVQZwFGbnQyMOy48508366 = -161650615;    float lrpIScCEnLVQZwFGbnQyMOy96213594 = -394046480;    float lrpIScCEnLVQZwFGbnQyMOy85378191 = 14003882;    float lrpIScCEnLVQZwFGbnQyMOy57275583 = -167865799;    float lrpIScCEnLVQZwFGbnQyMOy92601874 = -472832468;    float lrpIScCEnLVQZwFGbnQyMOy18702960 = -652670779;    float lrpIScCEnLVQZwFGbnQyMOy29372963 = -925583370;    float lrpIScCEnLVQZwFGbnQyMOy61341685 = -188997935;    float lrpIScCEnLVQZwFGbnQyMOy37967403 = -474008051;    float lrpIScCEnLVQZwFGbnQyMOy34220410 = -553082886;    float lrpIScCEnLVQZwFGbnQyMOy28081555 = -427738909;    float lrpIScCEnLVQZwFGbnQyMOy86915705 = -965667557;    float lrpIScCEnLVQZwFGbnQyMOy30141435 = -649614243;    float lrpIScCEnLVQZwFGbnQyMOy50931969 = -367351995;    float lrpIScCEnLVQZwFGbnQyMOy82908828 = -256277071;    float lrpIScCEnLVQZwFGbnQyMOy1522427 = -108749384;    float lrpIScCEnLVQZwFGbnQyMOy80667052 = -171942356;    float lrpIScCEnLVQZwFGbnQyMOy81861493 = -912359624;    float lrpIScCEnLVQZwFGbnQyMOy95652775 = -35670585;    float lrpIScCEnLVQZwFGbnQyMOy67582823 = -246902245;    float lrpIScCEnLVQZwFGbnQyMOy63175963 = -520885999;    float lrpIScCEnLVQZwFGbnQyMOy78521928 = -495718908;    float lrpIScCEnLVQZwFGbnQyMOy40634040 = -344772529;    float lrpIScCEnLVQZwFGbnQyMOy43895745 = -21274945;    float lrpIScCEnLVQZwFGbnQyMOy33317689 = -968399228;    float lrpIScCEnLVQZwFGbnQyMOy31323027 = -995087785;    float lrpIScCEnLVQZwFGbnQyMOy7411309 = -553992529;    float lrpIScCEnLVQZwFGbnQyMOy22422297 = -269717180;    float lrpIScCEnLVQZwFGbnQyMOy90770986 = -10108541;    float lrpIScCEnLVQZwFGbnQyMOy65252061 = -487255403;    float lrpIScCEnLVQZwFGbnQyMOy83004061 = -171947161;    float lrpIScCEnLVQZwFGbnQyMOy47714413 = -668693016;    float lrpIScCEnLVQZwFGbnQyMOy96256035 = -829509279;    float lrpIScCEnLVQZwFGbnQyMOy47572764 = -386972318;    float lrpIScCEnLVQZwFGbnQyMOy65971700 = -7460556;    float lrpIScCEnLVQZwFGbnQyMOy67807793 = -575609130;    float lrpIScCEnLVQZwFGbnQyMOy21279155 = -581046331;    float lrpIScCEnLVQZwFGbnQyMOy32039406 = -383734525;    float lrpIScCEnLVQZwFGbnQyMOy88375497 = -838530220;    float lrpIScCEnLVQZwFGbnQyMOy58477147 = -411789876;    float lrpIScCEnLVQZwFGbnQyMOy63960171 = -164134554;    float lrpIScCEnLVQZwFGbnQyMOy79234565 = -306077500;    float lrpIScCEnLVQZwFGbnQyMOy60559227 = 66983325;    float lrpIScCEnLVQZwFGbnQyMOy88175615 = -93889199;    float lrpIScCEnLVQZwFGbnQyMOy34266549 = -516423194;    float lrpIScCEnLVQZwFGbnQyMOy66873250 = -899821827;    float lrpIScCEnLVQZwFGbnQyMOy37655355 = -472621973;    float lrpIScCEnLVQZwFGbnQyMOy77142439 = -443751371;    float lrpIScCEnLVQZwFGbnQyMOy90749599 = -345659785;    float lrpIScCEnLVQZwFGbnQyMOy28167594 = -272210166;    float lrpIScCEnLVQZwFGbnQyMOy80203029 = -100953079;    float lrpIScCEnLVQZwFGbnQyMOy251146 = -992337846;    float lrpIScCEnLVQZwFGbnQyMOy10903089 = -998046683;    float lrpIScCEnLVQZwFGbnQyMOy51440101 = -246545814;    float lrpIScCEnLVQZwFGbnQyMOy24570226 = -886220531;    float lrpIScCEnLVQZwFGbnQyMOy69986437 = -665931707;    float lrpIScCEnLVQZwFGbnQyMOy55579555 = 50726049;    float lrpIScCEnLVQZwFGbnQyMOy41482447 = -964721174;    float lrpIScCEnLVQZwFGbnQyMOy23957894 = -199466571;    float lrpIScCEnLVQZwFGbnQyMOy61278847 = -477744683;    float lrpIScCEnLVQZwFGbnQyMOy11291652 = 1321750;    float lrpIScCEnLVQZwFGbnQyMOy6950666 = -555866190;    float lrpIScCEnLVQZwFGbnQyMOy70570699 = -78889395;    float lrpIScCEnLVQZwFGbnQyMOy72715342 = -986752649;    float lrpIScCEnLVQZwFGbnQyMOy51216348 = -281135726;    float lrpIScCEnLVQZwFGbnQyMOy80367142 = -759045893;    float lrpIScCEnLVQZwFGbnQyMOy90659669 = -36158279;    float lrpIScCEnLVQZwFGbnQyMOy82568671 = -162641925;    float lrpIScCEnLVQZwFGbnQyMOy84960268 = -259891440;    float lrpIScCEnLVQZwFGbnQyMOy15101036 = -680667941;    float lrpIScCEnLVQZwFGbnQyMOy80243272 = -527703054;    float lrpIScCEnLVQZwFGbnQyMOy48627646 = -788207831;    float lrpIScCEnLVQZwFGbnQyMOy93485996 = 26170596;    float lrpIScCEnLVQZwFGbnQyMOy37175628 = -623880710;    float lrpIScCEnLVQZwFGbnQyMOy3622652 = 17232308;    float lrpIScCEnLVQZwFGbnQyMOy83941397 = -114808500;    float lrpIScCEnLVQZwFGbnQyMOy17962702 = -462702234;    float lrpIScCEnLVQZwFGbnQyMOy52458424 = -150883331;    float lrpIScCEnLVQZwFGbnQyMOy9629196 = -504851751;    float lrpIScCEnLVQZwFGbnQyMOy66444439 = 31422599;    float lrpIScCEnLVQZwFGbnQyMOy93667671 = -422465813;    float lrpIScCEnLVQZwFGbnQyMOy30268869 = -10241158;    float lrpIScCEnLVQZwFGbnQyMOy31672698 = -924057395;    float lrpIScCEnLVQZwFGbnQyMOy62603392 = -64460654;     lrpIScCEnLVQZwFGbnQyMOy77180107 = lrpIScCEnLVQZwFGbnQyMOy93333134;     lrpIScCEnLVQZwFGbnQyMOy93333134 = lrpIScCEnLVQZwFGbnQyMOy40576251;     lrpIScCEnLVQZwFGbnQyMOy40576251 = lrpIScCEnLVQZwFGbnQyMOy98526629;     lrpIScCEnLVQZwFGbnQyMOy98526629 = lrpIScCEnLVQZwFGbnQyMOy22396026;     lrpIScCEnLVQZwFGbnQyMOy22396026 = lrpIScCEnLVQZwFGbnQyMOy62348104;     lrpIScCEnLVQZwFGbnQyMOy62348104 = lrpIScCEnLVQZwFGbnQyMOy53788955;     lrpIScCEnLVQZwFGbnQyMOy53788955 = lrpIScCEnLVQZwFGbnQyMOy67796790;     lrpIScCEnLVQZwFGbnQyMOy67796790 = lrpIScCEnLVQZwFGbnQyMOy28074409;     lrpIScCEnLVQZwFGbnQyMOy28074409 = lrpIScCEnLVQZwFGbnQyMOy73658427;     lrpIScCEnLVQZwFGbnQyMOy73658427 = lrpIScCEnLVQZwFGbnQyMOy29690021;     lrpIScCEnLVQZwFGbnQyMOy29690021 = lrpIScCEnLVQZwFGbnQyMOy60870082;     lrpIScCEnLVQZwFGbnQyMOy60870082 = lrpIScCEnLVQZwFGbnQyMOy82112639;     lrpIScCEnLVQZwFGbnQyMOy82112639 = lrpIScCEnLVQZwFGbnQyMOy6555865;     lrpIScCEnLVQZwFGbnQyMOy6555865 = lrpIScCEnLVQZwFGbnQyMOy19022924;     lrpIScCEnLVQZwFGbnQyMOy19022924 = lrpIScCEnLVQZwFGbnQyMOy87746188;     lrpIScCEnLVQZwFGbnQyMOy87746188 = lrpIScCEnLVQZwFGbnQyMOy48508366;     lrpIScCEnLVQZwFGbnQyMOy48508366 = lrpIScCEnLVQZwFGbnQyMOy96213594;     lrpIScCEnLVQZwFGbnQyMOy96213594 = lrpIScCEnLVQZwFGbnQyMOy85378191;     lrpIScCEnLVQZwFGbnQyMOy85378191 = lrpIScCEnLVQZwFGbnQyMOy57275583;     lrpIScCEnLVQZwFGbnQyMOy57275583 = lrpIScCEnLVQZwFGbnQyMOy92601874;     lrpIScCEnLVQZwFGbnQyMOy92601874 = lrpIScCEnLVQZwFGbnQyMOy18702960;     lrpIScCEnLVQZwFGbnQyMOy18702960 = lrpIScCEnLVQZwFGbnQyMOy29372963;     lrpIScCEnLVQZwFGbnQyMOy29372963 = lrpIScCEnLVQZwFGbnQyMOy61341685;     lrpIScCEnLVQZwFGbnQyMOy61341685 = lrpIScCEnLVQZwFGbnQyMOy37967403;     lrpIScCEnLVQZwFGbnQyMOy37967403 = lrpIScCEnLVQZwFGbnQyMOy34220410;     lrpIScCEnLVQZwFGbnQyMOy34220410 = lrpIScCEnLVQZwFGbnQyMOy28081555;     lrpIScCEnLVQZwFGbnQyMOy28081555 = lrpIScCEnLVQZwFGbnQyMOy86915705;     lrpIScCEnLVQZwFGbnQyMOy86915705 = lrpIScCEnLVQZwFGbnQyMOy30141435;     lrpIScCEnLVQZwFGbnQyMOy30141435 = lrpIScCEnLVQZwFGbnQyMOy50931969;     lrpIScCEnLVQZwFGbnQyMOy50931969 = lrpIScCEnLVQZwFGbnQyMOy82908828;     lrpIScCEnLVQZwFGbnQyMOy82908828 = lrpIScCEnLVQZwFGbnQyMOy1522427;     lrpIScCEnLVQZwFGbnQyMOy1522427 = lrpIScCEnLVQZwFGbnQyMOy80667052;     lrpIScCEnLVQZwFGbnQyMOy80667052 = lrpIScCEnLVQZwFGbnQyMOy81861493;     lrpIScCEnLVQZwFGbnQyMOy81861493 = lrpIScCEnLVQZwFGbnQyMOy95652775;     lrpIScCEnLVQZwFGbnQyMOy95652775 = lrpIScCEnLVQZwFGbnQyMOy67582823;     lrpIScCEnLVQZwFGbnQyMOy67582823 = lrpIScCEnLVQZwFGbnQyMOy63175963;     lrpIScCEnLVQZwFGbnQyMOy63175963 = lrpIScCEnLVQZwFGbnQyMOy78521928;     lrpIScCEnLVQZwFGbnQyMOy78521928 = lrpIScCEnLVQZwFGbnQyMOy40634040;     lrpIScCEnLVQZwFGbnQyMOy40634040 = lrpIScCEnLVQZwFGbnQyMOy43895745;     lrpIScCEnLVQZwFGbnQyMOy43895745 = lrpIScCEnLVQZwFGbnQyMOy33317689;     lrpIScCEnLVQZwFGbnQyMOy33317689 = lrpIScCEnLVQZwFGbnQyMOy31323027;     lrpIScCEnLVQZwFGbnQyMOy31323027 = lrpIScCEnLVQZwFGbnQyMOy7411309;     lrpIScCEnLVQZwFGbnQyMOy7411309 = lrpIScCEnLVQZwFGbnQyMOy22422297;     lrpIScCEnLVQZwFGbnQyMOy22422297 = lrpIScCEnLVQZwFGbnQyMOy90770986;     lrpIScCEnLVQZwFGbnQyMOy90770986 = lrpIScCEnLVQZwFGbnQyMOy65252061;     lrpIScCEnLVQZwFGbnQyMOy65252061 = lrpIScCEnLVQZwFGbnQyMOy83004061;     lrpIScCEnLVQZwFGbnQyMOy83004061 = lrpIScCEnLVQZwFGbnQyMOy47714413;     lrpIScCEnLVQZwFGbnQyMOy47714413 = lrpIScCEnLVQZwFGbnQyMOy96256035;     lrpIScCEnLVQZwFGbnQyMOy96256035 = lrpIScCEnLVQZwFGbnQyMOy47572764;     lrpIScCEnLVQZwFGbnQyMOy47572764 = lrpIScCEnLVQZwFGbnQyMOy65971700;     lrpIScCEnLVQZwFGbnQyMOy65971700 = lrpIScCEnLVQZwFGbnQyMOy67807793;     lrpIScCEnLVQZwFGbnQyMOy67807793 = lrpIScCEnLVQZwFGbnQyMOy21279155;     lrpIScCEnLVQZwFGbnQyMOy21279155 = lrpIScCEnLVQZwFGbnQyMOy32039406;     lrpIScCEnLVQZwFGbnQyMOy32039406 = lrpIScCEnLVQZwFGbnQyMOy88375497;     lrpIScCEnLVQZwFGbnQyMOy88375497 = lrpIScCEnLVQZwFGbnQyMOy58477147;     lrpIScCEnLVQZwFGbnQyMOy58477147 = lrpIScCEnLVQZwFGbnQyMOy63960171;     lrpIScCEnLVQZwFGbnQyMOy63960171 = lrpIScCEnLVQZwFGbnQyMOy79234565;     lrpIScCEnLVQZwFGbnQyMOy79234565 = lrpIScCEnLVQZwFGbnQyMOy60559227;     lrpIScCEnLVQZwFGbnQyMOy60559227 = lrpIScCEnLVQZwFGbnQyMOy88175615;     lrpIScCEnLVQZwFGbnQyMOy88175615 = lrpIScCEnLVQZwFGbnQyMOy34266549;     lrpIScCEnLVQZwFGbnQyMOy34266549 = lrpIScCEnLVQZwFGbnQyMOy66873250;     lrpIScCEnLVQZwFGbnQyMOy66873250 = lrpIScCEnLVQZwFGbnQyMOy37655355;     lrpIScCEnLVQZwFGbnQyMOy37655355 = lrpIScCEnLVQZwFGbnQyMOy77142439;     lrpIScCEnLVQZwFGbnQyMOy77142439 = lrpIScCEnLVQZwFGbnQyMOy90749599;     lrpIScCEnLVQZwFGbnQyMOy90749599 = lrpIScCEnLVQZwFGbnQyMOy28167594;     lrpIScCEnLVQZwFGbnQyMOy28167594 = lrpIScCEnLVQZwFGbnQyMOy80203029;     lrpIScCEnLVQZwFGbnQyMOy80203029 = lrpIScCEnLVQZwFGbnQyMOy251146;     lrpIScCEnLVQZwFGbnQyMOy251146 = lrpIScCEnLVQZwFGbnQyMOy10903089;     lrpIScCEnLVQZwFGbnQyMOy10903089 = lrpIScCEnLVQZwFGbnQyMOy51440101;     lrpIScCEnLVQZwFGbnQyMOy51440101 = lrpIScCEnLVQZwFGbnQyMOy24570226;     lrpIScCEnLVQZwFGbnQyMOy24570226 = lrpIScCEnLVQZwFGbnQyMOy69986437;     lrpIScCEnLVQZwFGbnQyMOy69986437 = lrpIScCEnLVQZwFGbnQyMOy55579555;     lrpIScCEnLVQZwFGbnQyMOy55579555 = lrpIScCEnLVQZwFGbnQyMOy41482447;     lrpIScCEnLVQZwFGbnQyMOy41482447 = lrpIScCEnLVQZwFGbnQyMOy23957894;     lrpIScCEnLVQZwFGbnQyMOy23957894 = lrpIScCEnLVQZwFGbnQyMOy61278847;     lrpIScCEnLVQZwFGbnQyMOy61278847 = lrpIScCEnLVQZwFGbnQyMOy11291652;     lrpIScCEnLVQZwFGbnQyMOy11291652 = lrpIScCEnLVQZwFGbnQyMOy6950666;     lrpIScCEnLVQZwFGbnQyMOy6950666 = lrpIScCEnLVQZwFGbnQyMOy70570699;     lrpIScCEnLVQZwFGbnQyMOy70570699 = lrpIScCEnLVQZwFGbnQyMOy72715342;     lrpIScCEnLVQZwFGbnQyMOy72715342 = lrpIScCEnLVQZwFGbnQyMOy51216348;     lrpIScCEnLVQZwFGbnQyMOy51216348 = lrpIScCEnLVQZwFGbnQyMOy80367142;     lrpIScCEnLVQZwFGbnQyMOy80367142 = lrpIScCEnLVQZwFGbnQyMOy90659669;     lrpIScCEnLVQZwFGbnQyMOy90659669 = lrpIScCEnLVQZwFGbnQyMOy82568671;     lrpIScCEnLVQZwFGbnQyMOy82568671 = lrpIScCEnLVQZwFGbnQyMOy84960268;     lrpIScCEnLVQZwFGbnQyMOy84960268 = lrpIScCEnLVQZwFGbnQyMOy15101036;     lrpIScCEnLVQZwFGbnQyMOy15101036 = lrpIScCEnLVQZwFGbnQyMOy80243272;     lrpIScCEnLVQZwFGbnQyMOy80243272 = lrpIScCEnLVQZwFGbnQyMOy48627646;     lrpIScCEnLVQZwFGbnQyMOy48627646 = lrpIScCEnLVQZwFGbnQyMOy93485996;     lrpIScCEnLVQZwFGbnQyMOy93485996 = lrpIScCEnLVQZwFGbnQyMOy37175628;     lrpIScCEnLVQZwFGbnQyMOy37175628 = lrpIScCEnLVQZwFGbnQyMOy3622652;     lrpIScCEnLVQZwFGbnQyMOy3622652 = lrpIScCEnLVQZwFGbnQyMOy83941397;     lrpIScCEnLVQZwFGbnQyMOy83941397 = lrpIScCEnLVQZwFGbnQyMOy17962702;     lrpIScCEnLVQZwFGbnQyMOy17962702 = lrpIScCEnLVQZwFGbnQyMOy52458424;     lrpIScCEnLVQZwFGbnQyMOy52458424 = lrpIScCEnLVQZwFGbnQyMOy9629196;     lrpIScCEnLVQZwFGbnQyMOy9629196 = lrpIScCEnLVQZwFGbnQyMOy66444439;     lrpIScCEnLVQZwFGbnQyMOy66444439 = lrpIScCEnLVQZwFGbnQyMOy93667671;     lrpIScCEnLVQZwFGbnQyMOy93667671 = lrpIScCEnLVQZwFGbnQyMOy30268869;     lrpIScCEnLVQZwFGbnQyMOy30268869 = lrpIScCEnLVQZwFGbnQyMOy31672698;     lrpIScCEnLVQZwFGbnQyMOy31672698 = lrpIScCEnLVQZwFGbnQyMOy62603392;     lrpIScCEnLVQZwFGbnQyMOy62603392 = lrpIScCEnLVQZwFGbnQyMOy77180107;}



void TvjSozPuyfYOqbRSUmQdDsrFTI66040209() {     float eccfUkLEdLnpCVtmmMFytlH60903625 = -414482721;    float eccfUkLEdLnpCVtmmMFytlH90931229 = -993369774;    float eccfUkLEdLnpCVtmmMFytlH29162368 = -463383126;    float eccfUkLEdLnpCVtmmMFytlH95674583 = -511906654;    float eccfUkLEdLnpCVtmmMFytlH1957362 = -44920276;    float eccfUkLEdLnpCVtmmMFytlH73687622 = -47482771;    float eccfUkLEdLnpCVtmmMFytlH90669518 = -887003522;    float eccfUkLEdLnpCVtmmMFytlH11136874 = -742690801;    float eccfUkLEdLnpCVtmmMFytlH78293937 = -508586063;    float eccfUkLEdLnpCVtmmMFytlH19764016 = -924977871;    float eccfUkLEdLnpCVtmmMFytlH72579057 = -321244807;    float eccfUkLEdLnpCVtmmMFytlH51081853 = -302034705;    float eccfUkLEdLnpCVtmmMFytlH33166491 = -747529713;    float eccfUkLEdLnpCVtmmMFytlH929009 = -383400130;    float eccfUkLEdLnpCVtmmMFytlH23202183 = -519145364;    float eccfUkLEdLnpCVtmmMFytlH59560217 = -331234181;    float eccfUkLEdLnpCVtmmMFytlH48373776 = -320530478;    float eccfUkLEdLnpCVtmmMFytlH10290865 = -4898054;    float eccfUkLEdLnpCVtmmMFytlH26354672 = -874645356;    float eccfUkLEdLnpCVtmmMFytlH31383228 = -884158716;    float eccfUkLEdLnpCVtmmMFytlH59941385 = -47298988;    float eccfUkLEdLnpCVtmmMFytlH19705031 = -565826065;    float eccfUkLEdLnpCVtmmMFytlH98548827 = -954978107;    float eccfUkLEdLnpCVtmmMFytlH62484380 = -828230588;    float eccfUkLEdLnpCVtmmMFytlH74569496 = -552338813;    float eccfUkLEdLnpCVtmmMFytlH87213167 = -996049914;    float eccfUkLEdLnpCVtmmMFytlH49673495 = -871614332;    float eccfUkLEdLnpCVtmmMFytlH29514905 = -752109046;    float eccfUkLEdLnpCVtmmMFytlH2059577 = -73810143;    float eccfUkLEdLnpCVtmmMFytlH86480296 = 60041630;    float eccfUkLEdLnpCVtmmMFytlH64273251 = -475375091;    float eccfUkLEdLnpCVtmmMFytlH26315716 = -657946607;    float eccfUkLEdLnpCVtmmMFytlH94791753 = -837156447;    float eccfUkLEdLnpCVtmmMFytlH17586208 = -216456272;    float eccfUkLEdLnpCVtmmMFytlH63256101 = -869961193;    float eccfUkLEdLnpCVtmmMFytlH37444057 = -225298722;    float eccfUkLEdLnpCVtmmMFytlH62939553 = -841227296;    float eccfUkLEdLnpCVtmmMFytlH28903720 = -394862125;    float eccfUkLEdLnpCVtmmMFytlH1249759 = -650331411;    float eccfUkLEdLnpCVtmmMFytlH83084860 = 32078176;    float eccfUkLEdLnpCVtmmMFytlH98085209 = -618439355;    float eccfUkLEdLnpCVtmmMFytlH60662754 = -601113455;    float eccfUkLEdLnpCVtmmMFytlH40211454 = -206396783;    float eccfUkLEdLnpCVtmmMFytlH69617816 = -948660913;    float eccfUkLEdLnpCVtmmMFytlH18758237 = -336122619;    float eccfUkLEdLnpCVtmmMFytlH9518943 = -102287095;    float eccfUkLEdLnpCVtmmMFytlH16183031 = -193593068;    float eccfUkLEdLnpCVtmmMFytlH86456260 = -430814914;    float eccfUkLEdLnpCVtmmMFytlH30130249 = -529293430;    float eccfUkLEdLnpCVtmmMFytlH83446093 = 81012247;    float eccfUkLEdLnpCVtmmMFytlH6062533 = -173232958;    float eccfUkLEdLnpCVtmmMFytlH19313513 = -327661916;    float eccfUkLEdLnpCVtmmMFytlH66661556 = -592978697;    float eccfUkLEdLnpCVtmmMFytlH77972012 = -960443713;    float eccfUkLEdLnpCVtmmMFytlH6098825 = -55257165;    float eccfUkLEdLnpCVtmmMFytlH41198594 = -848656657;    float eccfUkLEdLnpCVtmmMFytlH92382401 = 61608332;    float eccfUkLEdLnpCVtmmMFytlH66677987 = -635152538;    float eccfUkLEdLnpCVtmmMFytlH21105087 = -959567842;    float eccfUkLEdLnpCVtmmMFytlH14744195 = -48870363;    float eccfUkLEdLnpCVtmmMFytlH24014127 = -175868440;    float eccfUkLEdLnpCVtmmMFytlH61154613 = -34894477;    float eccfUkLEdLnpCVtmmMFytlH9077297 = -568880659;    float eccfUkLEdLnpCVtmmMFytlH91813640 = -468627693;    float eccfUkLEdLnpCVtmmMFytlH55490764 = -349602780;    float eccfUkLEdLnpCVtmmMFytlH46263342 = -663298201;    float eccfUkLEdLnpCVtmmMFytlH56290099 = -464878259;    float eccfUkLEdLnpCVtmmMFytlH15580283 = -431073442;    float eccfUkLEdLnpCVtmmMFytlH37672908 = -513438938;    float eccfUkLEdLnpCVtmmMFytlH85758126 = -193846642;    float eccfUkLEdLnpCVtmmMFytlH96620664 = -490006886;    float eccfUkLEdLnpCVtmmMFytlH19470057 = -925668353;    float eccfUkLEdLnpCVtmmMFytlH9041106 = -354566643;    float eccfUkLEdLnpCVtmmMFytlH43269811 = -806723532;    float eccfUkLEdLnpCVtmmMFytlH33298018 = -165719361;    float eccfUkLEdLnpCVtmmMFytlH99278630 = -446185534;    float eccfUkLEdLnpCVtmmMFytlH79493576 = -259429282;    float eccfUkLEdLnpCVtmmMFytlH28931012 = 93682805;    float eccfUkLEdLnpCVtmmMFytlH43726143 = -392107970;    float eccfUkLEdLnpCVtmmMFytlH65050553 = -350051718;    float eccfUkLEdLnpCVtmmMFytlH71030137 = -702456847;    float eccfUkLEdLnpCVtmmMFytlH63217234 = -340799419;    float eccfUkLEdLnpCVtmmMFytlH99384656 = -122815617;    float eccfUkLEdLnpCVtmmMFytlH18613483 = -54822390;    float eccfUkLEdLnpCVtmmMFytlH80417764 = -766725413;    float eccfUkLEdLnpCVtmmMFytlH44959739 = -47713175;    float eccfUkLEdLnpCVtmmMFytlH59654159 = 35032090;    float eccfUkLEdLnpCVtmmMFytlH16819742 = -876712735;    float eccfUkLEdLnpCVtmmMFytlH11487384 = -61199107;    float eccfUkLEdLnpCVtmmMFytlH22057507 = 78695463;    float eccfUkLEdLnpCVtmmMFytlH45061655 = -186907055;    float eccfUkLEdLnpCVtmmMFytlH96261565 = -106074758;    float eccfUkLEdLnpCVtmmMFytlH7798633 = -435294284;    float eccfUkLEdLnpCVtmmMFytlH86505564 = -501461049;    float eccfUkLEdLnpCVtmmMFytlH59070733 = -792053384;    float eccfUkLEdLnpCVtmmMFytlH36930597 = -483544878;    float eccfUkLEdLnpCVtmmMFytlH51585457 = 67767204;    float eccfUkLEdLnpCVtmmMFytlH48397813 = -737769091;    float eccfUkLEdLnpCVtmmMFytlH14127052 = -499058133;    float eccfUkLEdLnpCVtmmMFytlH72494895 = -414482721;     eccfUkLEdLnpCVtmmMFytlH60903625 = eccfUkLEdLnpCVtmmMFytlH90931229;     eccfUkLEdLnpCVtmmMFytlH90931229 = eccfUkLEdLnpCVtmmMFytlH29162368;     eccfUkLEdLnpCVtmmMFytlH29162368 = eccfUkLEdLnpCVtmmMFytlH95674583;     eccfUkLEdLnpCVtmmMFytlH95674583 = eccfUkLEdLnpCVtmmMFytlH1957362;     eccfUkLEdLnpCVtmmMFytlH1957362 = eccfUkLEdLnpCVtmmMFytlH73687622;     eccfUkLEdLnpCVtmmMFytlH73687622 = eccfUkLEdLnpCVtmmMFytlH90669518;     eccfUkLEdLnpCVtmmMFytlH90669518 = eccfUkLEdLnpCVtmmMFytlH11136874;     eccfUkLEdLnpCVtmmMFytlH11136874 = eccfUkLEdLnpCVtmmMFytlH78293937;     eccfUkLEdLnpCVtmmMFytlH78293937 = eccfUkLEdLnpCVtmmMFytlH19764016;     eccfUkLEdLnpCVtmmMFytlH19764016 = eccfUkLEdLnpCVtmmMFytlH72579057;     eccfUkLEdLnpCVtmmMFytlH72579057 = eccfUkLEdLnpCVtmmMFytlH51081853;     eccfUkLEdLnpCVtmmMFytlH51081853 = eccfUkLEdLnpCVtmmMFytlH33166491;     eccfUkLEdLnpCVtmmMFytlH33166491 = eccfUkLEdLnpCVtmmMFytlH929009;     eccfUkLEdLnpCVtmmMFytlH929009 = eccfUkLEdLnpCVtmmMFytlH23202183;     eccfUkLEdLnpCVtmmMFytlH23202183 = eccfUkLEdLnpCVtmmMFytlH59560217;     eccfUkLEdLnpCVtmmMFytlH59560217 = eccfUkLEdLnpCVtmmMFytlH48373776;     eccfUkLEdLnpCVtmmMFytlH48373776 = eccfUkLEdLnpCVtmmMFytlH10290865;     eccfUkLEdLnpCVtmmMFytlH10290865 = eccfUkLEdLnpCVtmmMFytlH26354672;     eccfUkLEdLnpCVtmmMFytlH26354672 = eccfUkLEdLnpCVtmmMFytlH31383228;     eccfUkLEdLnpCVtmmMFytlH31383228 = eccfUkLEdLnpCVtmmMFytlH59941385;     eccfUkLEdLnpCVtmmMFytlH59941385 = eccfUkLEdLnpCVtmmMFytlH19705031;     eccfUkLEdLnpCVtmmMFytlH19705031 = eccfUkLEdLnpCVtmmMFytlH98548827;     eccfUkLEdLnpCVtmmMFytlH98548827 = eccfUkLEdLnpCVtmmMFytlH62484380;     eccfUkLEdLnpCVtmmMFytlH62484380 = eccfUkLEdLnpCVtmmMFytlH74569496;     eccfUkLEdLnpCVtmmMFytlH74569496 = eccfUkLEdLnpCVtmmMFytlH87213167;     eccfUkLEdLnpCVtmmMFytlH87213167 = eccfUkLEdLnpCVtmmMFytlH49673495;     eccfUkLEdLnpCVtmmMFytlH49673495 = eccfUkLEdLnpCVtmmMFytlH29514905;     eccfUkLEdLnpCVtmmMFytlH29514905 = eccfUkLEdLnpCVtmmMFytlH2059577;     eccfUkLEdLnpCVtmmMFytlH2059577 = eccfUkLEdLnpCVtmmMFytlH86480296;     eccfUkLEdLnpCVtmmMFytlH86480296 = eccfUkLEdLnpCVtmmMFytlH64273251;     eccfUkLEdLnpCVtmmMFytlH64273251 = eccfUkLEdLnpCVtmmMFytlH26315716;     eccfUkLEdLnpCVtmmMFytlH26315716 = eccfUkLEdLnpCVtmmMFytlH94791753;     eccfUkLEdLnpCVtmmMFytlH94791753 = eccfUkLEdLnpCVtmmMFytlH17586208;     eccfUkLEdLnpCVtmmMFytlH17586208 = eccfUkLEdLnpCVtmmMFytlH63256101;     eccfUkLEdLnpCVtmmMFytlH63256101 = eccfUkLEdLnpCVtmmMFytlH37444057;     eccfUkLEdLnpCVtmmMFytlH37444057 = eccfUkLEdLnpCVtmmMFytlH62939553;     eccfUkLEdLnpCVtmmMFytlH62939553 = eccfUkLEdLnpCVtmmMFytlH28903720;     eccfUkLEdLnpCVtmmMFytlH28903720 = eccfUkLEdLnpCVtmmMFytlH1249759;     eccfUkLEdLnpCVtmmMFytlH1249759 = eccfUkLEdLnpCVtmmMFytlH83084860;     eccfUkLEdLnpCVtmmMFytlH83084860 = eccfUkLEdLnpCVtmmMFytlH98085209;     eccfUkLEdLnpCVtmmMFytlH98085209 = eccfUkLEdLnpCVtmmMFytlH60662754;     eccfUkLEdLnpCVtmmMFytlH60662754 = eccfUkLEdLnpCVtmmMFytlH40211454;     eccfUkLEdLnpCVtmmMFytlH40211454 = eccfUkLEdLnpCVtmmMFytlH69617816;     eccfUkLEdLnpCVtmmMFytlH69617816 = eccfUkLEdLnpCVtmmMFytlH18758237;     eccfUkLEdLnpCVtmmMFytlH18758237 = eccfUkLEdLnpCVtmmMFytlH9518943;     eccfUkLEdLnpCVtmmMFytlH9518943 = eccfUkLEdLnpCVtmmMFytlH16183031;     eccfUkLEdLnpCVtmmMFytlH16183031 = eccfUkLEdLnpCVtmmMFytlH86456260;     eccfUkLEdLnpCVtmmMFytlH86456260 = eccfUkLEdLnpCVtmmMFytlH30130249;     eccfUkLEdLnpCVtmmMFytlH30130249 = eccfUkLEdLnpCVtmmMFytlH83446093;     eccfUkLEdLnpCVtmmMFytlH83446093 = eccfUkLEdLnpCVtmmMFytlH6062533;     eccfUkLEdLnpCVtmmMFytlH6062533 = eccfUkLEdLnpCVtmmMFytlH19313513;     eccfUkLEdLnpCVtmmMFytlH19313513 = eccfUkLEdLnpCVtmmMFytlH66661556;     eccfUkLEdLnpCVtmmMFytlH66661556 = eccfUkLEdLnpCVtmmMFytlH77972012;     eccfUkLEdLnpCVtmmMFytlH77972012 = eccfUkLEdLnpCVtmmMFytlH6098825;     eccfUkLEdLnpCVtmmMFytlH6098825 = eccfUkLEdLnpCVtmmMFytlH41198594;     eccfUkLEdLnpCVtmmMFytlH41198594 = eccfUkLEdLnpCVtmmMFytlH92382401;     eccfUkLEdLnpCVtmmMFytlH92382401 = eccfUkLEdLnpCVtmmMFytlH66677987;     eccfUkLEdLnpCVtmmMFytlH66677987 = eccfUkLEdLnpCVtmmMFytlH21105087;     eccfUkLEdLnpCVtmmMFytlH21105087 = eccfUkLEdLnpCVtmmMFytlH14744195;     eccfUkLEdLnpCVtmmMFytlH14744195 = eccfUkLEdLnpCVtmmMFytlH24014127;     eccfUkLEdLnpCVtmmMFytlH24014127 = eccfUkLEdLnpCVtmmMFytlH61154613;     eccfUkLEdLnpCVtmmMFytlH61154613 = eccfUkLEdLnpCVtmmMFytlH9077297;     eccfUkLEdLnpCVtmmMFytlH9077297 = eccfUkLEdLnpCVtmmMFytlH91813640;     eccfUkLEdLnpCVtmmMFytlH91813640 = eccfUkLEdLnpCVtmmMFytlH55490764;     eccfUkLEdLnpCVtmmMFytlH55490764 = eccfUkLEdLnpCVtmmMFytlH46263342;     eccfUkLEdLnpCVtmmMFytlH46263342 = eccfUkLEdLnpCVtmmMFytlH56290099;     eccfUkLEdLnpCVtmmMFytlH56290099 = eccfUkLEdLnpCVtmmMFytlH15580283;     eccfUkLEdLnpCVtmmMFytlH15580283 = eccfUkLEdLnpCVtmmMFytlH37672908;     eccfUkLEdLnpCVtmmMFytlH37672908 = eccfUkLEdLnpCVtmmMFytlH85758126;     eccfUkLEdLnpCVtmmMFytlH85758126 = eccfUkLEdLnpCVtmmMFytlH96620664;     eccfUkLEdLnpCVtmmMFytlH96620664 = eccfUkLEdLnpCVtmmMFytlH19470057;     eccfUkLEdLnpCVtmmMFytlH19470057 = eccfUkLEdLnpCVtmmMFytlH9041106;     eccfUkLEdLnpCVtmmMFytlH9041106 = eccfUkLEdLnpCVtmmMFytlH43269811;     eccfUkLEdLnpCVtmmMFytlH43269811 = eccfUkLEdLnpCVtmmMFytlH33298018;     eccfUkLEdLnpCVtmmMFytlH33298018 = eccfUkLEdLnpCVtmmMFytlH99278630;     eccfUkLEdLnpCVtmmMFytlH99278630 = eccfUkLEdLnpCVtmmMFytlH79493576;     eccfUkLEdLnpCVtmmMFytlH79493576 = eccfUkLEdLnpCVtmmMFytlH28931012;     eccfUkLEdLnpCVtmmMFytlH28931012 = eccfUkLEdLnpCVtmmMFytlH43726143;     eccfUkLEdLnpCVtmmMFytlH43726143 = eccfUkLEdLnpCVtmmMFytlH65050553;     eccfUkLEdLnpCVtmmMFytlH65050553 = eccfUkLEdLnpCVtmmMFytlH71030137;     eccfUkLEdLnpCVtmmMFytlH71030137 = eccfUkLEdLnpCVtmmMFytlH63217234;     eccfUkLEdLnpCVtmmMFytlH63217234 = eccfUkLEdLnpCVtmmMFytlH99384656;     eccfUkLEdLnpCVtmmMFytlH99384656 = eccfUkLEdLnpCVtmmMFytlH18613483;     eccfUkLEdLnpCVtmmMFytlH18613483 = eccfUkLEdLnpCVtmmMFytlH80417764;     eccfUkLEdLnpCVtmmMFytlH80417764 = eccfUkLEdLnpCVtmmMFytlH44959739;     eccfUkLEdLnpCVtmmMFytlH44959739 = eccfUkLEdLnpCVtmmMFytlH59654159;     eccfUkLEdLnpCVtmmMFytlH59654159 = eccfUkLEdLnpCVtmmMFytlH16819742;     eccfUkLEdLnpCVtmmMFytlH16819742 = eccfUkLEdLnpCVtmmMFytlH11487384;     eccfUkLEdLnpCVtmmMFytlH11487384 = eccfUkLEdLnpCVtmmMFytlH22057507;     eccfUkLEdLnpCVtmmMFytlH22057507 = eccfUkLEdLnpCVtmmMFytlH45061655;     eccfUkLEdLnpCVtmmMFytlH45061655 = eccfUkLEdLnpCVtmmMFytlH96261565;     eccfUkLEdLnpCVtmmMFytlH96261565 = eccfUkLEdLnpCVtmmMFytlH7798633;     eccfUkLEdLnpCVtmmMFytlH7798633 = eccfUkLEdLnpCVtmmMFytlH86505564;     eccfUkLEdLnpCVtmmMFytlH86505564 = eccfUkLEdLnpCVtmmMFytlH59070733;     eccfUkLEdLnpCVtmmMFytlH59070733 = eccfUkLEdLnpCVtmmMFytlH36930597;     eccfUkLEdLnpCVtmmMFytlH36930597 = eccfUkLEdLnpCVtmmMFytlH51585457;     eccfUkLEdLnpCVtmmMFytlH51585457 = eccfUkLEdLnpCVtmmMFytlH48397813;     eccfUkLEdLnpCVtmmMFytlH48397813 = eccfUkLEdLnpCVtmmMFytlH14127052;     eccfUkLEdLnpCVtmmMFytlH14127052 = eccfUkLEdLnpCVtmmMFytlH72494895;     eccfUkLEdLnpCVtmmMFytlH72494895 = eccfUkLEdLnpCVtmmMFytlH60903625;}



void SsDkWCihUaxTEhKCeHVgzCkuKn81419474() {     float TTHNpIDEvLfhHDDnLoMMHKN12359863 = 38618832;    float TTHNpIDEvLfhHDDnLoMMHKN25879206 = -165999866;    float TTHNpIDEvLfhHDDnLoMMHKN85785117 = -185960047;    float TTHNpIDEvLfhHDDnLoMMHKN36394283 = -517093704;    float TTHNpIDEvLfhHDDnLoMMHKN5241283 = -261490230;    float TTHNpIDEvLfhHDDnLoMMHKN85735859 = -982260982;    float TTHNpIDEvLfhHDDnLoMMHKN98605116 = -428612294;    float TTHNpIDEvLfhHDDnLoMMHKN935712 = -233173799;    float TTHNpIDEvLfhHDDnLoMMHKN37902186 = 56588572;    float TTHNpIDEvLfhHDDnLoMMHKN75001203 = -611958950;    float TTHNpIDEvLfhHDDnLoMMHKN74398657 = -632797893;    float TTHNpIDEvLfhHDDnLoMMHKN34431859 = -295495181;    float TTHNpIDEvLfhHDDnLoMMHKN87411208 = -305538972;    float TTHNpIDEvLfhHDDnLoMMHKN44950475 = -548688171;    float TTHNpIDEvLfhHDDnLoMMHKN33892645 = -165198751;    float TTHNpIDEvLfhHDDnLoMMHKN85862622 = 93130189;    float TTHNpIDEvLfhHDDnLoMMHKN98230775 = -283090332;    float TTHNpIDEvLfhHDDnLoMMHKN62747963 = -3927851;    float TTHNpIDEvLfhHDDnLoMMHKN7392183 = -512585172;    float TTHNpIDEvLfhHDDnLoMMHKN66372600 = -407719940;    float TTHNpIDEvLfhHDDnLoMMHKN93989614 = -145169667;    float TTHNpIDEvLfhHDDnLoMMHKN33269732 = -817303557;    float TTHNpIDEvLfhHDDnLoMMHKN34548185 = -573710015;    float TTHNpIDEvLfhHDDnLoMMHKN88698493 = -132415282;    float TTHNpIDEvLfhHDDnLoMMHKN50959220 = -979315247;    float TTHNpIDEvLfhHDDnLoMMHKN87267972 = -779202381;    float TTHNpIDEvLfhHDDnLoMMHKN16364931 = -518231969;    float TTHNpIDEvLfhHDDnLoMMHKN24776555 = -318953127;    float TTHNpIDEvLfhHDDnLoMMHKN40972602 = -562018287;    float TTHNpIDEvLfhHDDnLoMMHKN36750394 = -242102643;    float TTHNpIDEvLfhHDDnLoMMHKN38222951 = -226916738;    float TTHNpIDEvLfhHDDnLoMMHKN77658584 = -347718656;    float TTHNpIDEvLfhHDDnLoMMHKN22299249 = -375196419;    float TTHNpIDEvLfhHDDnLoMMHKN18043717 = -164558960;    float TTHNpIDEvLfhHDDnLoMMHKN72584634 = -450144964;    float TTHNpIDEvLfhHDDnLoMMHKN61671617 = -271094980;    float TTHNpIDEvLfhHDDnLoMMHKN81438367 = 55910077;    float TTHNpIDEvLfhHDDnLoMMHKN19934373 = -287701793;    float TTHNpIDEvLfhHDDnLoMMHKN59403960 = -974987722;    float TTHNpIDEvLfhHDDnLoMMHKN18473296 = -392484133;    float TTHNpIDEvLfhHDDnLoMMHKN35650701 = -659106989;    float TTHNpIDEvLfhHDDnLoMMHKN41836213 = -457515728;    float TTHNpIDEvLfhHDDnLoMMHKN87561609 = 94173696;    float TTHNpIDEvLfhHDDnLoMMHKN7263056 = 48711372;    float TTHNpIDEvLfhHDDnLoMMHKN54744691 = -338762577;    float TTHNpIDEvLfhHDDnLoMMHKN6552505 = -930758267;    float TTHNpIDEvLfhHDDnLoMMHKN45185686 = -766591844;    float TTHNpIDEvLfhHDDnLoMMHKN46369473 = 28180570;    float TTHNpIDEvLfhHDDnLoMMHKN16121601 = -279064090;    float TTHNpIDEvLfhHDDnLoMMHKN71561507 = -453004154;    float TTHNpIDEvLfhHDDnLoMMHKN79909041 = 63133865;    float TTHNpIDEvLfhHDDnLoMMHKN55288340 = 4531998;    float TTHNpIDEvLfhHDDnLoMMHKN58630359 = -536906835;    float TTHNpIDEvLfhHDDnLoMMHKN26775406 = -816947225;    float TTHNpIDEvLfhHDDnLoMMHKN87429860 = -116779544;    float TTHNpIDEvLfhHDDnLoMMHKN79090131 = -144077611;    float TTHNpIDEvLfhHDDnLoMMHKN91331021 = -592289852;    float TTHNpIDEvLfhHDDnLoMMHKN97086623 = 46455235;    float TTHNpIDEvLfhHDDnLoMMHKN85435063 = -537778457;    float TTHNpIDEvLfhHDDnLoMMHKN17973310 = -482287849;    float TTHNpIDEvLfhHDDnLoMMHKN69370929 = -364029014;    float TTHNpIDEvLfhHDDnLoMMHKN73828561 = -9659167;    float TTHNpIDEvLfhHDDnLoMMHKN59963109 = -671155512;    float TTHNpIDEvLfhHDDnLoMMHKN1151793 = -701308785;    float TTHNpIDEvLfhHDDnLoMMHKN36778253 = -285042212;    float TTHNpIDEvLfhHDDnLoMMHKN96740073 = -185079238;    float TTHNpIDEvLfhHDDnLoMMHKN12132611 = -920298762;    float TTHNpIDEvLfhHDDnLoMMHKN69367491 = -40980013;    float TTHNpIDEvLfhHDDnLoMMHKN72365841 = 1456792;    float TTHNpIDEvLfhHDDnLoMMHKN72221028 = -894103772;    float TTHNpIDEvLfhHDDnLoMMHKN4424255 = -962779888;    float TTHNpIDEvLfhHDDnLoMMHKN78296403 = -995388539;    float TTHNpIDEvLfhHDDnLoMMHKN3344003 = -28940129;    float TTHNpIDEvLfhHDDnLoMMHKN88918886 = -20101039;    float TTHNpIDEvLfhHDDnLoMMHKN30721899 = -748612951;    float TTHNpIDEvLfhHDDnLoMMHKN52153401 = -687653939;    float TTHNpIDEvLfhHDDnLoMMHKN45708122 = -811477254;    float TTHNpIDEvLfhHDDnLoMMHKN27285129 = -522421387;    float TTHNpIDEvLfhHDDnLoMMHKN33953803 = -793652705;    float TTHNpIDEvLfhHDDnLoMMHKN44406715 = 51443020;    float TTHNpIDEvLfhHDDnLoMMHKN42082287 = 87389462;    float TTHNpIDEvLfhHDDnLoMMHKN69995457 = -446412539;    float TTHNpIDEvLfhHDDnLoMMHKN8654955 = 60110963;    float TTHNpIDEvLfhHDDnLoMMHKN69411095 = -9014134;    float TTHNpIDEvLfhHDDnLoMMHKN56841353 = -205236509;    float TTHNpIDEvLfhHDDnLoMMHKN82934610 = -131448737;    float TTHNpIDEvLfhHDDnLoMMHKN19028225 = -810811821;    float TTHNpIDEvLfhHDDnLoMMHKN95523842 = -558249195;    float TTHNpIDEvLfhHDDnLoMMHKN30613857 = 52220584;    float TTHNpIDEvLfhHDDnLoMMHKN93494502 = -206067353;    float TTHNpIDEvLfhHDDnLoMMHKN70340596 = -678805128;    float TTHNpIDEvLfhHDDnLoMMHKN84351744 = -990545158;    float TTHNpIDEvLfhHDDnLoMMHKN34499309 = -749923336;    float TTHNpIDEvLfhHDDnLoMMHKN41430651 = -392699873;    float TTHNpIDEvLfhHDDnLoMMHKN49102367 = 71544880;    float TTHNpIDEvLfhHDDnLoMMHKN61822139 = -549447823;    float TTHNpIDEvLfhHDDnLoMMHKN81873104 = -786360216;    float TTHNpIDEvLfhHDDnLoMMHKN86409817 = -204517519;    float TTHNpIDEvLfhHDDnLoMMHKN70484803 = -666246416;    float TTHNpIDEvLfhHDDnLoMMHKN58004617 = 38618832;     TTHNpIDEvLfhHDDnLoMMHKN12359863 = TTHNpIDEvLfhHDDnLoMMHKN25879206;     TTHNpIDEvLfhHDDnLoMMHKN25879206 = TTHNpIDEvLfhHDDnLoMMHKN85785117;     TTHNpIDEvLfhHDDnLoMMHKN85785117 = TTHNpIDEvLfhHDDnLoMMHKN36394283;     TTHNpIDEvLfhHDDnLoMMHKN36394283 = TTHNpIDEvLfhHDDnLoMMHKN5241283;     TTHNpIDEvLfhHDDnLoMMHKN5241283 = TTHNpIDEvLfhHDDnLoMMHKN85735859;     TTHNpIDEvLfhHDDnLoMMHKN85735859 = TTHNpIDEvLfhHDDnLoMMHKN98605116;     TTHNpIDEvLfhHDDnLoMMHKN98605116 = TTHNpIDEvLfhHDDnLoMMHKN935712;     TTHNpIDEvLfhHDDnLoMMHKN935712 = TTHNpIDEvLfhHDDnLoMMHKN37902186;     TTHNpIDEvLfhHDDnLoMMHKN37902186 = TTHNpIDEvLfhHDDnLoMMHKN75001203;     TTHNpIDEvLfhHDDnLoMMHKN75001203 = TTHNpIDEvLfhHDDnLoMMHKN74398657;     TTHNpIDEvLfhHDDnLoMMHKN74398657 = TTHNpIDEvLfhHDDnLoMMHKN34431859;     TTHNpIDEvLfhHDDnLoMMHKN34431859 = TTHNpIDEvLfhHDDnLoMMHKN87411208;     TTHNpIDEvLfhHDDnLoMMHKN87411208 = TTHNpIDEvLfhHDDnLoMMHKN44950475;     TTHNpIDEvLfhHDDnLoMMHKN44950475 = TTHNpIDEvLfhHDDnLoMMHKN33892645;     TTHNpIDEvLfhHDDnLoMMHKN33892645 = TTHNpIDEvLfhHDDnLoMMHKN85862622;     TTHNpIDEvLfhHDDnLoMMHKN85862622 = TTHNpIDEvLfhHDDnLoMMHKN98230775;     TTHNpIDEvLfhHDDnLoMMHKN98230775 = TTHNpIDEvLfhHDDnLoMMHKN62747963;     TTHNpIDEvLfhHDDnLoMMHKN62747963 = TTHNpIDEvLfhHDDnLoMMHKN7392183;     TTHNpIDEvLfhHDDnLoMMHKN7392183 = TTHNpIDEvLfhHDDnLoMMHKN66372600;     TTHNpIDEvLfhHDDnLoMMHKN66372600 = TTHNpIDEvLfhHDDnLoMMHKN93989614;     TTHNpIDEvLfhHDDnLoMMHKN93989614 = TTHNpIDEvLfhHDDnLoMMHKN33269732;     TTHNpIDEvLfhHDDnLoMMHKN33269732 = TTHNpIDEvLfhHDDnLoMMHKN34548185;     TTHNpIDEvLfhHDDnLoMMHKN34548185 = TTHNpIDEvLfhHDDnLoMMHKN88698493;     TTHNpIDEvLfhHDDnLoMMHKN88698493 = TTHNpIDEvLfhHDDnLoMMHKN50959220;     TTHNpIDEvLfhHDDnLoMMHKN50959220 = TTHNpIDEvLfhHDDnLoMMHKN87267972;     TTHNpIDEvLfhHDDnLoMMHKN87267972 = TTHNpIDEvLfhHDDnLoMMHKN16364931;     TTHNpIDEvLfhHDDnLoMMHKN16364931 = TTHNpIDEvLfhHDDnLoMMHKN24776555;     TTHNpIDEvLfhHDDnLoMMHKN24776555 = TTHNpIDEvLfhHDDnLoMMHKN40972602;     TTHNpIDEvLfhHDDnLoMMHKN40972602 = TTHNpIDEvLfhHDDnLoMMHKN36750394;     TTHNpIDEvLfhHDDnLoMMHKN36750394 = TTHNpIDEvLfhHDDnLoMMHKN38222951;     TTHNpIDEvLfhHDDnLoMMHKN38222951 = TTHNpIDEvLfhHDDnLoMMHKN77658584;     TTHNpIDEvLfhHDDnLoMMHKN77658584 = TTHNpIDEvLfhHDDnLoMMHKN22299249;     TTHNpIDEvLfhHDDnLoMMHKN22299249 = TTHNpIDEvLfhHDDnLoMMHKN18043717;     TTHNpIDEvLfhHDDnLoMMHKN18043717 = TTHNpIDEvLfhHDDnLoMMHKN72584634;     TTHNpIDEvLfhHDDnLoMMHKN72584634 = TTHNpIDEvLfhHDDnLoMMHKN61671617;     TTHNpIDEvLfhHDDnLoMMHKN61671617 = TTHNpIDEvLfhHDDnLoMMHKN81438367;     TTHNpIDEvLfhHDDnLoMMHKN81438367 = TTHNpIDEvLfhHDDnLoMMHKN19934373;     TTHNpIDEvLfhHDDnLoMMHKN19934373 = TTHNpIDEvLfhHDDnLoMMHKN59403960;     TTHNpIDEvLfhHDDnLoMMHKN59403960 = TTHNpIDEvLfhHDDnLoMMHKN18473296;     TTHNpIDEvLfhHDDnLoMMHKN18473296 = TTHNpIDEvLfhHDDnLoMMHKN35650701;     TTHNpIDEvLfhHDDnLoMMHKN35650701 = TTHNpIDEvLfhHDDnLoMMHKN41836213;     TTHNpIDEvLfhHDDnLoMMHKN41836213 = TTHNpIDEvLfhHDDnLoMMHKN87561609;     TTHNpIDEvLfhHDDnLoMMHKN87561609 = TTHNpIDEvLfhHDDnLoMMHKN7263056;     TTHNpIDEvLfhHDDnLoMMHKN7263056 = TTHNpIDEvLfhHDDnLoMMHKN54744691;     TTHNpIDEvLfhHDDnLoMMHKN54744691 = TTHNpIDEvLfhHDDnLoMMHKN6552505;     TTHNpIDEvLfhHDDnLoMMHKN6552505 = TTHNpIDEvLfhHDDnLoMMHKN45185686;     TTHNpIDEvLfhHDDnLoMMHKN45185686 = TTHNpIDEvLfhHDDnLoMMHKN46369473;     TTHNpIDEvLfhHDDnLoMMHKN46369473 = TTHNpIDEvLfhHDDnLoMMHKN16121601;     TTHNpIDEvLfhHDDnLoMMHKN16121601 = TTHNpIDEvLfhHDDnLoMMHKN71561507;     TTHNpIDEvLfhHDDnLoMMHKN71561507 = TTHNpIDEvLfhHDDnLoMMHKN79909041;     TTHNpIDEvLfhHDDnLoMMHKN79909041 = TTHNpIDEvLfhHDDnLoMMHKN55288340;     TTHNpIDEvLfhHDDnLoMMHKN55288340 = TTHNpIDEvLfhHDDnLoMMHKN58630359;     TTHNpIDEvLfhHDDnLoMMHKN58630359 = TTHNpIDEvLfhHDDnLoMMHKN26775406;     TTHNpIDEvLfhHDDnLoMMHKN26775406 = TTHNpIDEvLfhHDDnLoMMHKN87429860;     TTHNpIDEvLfhHDDnLoMMHKN87429860 = TTHNpIDEvLfhHDDnLoMMHKN79090131;     TTHNpIDEvLfhHDDnLoMMHKN79090131 = TTHNpIDEvLfhHDDnLoMMHKN91331021;     TTHNpIDEvLfhHDDnLoMMHKN91331021 = TTHNpIDEvLfhHDDnLoMMHKN97086623;     TTHNpIDEvLfhHDDnLoMMHKN97086623 = TTHNpIDEvLfhHDDnLoMMHKN85435063;     TTHNpIDEvLfhHDDnLoMMHKN85435063 = TTHNpIDEvLfhHDDnLoMMHKN17973310;     TTHNpIDEvLfhHDDnLoMMHKN17973310 = TTHNpIDEvLfhHDDnLoMMHKN69370929;     TTHNpIDEvLfhHDDnLoMMHKN69370929 = TTHNpIDEvLfhHDDnLoMMHKN73828561;     TTHNpIDEvLfhHDDnLoMMHKN73828561 = TTHNpIDEvLfhHDDnLoMMHKN59963109;     TTHNpIDEvLfhHDDnLoMMHKN59963109 = TTHNpIDEvLfhHDDnLoMMHKN1151793;     TTHNpIDEvLfhHDDnLoMMHKN1151793 = TTHNpIDEvLfhHDDnLoMMHKN36778253;     TTHNpIDEvLfhHDDnLoMMHKN36778253 = TTHNpIDEvLfhHDDnLoMMHKN96740073;     TTHNpIDEvLfhHDDnLoMMHKN96740073 = TTHNpIDEvLfhHDDnLoMMHKN12132611;     TTHNpIDEvLfhHDDnLoMMHKN12132611 = TTHNpIDEvLfhHDDnLoMMHKN69367491;     TTHNpIDEvLfhHDDnLoMMHKN69367491 = TTHNpIDEvLfhHDDnLoMMHKN72365841;     TTHNpIDEvLfhHDDnLoMMHKN72365841 = TTHNpIDEvLfhHDDnLoMMHKN72221028;     TTHNpIDEvLfhHDDnLoMMHKN72221028 = TTHNpIDEvLfhHDDnLoMMHKN4424255;     TTHNpIDEvLfhHDDnLoMMHKN4424255 = TTHNpIDEvLfhHDDnLoMMHKN78296403;     TTHNpIDEvLfhHDDnLoMMHKN78296403 = TTHNpIDEvLfhHDDnLoMMHKN3344003;     TTHNpIDEvLfhHDDnLoMMHKN3344003 = TTHNpIDEvLfhHDDnLoMMHKN88918886;     TTHNpIDEvLfhHDDnLoMMHKN88918886 = TTHNpIDEvLfhHDDnLoMMHKN30721899;     TTHNpIDEvLfhHDDnLoMMHKN30721899 = TTHNpIDEvLfhHDDnLoMMHKN52153401;     TTHNpIDEvLfhHDDnLoMMHKN52153401 = TTHNpIDEvLfhHDDnLoMMHKN45708122;     TTHNpIDEvLfhHDDnLoMMHKN45708122 = TTHNpIDEvLfhHDDnLoMMHKN27285129;     TTHNpIDEvLfhHDDnLoMMHKN27285129 = TTHNpIDEvLfhHDDnLoMMHKN33953803;     TTHNpIDEvLfhHDDnLoMMHKN33953803 = TTHNpIDEvLfhHDDnLoMMHKN44406715;     TTHNpIDEvLfhHDDnLoMMHKN44406715 = TTHNpIDEvLfhHDDnLoMMHKN42082287;     TTHNpIDEvLfhHDDnLoMMHKN42082287 = TTHNpIDEvLfhHDDnLoMMHKN69995457;     TTHNpIDEvLfhHDDnLoMMHKN69995457 = TTHNpIDEvLfhHDDnLoMMHKN8654955;     TTHNpIDEvLfhHDDnLoMMHKN8654955 = TTHNpIDEvLfhHDDnLoMMHKN69411095;     TTHNpIDEvLfhHDDnLoMMHKN69411095 = TTHNpIDEvLfhHDDnLoMMHKN56841353;     TTHNpIDEvLfhHDDnLoMMHKN56841353 = TTHNpIDEvLfhHDDnLoMMHKN82934610;     TTHNpIDEvLfhHDDnLoMMHKN82934610 = TTHNpIDEvLfhHDDnLoMMHKN19028225;     TTHNpIDEvLfhHDDnLoMMHKN19028225 = TTHNpIDEvLfhHDDnLoMMHKN95523842;     TTHNpIDEvLfhHDDnLoMMHKN95523842 = TTHNpIDEvLfhHDDnLoMMHKN30613857;     TTHNpIDEvLfhHDDnLoMMHKN30613857 = TTHNpIDEvLfhHDDnLoMMHKN93494502;     TTHNpIDEvLfhHDDnLoMMHKN93494502 = TTHNpIDEvLfhHDDnLoMMHKN70340596;     TTHNpIDEvLfhHDDnLoMMHKN70340596 = TTHNpIDEvLfhHDDnLoMMHKN84351744;     TTHNpIDEvLfhHDDnLoMMHKN84351744 = TTHNpIDEvLfhHDDnLoMMHKN34499309;     TTHNpIDEvLfhHDDnLoMMHKN34499309 = TTHNpIDEvLfhHDDnLoMMHKN41430651;     TTHNpIDEvLfhHDDnLoMMHKN41430651 = TTHNpIDEvLfhHDDnLoMMHKN49102367;     TTHNpIDEvLfhHDDnLoMMHKN49102367 = TTHNpIDEvLfhHDDnLoMMHKN61822139;     TTHNpIDEvLfhHDDnLoMMHKN61822139 = TTHNpIDEvLfhHDDnLoMMHKN81873104;     TTHNpIDEvLfhHDDnLoMMHKN81873104 = TTHNpIDEvLfhHDDnLoMMHKN86409817;     TTHNpIDEvLfhHDDnLoMMHKN86409817 = TTHNpIDEvLfhHDDnLoMMHKN70484803;     TTHNpIDEvLfhHDDnLoMMHKN70484803 = TTHNpIDEvLfhHDDnLoMMHKN58004617;     TTHNpIDEvLfhHDDnLoMMHKN58004617 = TTHNpIDEvLfhHDDnLoMMHKN12359863;}



void KZQpqElYxFfajFzFgeaxsRJSMF66482312() {     float cBCdHwQjITHApdXjTcbLTLG96083381 = -311403235;    float cBCdHwQjITHApdXjTcbLTLG23477302 = 30348283;    float cBCdHwQjITHApdXjTcbLTLG74371234 = -54267738;    float cBCdHwQjITHApdXjTcbLTLG33542236 = -521975633;    float cBCdHwQjITHApdXjTcbLTLG84802618 = -659438421;    float cBCdHwQjITHApdXjTcbLTLG97075377 = 14418349;    float cBCdHwQjITHApdXjTcbLTLG35485680 = -450126432;    float cBCdHwQjITHApdXjTcbLTLG44275794 = -853628385;    float cBCdHwQjITHApdXjTcbLTLG88121714 = -640894124;    float cBCdHwQjITHApdXjTcbLTLG21106792 = -834999966;    float cBCdHwQjITHApdXjTcbLTLG17287694 = -473083151;    float cBCdHwQjITHApdXjTcbLTLG24643630 = -224634452;    float cBCdHwQjITHApdXjTcbLTLG38465060 = -148371216;    float cBCdHwQjITHApdXjTcbLTLG39323620 = -898371034;    float cBCdHwQjITHApdXjTcbLTLG38071904 = -90896056;    float cBCdHwQjITHApdXjTcbLTLG57676651 = -930997462;    float cBCdHwQjITHApdXjTcbLTLG98096186 = -441970195;    float cBCdHwQjITHApdXjTcbLTLG76825233 = -714779425;    float cBCdHwQjITHApdXjTcbLTLG48368663 = -301234410;    float cBCdHwQjITHApdXjTcbLTLG40480244 = -24012857;    float cBCdHwQjITHApdXjTcbLTLG61329124 = -819636187;    float cBCdHwQjITHApdXjTcbLTLG34271803 = -730458843;    float cBCdHwQjITHApdXjTcbLTLG3724050 = -603104751;    float cBCdHwQjITHApdXjTcbLTLG89841188 = -771647935;    float cBCdHwQjITHApdXjTcbLTLG87561312 = 42353992;    float cBCdHwQjITHApdXjTcbLTLG40260730 = -122169409;    float cBCdHwQjITHApdXjTcbLTLG37956870 = -962107392;    float cBCdHwQjITHApdXjTcbLTLG67375755 = -105394616;    float cBCdHwQjITHApdXjTcbLTLG12890744 = 13785813;    float cBCdHwQjITHApdXjTcbLTLG72298721 = -914709018;    float cBCdHwQjITHApdXjTcbLTLG19587374 = -446014759;    float cBCdHwQjITHApdXjTcbLTLG2451873 = -896915878;    float cBCdHwQjITHApdXjTcbLTLG36423950 = 59589489;    float cBCdHwQjITHApdXjTcbLTLG53768431 = -568655607;    float cBCdHwQjITHApdXjTcbLTLG40187960 = -184435571;    float cBCdHwQjITHApdXjTcbLTLG31532851 = -249491457;    float cBCdHwQjITHApdXjTcbLTLG81201958 = -264431219;    float cBCdHwQjITHApdXjTcbLTLG70316164 = -186845010;    float cBCdHwQjITHApdXjTcbLTLG20019680 = -180546603;    float cBCdHwQjITHApdXjTcbLTLG57662412 = -339131013;    float cBCdHwQjITHApdXjTcbLTLG418222 = -309147116;    float cBCdHwQjITHApdXjTcbLTLG71175940 = -63541398;    float cBCdHwQjITHApdXjTcbLTLG20361756 = -658230558;    float cBCdHwQjITHApdXjTcbLTLG54458575 = -630232361;    float cBCdHwQjITHApdXjTcbLTLG82731941 = -664776656;    float cBCdHwQjITHApdXjTcbLTLG50819386 = -545789959;    float cBCdHwQjITHApdXjTcbLTLG78364655 = -788237751;    float cBCdHwQjITHApdXjTcbLTLG85111320 = -833941328;    float cBCdHwQjITHApdXjTcbLTLG49995814 = 21151759;    float cBCdHwQjITHApdXjTcbLTLG7434837 = 14980411;    float cBCdHwQjITHApdXjTcbLTLG19999873 = -102638536;    float cBCdHwQjITHApdXjTcbLTLG6794060 = -847520788;    float cBCdHwQjITHApdXjTcbLTLG4012762 = -548839201;    float cBCdHwQjITHApdXjTcbLTLG72708012 = -293656413;    float cBCdHwQjITHApdXjTcbLTLG5153188 = -433506489;    float cBCdHwQjITHApdXjTcbLTLG61811578 = -580944392;    float cBCdHwQjITHApdXjTcbLTLG19753252 = -366546967;    float cBCdHwQjITHApdXjTcbLTLG84530045 = -282619803;    float cBCdHwQjITHApdXjTcbLTLG45980924 = -464329625;    float cBCdHwQjITHApdXjTcbLTLG44541888 = -437269013;    float cBCdHwQjITHApdXjTcbLTLG59118507 = -23474260;    float cBCdHwQjITHApdXjTcbLTLG68109924 = -244731817;    float cBCdHwQjITHApdXjTcbLTLG31385050 = -767414198;    float cBCdHwQjITHApdXjTcbLTLG15822994 = -726185107;    float cBCdHwQjITHApdXjTcbLTLG1519418 = -288985207;    float cBCdHwQjITHApdXjTcbLTLG14835821 = -576167273;    float cBCdHwQjITHApdXjTcbLTLG88219679 = -184223942;    float cBCdHwQjITHApdXjTcbLTLG84696629 = -579715609;    float cBCdHwQjITHApdXjTcbLTLG99135659 = -613935463;    float cBCdHwQjITHApdXjTcbLTLG6539053 = -841404600;    float cBCdHwQjITHApdXjTcbLTLG76474693 = -566566243;    float cBCdHwQjITHApdXjTcbLTLG27780023 = -155125186;    float cBCdHwQjITHApdXjTcbLTLG56805553 = -434232822;    float cBCdHwQjITHApdXjTcbLTLG90706251 = -962103398;    float cBCdHwQjITHApdXjTcbLTLG40062023 = -714865742;    float cBCdHwQjITHApdXjTcbLTLG90153184 = -656094790;    float cBCdHwQjITHApdXjTcbLTLG13910047 = 27771714;    float cBCdHwQjITHApdXjTcbLTLG49265475 = -972872391;    float cBCdHwQjITHApdXjTcbLTLG7109247 = -6871280;    float cBCdHwQjITHApdXjTcbLTLG36741927 = -411856050;    float cBCdHwQjITHApdXjTcbLTLG61896075 = -333931659;    float cBCdHwQjITHApdXjTcbLTLG52845549 = -28166065;    float cBCdHwQjITHApdXjTcbLTLG17379942 = -26546375;    float cBCdHwQjITHApdXjTcbLTLG5455907 = 98805401;    float cBCdHwQjITHApdXjTcbLTLG52298849 = -712070482;    float cBCdHwQjITHApdXjTcbLTLG12793314 = -598493971;    float cBCdHwQjITHApdXjTcbLTLG98439110 = -248076678;    float cBCdHwQjITHApdXjTcbLTLG63715938 = -646754099;    float cBCdHwQjITHApdXjTcbLTLG48615243 = -35149119;    float cBCdHwQjITHApdXjTcbLTLG78376381 = -603491180;    float cBCdHwQjITHApdXjTcbLTLG11779599 = -882944491;    float cBCdHwQjITHApdXjTcbLTLG96671912 = -981811417;    float cBCdHwQjITHApdXjTcbLTLG24335240 = -722515385;    float cBCdHwQjITHApdXjTcbLTLG75477791 = -743277591;    float cBCdHwQjITHApdXjTcbLTLG98543904 = -215656754;    float cBCdHwQjITHApdXjTcbLTLG32308297 = 35584700;    float cBCdHwQjITHApdXjTcbLTLG39790890 = -296127200;    float cBCdHwQjITHApdXjTcbLTLG4538763 = -932045451;    float cBCdHwQjITHApdXjTcbLTLG52939157 = -241247154;    float cBCdHwQjITHApdXjTcbLTLG67896120 = -311403235;     cBCdHwQjITHApdXjTcbLTLG96083381 = cBCdHwQjITHApdXjTcbLTLG23477302;     cBCdHwQjITHApdXjTcbLTLG23477302 = cBCdHwQjITHApdXjTcbLTLG74371234;     cBCdHwQjITHApdXjTcbLTLG74371234 = cBCdHwQjITHApdXjTcbLTLG33542236;     cBCdHwQjITHApdXjTcbLTLG33542236 = cBCdHwQjITHApdXjTcbLTLG84802618;     cBCdHwQjITHApdXjTcbLTLG84802618 = cBCdHwQjITHApdXjTcbLTLG97075377;     cBCdHwQjITHApdXjTcbLTLG97075377 = cBCdHwQjITHApdXjTcbLTLG35485680;     cBCdHwQjITHApdXjTcbLTLG35485680 = cBCdHwQjITHApdXjTcbLTLG44275794;     cBCdHwQjITHApdXjTcbLTLG44275794 = cBCdHwQjITHApdXjTcbLTLG88121714;     cBCdHwQjITHApdXjTcbLTLG88121714 = cBCdHwQjITHApdXjTcbLTLG21106792;     cBCdHwQjITHApdXjTcbLTLG21106792 = cBCdHwQjITHApdXjTcbLTLG17287694;     cBCdHwQjITHApdXjTcbLTLG17287694 = cBCdHwQjITHApdXjTcbLTLG24643630;     cBCdHwQjITHApdXjTcbLTLG24643630 = cBCdHwQjITHApdXjTcbLTLG38465060;     cBCdHwQjITHApdXjTcbLTLG38465060 = cBCdHwQjITHApdXjTcbLTLG39323620;     cBCdHwQjITHApdXjTcbLTLG39323620 = cBCdHwQjITHApdXjTcbLTLG38071904;     cBCdHwQjITHApdXjTcbLTLG38071904 = cBCdHwQjITHApdXjTcbLTLG57676651;     cBCdHwQjITHApdXjTcbLTLG57676651 = cBCdHwQjITHApdXjTcbLTLG98096186;     cBCdHwQjITHApdXjTcbLTLG98096186 = cBCdHwQjITHApdXjTcbLTLG76825233;     cBCdHwQjITHApdXjTcbLTLG76825233 = cBCdHwQjITHApdXjTcbLTLG48368663;     cBCdHwQjITHApdXjTcbLTLG48368663 = cBCdHwQjITHApdXjTcbLTLG40480244;     cBCdHwQjITHApdXjTcbLTLG40480244 = cBCdHwQjITHApdXjTcbLTLG61329124;     cBCdHwQjITHApdXjTcbLTLG61329124 = cBCdHwQjITHApdXjTcbLTLG34271803;     cBCdHwQjITHApdXjTcbLTLG34271803 = cBCdHwQjITHApdXjTcbLTLG3724050;     cBCdHwQjITHApdXjTcbLTLG3724050 = cBCdHwQjITHApdXjTcbLTLG89841188;     cBCdHwQjITHApdXjTcbLTLG89841188 = cBCdHwQjITHApdXjTcbLTLG87561312;     cBCdHwQjITHApdXjTcbLTLG87561312 = cBCdHwQjITHApdXjTcbLTLG40260730;     cBCdHwQjITHApdXjTcbLTLG40260730 = cBCdHwQjITHApdXjTcbLTLG37956870;     cBCdHwQjITHApdXjTcbLTLG37956870 = cBCdHwQjITHApdXjTcbLTLG67375755;     cBCdHwQjITHApdXjTcbLTLG67375755 = cBCdHwQjITHApdXjTcbLTLG12890744;     cBCdHwQjITHApdXjTcbLTLG12890744 = cBCdHwQjITHApdXjTcbLTLG72298721;     cBCdHwQjITHApdXjTcbLTLG72298721 = cBCdHwQjITHApdXjTcbLTLG19587374;     cBCdHwQjITHApdXjTcbLTLG19587374 = cBCdHwQjITHApdXjTcbLTLG2451873;     cBCdHwQjITHApdXjTcbLTLG2451873 = cBCdHwQjITHApdXjTcbLTLG36423950;     cBCdHwQjITHApdXjTcbLTLG36423950 = cBCdHwQjITHApdXjTcbLTLG53768431;     cBCdHwQjITHApdXjTcbLTLG53768431 = cBCdHwQjITHApdXjTcbLTLG40187960;     cBCdHwQjITHApdXjTcbLTLG40187960 = cBCdHwQjITHApdXjTcbLTLG31532851;     cBCdHwQjITHApdXjTcbLTLG31532851 = cBCdHwQjITHApdXjTcbLTLG81201958;     cBCdHwQjITHApdXjTcbLTLG81201958 = cBCdHwQjITHApdXjTcbLTLG70316164;     cBCdHwQjITHApdXjTcbLTLG70316164 = cBCdHwQjITHApdXjTcbLTLG20019680;     cBCdHwQjITHApdXjTcbLTLG20019680 = cBCdHwQjITHApdXjTcbLTLG57662412;     cBCdHwQjITHApdXjTcbLTLG57662412 = cBCdHwQjITHApdXjTcbLTLG418222;     cBCdHwQjITHApdXjTcbLTLG418222 = cBCdHwQjITHApdXjTcbLTLG71175940;     cBCdHwQjITHApdXjTcbLTLG71175940 = cBCdHwQjITHApdXjTcbLTLG20361756;     cBCdHwQjITHApdXjTcbLTLG20361756 = cBCdHwQjITHApdXjTcbLTLG54458575;     cBCdHwQjITHApdXjTcbLTLG54458575 = cBCdHwQjITHApdXjTcbLTLG82731941;     cBCdHwQjITHApdXjTcbLTLG82731941 = cBCdHwQjITHApdXjTcbLTLG50819386;     cBCdHwQjITHApdXjTcbLTLG50819386 = cBCdHwQjITHApdXjTcbLTLG78364655;     cBCdHwQjITHApdXjTcbLTLG78364655 = cBCdHwQjITHApdXjTcbLTLG85111320;     cBCdHwQjITHApdXjTcbLTLG85111320 = cBCdHwQjITHApdXjTcbLTLG49995814;     cBCdHwQjITHApdXjTcbLTLG49995814 = cBCdHwQjITHApdXjTcbLTLG7434837;     cBCdHwQjITHApdXjTcbLTLG7434837 = cBCdHwQjITHApdXjTcbLTLG19999873;     cBCdHwQjITHApdXjTcbLTLG19999873 = cBCdHwQjITHApdXjTcbLTLG6794060;     cBCdHwQjITHApdXjTcbLTLG6794060 = cBCdHwQjITHApdXjTcbLTLG4012762;     cBCdHwQjITHApdXjTcbLTLG4012762 = cBCdHwQjITHApdXjTcbLTLG72708012;     cBCdHwQjITHApdXjTcbLTLG72708012 = cBCdHwQjITHApdXjTcbLTLG5153188;     cBCdHwQjITHApdXjTcbLTLG5153188 = cBCdHwQjITHApdXjTcbLTLG61811578;     cBCdHwQjITHApdXjTcbLTLG61811578 = cBCdHwQjITHApdXjTcbLTLG19753252;     cBCdHwQjITHApdXjTcbLTLG19753252 = cBCdHwQjITHApdXjTcbLTLG84530045;     cBCdHwQjITHApdXjTcbLTLG84530045 = cBCdHwQjITHApdXjTcbLTLG45980924;     cBCdHwQjITHApdXjTcbLTLG45980924 = cBCdHwQjITHApdXjTcbLTLG44541888;     cBCdHwQjITHApdXjTcbLTLG44541888 = cBCdHwQjITHApdXjTcbLTLG59118507;     cBCdHwQjITHApdXjTcbLTLG59118507 = cBCdHwQjITHApdXjTcbLTLG68109924;     cBCdHwQjITHApdXjTcbLTLG68109924 = cBCdHwQjITHApdXjTcbLTLG31385050;     cBCdHwQjITHApdXjTcbLTLG31385050 = cBCdHwQjITHApdXjTcbLTLG15822994;     cBCdHwQjITHApdXjTcbLTLG15822994 = cBCdHwQjITHApdXjTcbLTLG1519418;     cBCdHwQjITHApdXjTcbLTLG1519418 = cBCdHwQjITHApdXjTcbLTLG14835821;     cBCdHwQjITHApdXjTcbLTLG14835821 = cBCdHwQjITHApdXjTcbLTLG88219679;     cBCdHwQjITHApdXjTcbLTLG88219679 = cBCdHwQjITHApdXjTcbLTLG84696629;     cBCdHwQjITHApdXjTcbLTLG84696629 = cBCdHwQjITHApdXjTcbLTLG99135659;     cBCdHwQjITHApdXjTcbLTLG99135659 = cBCdHwQjITHApdXjTcbLTLG6539053;     cBCdHwQjITHApdXjTcbLTLG6539053 = cBCdHwQjITHApdXjTcbLTLG76474693;     cBCdHwQjITHApdXjTcbLTLG76474693 = cBCdHwQjITHApdXjTcbLTLG27780023;     cBCdHwQjITHApdXjTcbLTLG27780023 = cBCdHwQjITHApdXjTcbLTLG56805553;     cBCdHwQjITHApdXjTcbLTLG56805553 = cBCdHwQjITHApdXjTcbLTLG90706251;     cBCdHwQjITHApdXjTcbLTLG90706251 = cBCdHwQjITHApdXjTcbLTLG40062023;     cBCdHwQjITHApdXjTcbLTLG40062023 = cBCdHwQjITHApdXjTcbLTLG90153184;     cBCdHwQjITHApdXjTcbLTLG90153184 = cBCdHwQjITHApdXjTcbLTLG13910047;     cBCdHwQjITHApdXjTcbLTLG13910047 = cBCdHwQjITHApdXjTcbLTLG49265475;     cBCdHwQjITHApdXjTcbLTLG49265475 = cBCdHwQjITHApdXjTcbLTLG7109247;     cBCdHwQjITHApdXjTcbLTLG7109247 = cBCdHwQjITHApdXjTcbLTLG36741927;     cBCdHwQjITHApdXjTcbLTLG36741927 = cBCdHwQjITHApdXjTcbLTLG61896075;     cBCdHwQjITHApdXjTcbLTLG61896075 = cBCdHwQjITHApdXjTcbLTLG52845549;     cBCdHwQjITHApdXjTcbLTLG52845549 = cBCdHwQjITHApdXjTcbLTLG17379942;     cBCdHwQjITHApdXjTcbLTLG17379942 = cBCdHwQjITHApdXjTcbLTLG5455907;     cBCdHwQjITHApdXjTcbLTLG5455907 = cBCdHwQjITHApdXjTcbLTLG52298849;     cBCdHwQjITHApdXjTcbLTLG52298849 = cBCdHwQjITHApdXjTcbLTLG12793314;     cBCdHwQjITHApdXjTcbLTLG12793314 = cBCdHwQjITHApdXjTcbLTLG98439110;     cBCdHwQjITHApdXjTcbLTLG98439110 = cBCdHwQjITHApdXjTcbLTLG63715938;     cBCdHwQjITHApdXjTcbLTLG63715938 = cBCdHwQjITHApdXjTcbLTLG48615243;     cBCdHwQjITHApdXjTcbLTLG48615243 = cBCdHwQjITHApdXjTcbLTLG78376381;     cBCdHwQjITHApdXjTcbLTLG78376381 = cBCdHwQjITHApdXjTcbLTLG11779599;     cBCdHwQjITHApdXjTcbLTLG11779599 = cBCdHwQjITHApdXjTcbLTLG96671912;     cBCdHwQjITHApdXjTcbLTLG96671912 = cBCdHwQjITHApdXjTcbLTLG24335240;     cBCdHwQjITHApdXjTcbLTLG24335240 = cBCdHwQjITHApdXjTcbLTLG75477791;     cBCdHwQjITHApdXjTcbLTLG75477791 = cBCdHwQjITHApdXjTcbLTLG98543904;     cBCdHwQjITHApdXjTcbLTLG98543904 = cBCdHwQjITHApdXjTcbLTLG32308297;     cBCdHwQjITHApdXjTcbLTLG32308297 = cBCdHwQjITHApdXjTcbLTLG39790890;     cBCdHwQjITHApdXjTcbLTLG39790890 = cBCdHwQjITHApdXjTcbLTLG4538763;     cBCdHwQjITHApdXjTcbLTLG4538763 = cBCdHwQjITHApdXjTcbLTLG52939157;     cBCdHwQjITHApdXjTcbLTLG52939157 = cBCdHwQjITHApdXjTcbLTLG67896120;     cBCdHwQjITHApdXjTcbLTLG67896120 = cBCdHwQjITHApdXjTcbLTLG96083381;}



void rFsrpVFXwVQxKvZWydNfChUFjQ51545150() {     float VSNoTeDrRkAEhhlqUhOztuj79806899 = -661425302;    float VSNoTeDrRkAEhhlqUhOztuj21075398 = -873303569;    float VSNoTeDrRkAEhhlqUhOztuj62957351 = 77424571;    float VSNoTeDrRkAEhhlqUhOztuj30690190 = -526857561;    float VSNoTeDrRkAEhhlqUhOztuj64363955 = 42613387;    float VSNoTeDrRkAEhhlqUhOztuj8414895 = -88902320;    float VSNoTeDrRkAEhhlqUhOztuj72366242 = -471640570;    float VSNoTeDrRkAEhhlqUhOztuj87615876 = -374082971;    float VSNoTeDrRkAEhhlqUhOztuj38341243 = -238376821;    float VSNoTeDrRkAEhhlqUhOztuj67212380 = 41959019;    float VSNoTeDrRkAEhhlqUhOztuj60176729 = -313368409;    float VSNoTeDrRkAEhhlqUhOztuj14855401 = -153773723;    float VSNoTeDrRkAEhhlqUhOztuj89518912 = 8796541;    float VSNoTeDrRkAEhhlqUhOztuj33696764 = -148053896;    float VSNoTeDrRkAEhhlqUhOztuj42251163 = -16593361;    float VSNoTeDrRkAEhhlqUhOztuj29490680 = -855125113;    float VSNoTeDrRkAEhhlqUhOztuj97961597 = -600850057;    float VSNoTeDrRkAEhhlqUhOztuj90902502 = -325630999;    float VSNoTeDrRkAEhhlqUhOztuj89345143 = -89883648;    float VSNoTeDrRkAEhhlqUhOztuj14587889 = -740305774;    float VSNoTeDrRkAEhhlqUhOztuj28668635 = -394102708;    float VSNoTeDrRkAEhhlqUhOztuj35273874 = -643614130;    float VSNoTeDrRkAEhhlqUhOztuj72899915 = -632499488;    float VSNoTeDrRkAEhhlqUhOztuj90983883 = -310880589;    float VSNoTeDrRkAEhhlqUhOztuj24163406 = -35976770;    float VSNoTeDrRkAEhhlqUhOztuj93253488 = -565136437;    float VSNoTeDrRkAEhhlqUhOztuj59548809 = -305982815;    float VSNoTeDrRkAEhhlqUhOztuj9974956 = -991836104;    float VSNoTeDrRkAEhhlqUhOztuj84808885 = -510410088;    float VSNoTeDrRkAEhhlqUhOztuj7847049 = -487315392;    float VSNoTeDrRkAEhhlqUhOztuj951797 = -665112779;    float VSNoTeDrRkAEhhlqUhOztuj27245161 = -346113101;    float VSNoTeDrRkAEhhlqUhOztuj50548651 = -605624602;    float VSNoTeDrRkAEhhlqUhOztuj89493145 = -972752255;    float VSNoTeDrRkAEhhlqUhOztuj7791285 = 81273821;    float VSNoTeDrRkAEhhlqUhOztuj1394085 = -227887934;    float VSNoTeDrRkAEhhlqUhOztuj80965548 = -584772516;    float VSNoTeDrRkAEhhlqUhOztuj20697955 = -85988226;    float VSNoTeDrRkAEhhlqUhOztuj80635398 = -486105485;    float VSNoTeDrRkAEhhlqUhOztuj96851527 = -285777892;    float VSNoTeDrRkAEhhlqUhOztuj65185742 = 40812758;    float VSNoTeDrRkAEhhlqUhOztuj515667 = -769567067;    float VSNoTeDrRkAEhhlqUhOztuj53161902 = -310634812;    float VSNoTeDrRkAEhhlqUhOztuj1654095 = -209176094;    float VSNoTeDrRkAEhhlqUhOztuj10719193 = -990790734;    float VSNoTeDrRkAEhhlqUhOztuj95086267 = -160821651;    float VSNoTeDrRkAEhhlqUhOztuj11543625 = -809883658;    float VSNoTeDrRkAEhhlqUhOztuj23853168 = -596063226;    float VSNoTeDrRkAEhhlqUhOztuj83870027 = -778632392;    float VSNoTeDrRkAEhhlqUhOztuj43308167 = -617035024;    float VSNoTeDrRkAEhhlqUhOztuj60090704 = -268410938;    float VSNoTeDrRkAEhhlqUhOztuj58299779 = -599573574;    float VSNoTeDrRkAEhhlqUhOztuj49395164 = -560771567;    float VSNoTeDrRkAEhhlqUhOztuj18640618 = -870365600;    float VSNoTeDrRkAEhhlqUhOztuj22876516 = -750233434;    float VSNoTeDrRkAEhhlqUhOztuj44533025 = 82188827;    float VSNoTeDrRkAEhhlqUhOztuj48175482 = -140804081;    float VSNoTeDrRkAEhhlqUhOztuj71973468 = -611694841;    float VSNoTeDrRkAEhhlqUhOztuj6526784 = -390880792;    float VSNoTeDrRkAEhhlqUhOztuj71110467 = -392250177;    float VSNoTeDrRkAEhhlqUhOztuj48866086 = -782919505;    float VSNoTeDrRkAEhhlqUhOztuj62391287 = -479804466;    float VSNoTeDrRkAEhhlqUhOztuj2806992 = -863672884;    float VSNoTeDrRkAEhhlqUhOztuj30494195 = -751061429;    float VSNoTeDrRkAEhhlqUhOztuj66260583 = -292928202;    float VSNoTeDrRkAEhhlqUhOztuj32931569 = -967255309;    float VSNoTeDrRkAEhhlqUhOztuj64306749 = -548149122;    float VSNoTeDrRkAEhhlqUhOztuj25768 = -18451204;    float VSNoTeDrRkAEhhlqUhOztuj25905479 = -129327718;    float VSNoTeDrRkAEhhlqUhOztuj40857078 = -788705428;    float VSNoTeDrRkAEhhlqUhOztuj48525132 = -170352598;    float VSNoTeDrRkAEhhlqUhOztuj77263642 = -414861832;    float VSNoTeDrRkAEhhlqUhOztuj10267104 = -839525514;    float VSNoTeDrRkAEhhlqUhOztuj92493616 = -804105756;    float VSNoTeDrRkAEhhlqUhOztuj49402147 = -681118532;    float VSNoTeDrRkAEhhlqUhOztuj28152968 = -624535642;    float VSNoTeDrRkAEhhlqUhOztuj82111971 = -232979318;    float VSNoTeDrRkAEhhlqUhOztuj71245820 = -323323395;    float VSNoTeDrRkAEhhlqUhOztuj80264691 = -320089855;    float VSNoTeDrRkAEhhlqUhOztuj29077138 = -875155120;    float VSNoTeDrRkAEhhlqUhOztuj81709863 = -755252780;    float VSNoTeDrRkAEhhlqUhOztuj35695642 = -709919590;    float VSNoTeDrRkAEhhlqUhOztuj26104929 = -113203712;    float VSNoTeDrRkAEhhlqUhOztuj41500719 = -893375064;    float VSNoTeDrRkAEhhlqUhOztuj47756344 = -118904455;    float VSNoTeDrRkAEhhlqUhOztuj42652017 = 34460795;    float VSNoTeDrRkAEhhlqUhOztuj77849996 = -785341534;    float VSNoTeDrRkAEhhlqUhOztuj31908034 = -735259002;    float VSNoTeDrRkAEhhlqUhOztuj66616629 = -122518822;    float VSNoTeDrRkAEhhlqUhOztuj63258260 = 99084993;    float VSNoTeDrRkAEhhlqUhOztuj53218602 = 12916146;    float VSNoTeDrRkAEhhlqUhOztuj8992081 = -973077676;    float VSNoTeDrRkAEhhlqUhOztuj14171171 = -695107435;    float VSNoTeDrRkAEhhlqUhOztuj9524932 = 6144691;    float VSNoTeDrRkAEhhlqUhOztuj47985442 = -502858387;    float VSNoTeDrRkAEhhlqUhOztuj2794456 = -479382777;    float VSNoTeDrRkAEhhlqUhOztuj97708675 = -905894183;    float VSNoTeDrRkAEhhlqUhOztuj22667708 = -559573384;    float VSNoTeDrRkAEhhlqUhOztuj35393512 = -916247892;    float VSNoTeDrRkAEhhlqUhOztuj77787623 = -661425302;     VSNoTeDrRkAEhhlqUhOztuj79806899 = VSNoTeDrRkAEhhlqUhOztuj21075398;     VSNoTeDrRkAEhhlqUhOztuj21075398 = VSNoTeDrRkAEhhlqUhOztuj62957351;     VSNoTeDrRkAEhhlqUhOztuj62957351 = VSNoTeDrRkAEhhlqUhOztuj30690190;     VSNoTeDrRkAEhhlqUhOztuj30690190 = VSNoTeDrRkAEhhlqUhOztuj64363955;     VSNoTeDrRkAEhhlqUhOztuj64363955 = VSNoTeDrRkAEhhlqUhOztuj8414895;     VSNoTeDrRkAEhhlqUhOztuj8414895 = VSNoTeDrRkAEhhlqUhOztuj72366242;     VSNoTeDrRkAEhhlqUhOztuj72366242 = VSNoTeDrRkAEhhlqUhOztuj87615876;     VSNoTeDrRkAEhhlqUhOztuj87615876 = VSNoTeDrRkAEhhlqUhOztuj38341243;     VSNoTeDrRkAEhhlqUhOztuj38341243 = VSNoTeDrRkAEhhlqUhOztuj67212380;     VSNoTeDrRkAEhhlqUhOztuj67212380 = VSNoTeDrRkAEhhlqUhOztuj60176729;     VSNoTeDrRkAEhhlqUhOztuj60176729 = VSNoTeDrRkAEhhlqUhOztuj14855401;     VSNoTeDrRkAEhhlqUhOztuj14855401 = VSNoTeDrRkAEhhlqUhOztuj89518912;     VSNoTeDrRkAEhhlqUhOztuj89518912 = VSNoTeDrRkAEhhlqUhOztuj33696764;     VSNoTeDrRkAEhhlqUhOztuj33696764 = VSNoTeDrRkAEhhlqUhOztuj42251163;     VSNoTeDrRkAEhhlqUhOztuj42251163 = VSNoTeDrRkAEhhlqUhOztuj29490680;     VSNoTeDrRkAEhhlqUhOztuj29490680 = VSNoTeDrRkAEhhlqUhOztuj97961597;     VSNoTeDrRkAEhhlqUhOztuj97961597 = VSNoTeDrRkAEhhlqUhOztuj90902502;     VSNoTeDrRkAEhhlqUhOztuj90902502 = VSNoTeDrRkAEhhlqUhOztuj89345143;     VSNoTeDrRkAEhhlqUhOztuj89345143 = VSNoTeDrRkAEhhlqUhOztuj14587889;     VSNoTeDrRkAEhhlqUhOztuj14587889 = VSNoTeDrRkAEhhlqUhOztuj28668635;     VSNoTeDrRkAEhhlqUhOztuj28668635 = VSNoTeDrRkAEhhlqUhOztuj35273874;     VSNoTeDrRkAEhhlqUhOztuj35273874 = VSNoTeDrRkAEhhlqUhOztuj72899915;     VSNoTeDrRkAEhhlqUhOztuj72899915 = VSNoTeDrRkAEhhlqUhOztuj90983883;     VSNoTeDrRkAEhhlqUhOztuj90983883 = VSNoTeDrRkAEhhlqUhOztuj24163406;     VSNoTeDrRkAEhhlqUhOztuj24163406 = VSNoTeDrRkAEhhlqUhOztuj93253488;     VSNoTeDrRkAEhhlqUhOztuj93253488 = VSNoTeDrRkAEhhlqUhOztuj59548809;     VSNoTeDrRkAEhhlqUhOztuj59548809 = VSNoTeDrRkAEhhlqUhOztuj9974956;     VSNoTeDrRkAEhhlqUhOztuj9974956 = VSNoTeDrRkAEhhlqUhOztuj84808885;     VSNoTeDrRkAEhhlqUhOztuj84808885 = VSNoTeDrRkAEhhlqUhOztuj7847049;     VSNoTeDrRkAEhhlqUhOztuj7847049 = VSNoTeDrRkAEhhlqUhOztuj951797;     VSNoTeDrRkAEhhlqUhOztuj951797 = VSNoTeDrRkAEhhlqUhOztuj27245161;     VSNoTeDrRkAEhhlqUhOztuj27245161 = VSNoTeDrRkAEhhlqUhOztuj50548651;     VSNoTeDrRkAEhhlqUhOztuj50548651 = VSNoTeDrRkAEhhlqUhOztuj89493145;     VSNoTeDrRkAEhhlqUhOztuj89493145 = VSNoTeDrRkAEhhlqUhOztuj7791285;     VSNoTeDrRkAEhhlqUhOztuj7791285 = VSNoTeDrRkAEhhlqUhOztuj1394085;     VSNoTeDrRkAEhhlqUhOztuj1394085 = VSNoTeDrRkAEhhlqUhOztuj80965548;     VSNoTeDrRkAEhhlqUhOztuj80965548 = VSNoTeDrRkAEhhlqUhOztuj20697955;     VSNoTeDrRkAEhhlqUhOztuj20697955 = VSNoTeDrRkAEhhlqUhOztuj80635398;     VSNoTeDrRkAEhhlqUhOztuj80635398 = VSNoTeDrRkAEhhlqUhOztuj96851527;     VSNoTeDrRkAEhhlqUhOztuj96851527 = VSNoTeDrRkAEhhlqUhOztuj65185742;     VSNoTeDrRkAEhhlqUhOztuj65185742 = VSNoTeDrRkAEhhlqUhOztuj515667;     VSNoTeDrRkAEhhlqUhOztuj515667 = VSNoTeDrRkAEhhlqUhOztuj53161902;     VSNoTeDrRkAEhhlqUhOztuj53161902 = VSNoTeDrRkAEhhlqUhOztuj1654095;     VSNoTeDrRkAEhhlqUhOztuj1654095 = VSNoTeDrRkAEhhlqUhOztuj10719193;     VSNoTeDrRkAEhhlqUhOztuj10719193 = VSNoTeDrRkAEhhlqUhOztuj95086267;     VSNoTeDrRkAEhhlqUhOztuj95086267 = VSNoTeDrRkAEhhlqUhOztuj11543625;     VSNoTeDrRkAEhhlqUhOztuj11543625 = VSNoTeDrRkAEhhlqUhOztuj23853168;     VSNoTeDrRkAEhhlqUhOztuj23853168 = VSNoTeDrRkAEhhlqUhOztuj83870027;     VSNoTeDrRkAEhhlqUhOztuj83870027 = VSNoTeDrRkAEhhlqUhOztuj43308167;     VSNoTeDrRkAEhhlqUhOztuj43308167 = VSNoTeDrRkAEhhlqUhOztuj60090704;     VSNoTeDrRkAEhhlqUhOztuj60090704 = VSNoTeDrRkAEhhlqUhOztuj58299779;     VSNoTeDrRkAEhhlqUhOztuj58299779 = VSNoTeDrRkAEhhlqUhOztuj49395164;     VSNoTeDrRkAEhhlqUhOztuj49395164 = VSNoTeDrRkAEhhlqUhOztuj18640618;     VSNoTeDrRkAEhhlqUhOztuj18640618 = VSNoTeDrRkAEhhlqUhOztuj22876516;     VSNoTeDrRkAEhhlqUhOztuj22876516 = VSNoTeDrRkAEhhlqUhOztuj44533025;     VSNoTeDrRkAEhhlqUhOztuj44533025 = VSNoTeDrRkAEhhlqUhOztuj48175482;     VSNoTeDrRkAEhhlqUhOztuj48175482 = VSNoTeDrRkAEhhlqUhOztuj71973468;     VSNoTeDrRkAEhhlqUhOztuj71973468 = VSNoTeDrRkAEhhlqUhOztuj6526784;     VSNoTeDrRkAEhhlqUhOztuj6526784 = VSNoTeDrRkAEhhlqUhOztuj71110467;     VSNoTeDrRkAEhhlqUhOztuj71110467 = VSNoTeDrRkAEhhlqUhOztuj48866086;     VSNoTeDrRkAEhhlqUhOztuj48866086 = VSNoTeDrRkAEhhlqUhOztuj62391287;     VSNoTeDrRkAEhhlqUhOztuj62391287 = VSNoTeDrRkAEhhlqUhOztuj2806992;     VSNoTeDrRkAEhhlqUhOztuj2806992 = VSNoTeDrRkAEhhlqUhOztuj30494195;     VSNoTeDrRkAEhhlqUhOztuj30494195 = VSNoTeDrRkAEhhlqUhOztuj66260583;     VSNoTeDrRkAEhhlqUhOztuj66260583 = VSNoTeDrRkAEhhlqUhOztuj32931569;     VSNoTeDrRkAEhhlqUhOztuj32931569 = VSNoTeDrRkAEhhlqUhOztuj64306749;     VSNoTeDrRkAEhhlqUhOztuj64306749 = VSNoTeDrRkAEhhlqUhOztuj25768;     VSNoTeDrRkAEhhlqUhOztuj25768 = VSNoTeDrRkAEhhlqUhOztuj25905479;     VSNoTeDrRkAEhhlqUhOztuj25905479 = VSNoTeDrRkAEhhlqUhOztuj40857078;     VSNoTeDrRkAEhhlqUhOztuj40857078 = VSNoTeDrRkAEhhlqUhOztuj48525132;     VSNoTeDrRkAEhhlqUhOztuj48525132 = VSNoTeDrRkAEhhlqUhOztuj77263642;     VSNoTeDrRkAEhhlqUhOztuj77263642 = VSNoTeDrRkAEhhlqUhOztuj10267104;     VSNoTeDrRkAEhhlqUhOztuj10267104 = VSNoTeDrRkAEhhlqUhOztuj92493616;     VSNoTeDrRkAEhhlqUhOztuj92493616 = VSNoTeDrRkAEhhlqUhOztuj49402147;     VSNoTeDrRkAEhhlqUhOztuj49402147 = VSNoTeDrRkAEhhlqUhOztuj28152968;     VSNoTeDrRkAEhhlqUhOztuj28152968 = VSNoTeDrRkAEhhlqUhOztuj82111971;     VSNoTeDrRkAEhhlqUhOztuj82111971 = VSNoTeDrRkAEhhlqUhOztuj71245820;     VSNoTeDrRkAEhhlqUhOztuj71245820 = VSNoTeDrRkAEhhlqUhOztuj80264691;     VSNoTeDrRkAEhhlqUhOztuj80264691 = VSNoTeDrRkAEhhlqUhOztuj29077138;     VSNoTeDrRkAEhhlqUhOztuj29077138 = VSNoTeDrRkAEhhlqUhOztuj81709863;     VSNoTeDrRkAEhhlqUhOztuj81709863 = VSNoTeDrRkAEhhlqUhOztuj35695642;     VSNoTeDrRkAEhhlqUhOztuj35695642 = VSNoTeDrRkAEhhlqUhOztuj26104929;     VSNoTeDrRkAEhhlqUhOztuj26104929 = VSNoTeDrRkAEhhlqUhOztuj41500719;     VSNoTeDrRkAEhhlqUhOztuj41500719 = VSNoTeDrRkAEhhlqUhOztuj47756344;     VSNoTeDrRkAEhhlqUhOztuj47756344 = VSNoTeDrRkAEhhlqUhOztuj42652017;     VSNoTeDrRkAEhhlqUhOztuj42652017 = VSNoTeDrRkAEhhlqUhOztuj77849996;     VSNoTeDrRkAEhhlqUhOztuj77849996 = VSNoTeDrRkAEhhlqUhOztuj31908034;     VSNoTeDrRkAEhhlqUhOztuj31908034 = VSNoTeDrRkAEhhlqUhOztuj66616629;     VSNoTeDrRkAEhhlqUhOztuj66616629 = VSNoTeDrRkAEhhlqUhOztuj63258260;     VSNoTeDrRkAEhhlqUhOztuj63258260 = VSNoTeDrRkAEhhlqUhOztuj53218602;     VSNoTeDrRkAEhhlqUhOztuj53218602 = VSNoTeDrRkAEhhlqUhOztuj8992081;     VSNoTeDrRkAEhhlqUhOztuj8992081 = VSNoTeDrRkAEhhlqUhOztuj14171171;     VSNoTeDrRkAEhhlqUhOztuj14171171 = VSNoTeDrRkAEhhlqUhOztuj9524932;     VSNoTeDrRkAEhhlqUhOztuj9524932 = VSNoTeDrRkAEhhlqUhOztuj47985442;     VSNoTeDrRkAEhhlqUhOztuj47985442 = VSNoTeDrRkAEhhlqUhOztuj2794456;     VSNoTeDrRkAEhhlqUhOztuj2794456 = VSNoTeDrRkAEhhlqUhOztuj97708675;     VSNoTeDrRkAEhhlqUhOztuj97708675 = VSNoTeDrRkAEhhlqUhOztuj22667708;     VSNoTeDrRkAEhhlqUhOztuj22667708 = VSNoTeDrRkAEhhlqUhOztuj35393512;     VSNoTeDrRkAEhhlqUhOztuj35393512 = VSNoTeDrRkAEhhlqUhOztuj77787623;     VSNoTeDrRkAEhhlqUhOztuj77787623 = VSNoTeDrRkAEhhlqUhOztuj79806899;}



void kNOtFFfOlnHHzSAmLhiYiwaeVz36607988() {     float pDGzqEdEENjyAujEoefuorm63530417 = 88552631;    float pDGzqEdEENjyAujEoefuorm18673493 = -676955420;    float pDGzqEdEENjyAujEoefuorm51543468 = -890883119;    float pDGzqEdEENjyAujEoefuorm27838143 = -531739490;    float pDGzqEdEENjyAujEoefuorm43925292 = -355334804;    float pDGzqEdEENjyAujEoefuorm19754413 = -192222989;    float pDGzqEdEENjyAujEoefuorm9246806 = -493154708;    float pDGzqEdEENjyAujEoefuorm30955960 = -994537557;    float pDGzqEdEENjyAujEoefuorm88560771 = -935859517;    float pDGzqEdEENjyAujEoefuorm13317969 = -181081997;    float pDGzqEdEENjyAujEoefuorm3065766 = -153653667;    float pDGzqEdEENjyAujEoefuorm5067171 = -82912994;    float pDGzqEdEENjyAujEoefuorm40572764 = -934035703;    float pDGzqEdEENjyAujEoefuorm28069909 = -497736759;    float pDGzqEdEENjyAujEoefuorm46430421 = 57709334;    float pDGzqEdEENjyAujEoefuorm1304709 = -779252765;    float pDGzqEdEENjyAujEoefuorm97827007 = -759729920;    float pDGzqEdEENjyAujEoefuorm4979773 = 63517427;    float pDGzqEdEENjyAujEoefuorm30321625 = -978532887;    float pDGzqEdEENjyAujEoefuorm88695533 = -356598691;    float pDGzqEdEENjyAujEoefuorm96008145 = 31430771;    float pDGzqEdEENjyAujEoefuorm36275945 = -556769416;    float pDGzqEdEENjyAujEoefuorm42075781 = -661894225;    float pDGzqEdEENjyAujEoefuorm92126578 = -950113242;    float pDGzqEdEENjyAujEoefuorm60765498 = -114307531;    float pDGzqEdEENjyAujEoefuorm46246246 = 91896536;    float pDGzqEdEENjyAujEoefuorm81140748 = -749858238;    float pDGzqEdEENjyAujEoefuorm52574156 = -778277592;    float pDGzqEdEENjyAujEoefuorm56727027 = 65394012;    float pDGzqEdEENjyAujEoefuorm43395376 = -59921767;    float pDGzqEdEENjyAujEoefuorm82316219 = -884210800;    float pDGzqEdEENjyAujEoefuorm52038449 = -895310323;    float pDGzqEdEENjyAujEoefuorm64673352 = -170838693;    float pDGzqEdEENjyAujEoefuorm25217859 = -276848903;    float pDGzqEdEENjyAujEoefuorm75394610 = -753016787;    float pDGzqEdEENjyAujEoefuorm71255318 = -206284411;    float pDGzqEdEENjyAujEoefuorm80729138 = -905113812;    float pDGzqEdEENjyAujEoefuorm71079746 = 14868557;    float pDGzqEdEENjyAujEoefuorm41251118 = -791664366;    float pDGzqEdEENjyAujEoefuorm36040644 = -232424772;    float pDGzqEdEENjyAujEoefuorm29953263 = -709227369;    float pDGzqEdEENjyAujEoefuorm29855394 = -375592736;    float pDGzqEdEENjyAujEoefuorm85962048 = 36960934;    float pDGzqEdEENjyAujEoefuorm48849614 = -888119826;    float pDGzqEdEENjyAujEoefuorm38706443 = -216804812;    float pDGzqEdEENjyAujEoefuorm39353149 = -875853342;    float pDGzqEdEENjyAujEoefuorm44722594 = -831529565;    float pDGzqEdEENjyAujEoefuorm62595015 = -358185123;    float pDGzqEdEENjyAujEoefuorm17744241 = -478416544;    float pDGzqEdEENjyAujEoefuorm79181497 = -149050460;    float pDGzqEdEENjyAujEoefuorm181536 = -434183339;    float pDGzqEdEENjyAujEoefuorm9805500 = -351626361;    float pDGzqEdEENjyAujEoefuorm94777566 = -572703933;    float pDGzqEdEENjyAujEoefuorm64573223 = -347074788;    float pDGzqEdEENjyAujEoefuorm40599843 = 33039621;    float pDGzqEdEENjyAujEoefuorm27254472 = -354677954;    float pDGzqEdEENjyAujEoefuorm76597712 = 84938805;    float pDGzqEdEENjyAujEoefuorm59416890 = -940769878;    float pDGzqEdEENjyAujEoefuorm67072644 = -317431959;    float pDGzqEdEENjyAujEoefuorm97679045 = -347231340;    float pDGzqEdEENjyAujEoefuorm38613664 = -442364751;    float pDGzqEdEENjyAujEoefuorm56672650 = -714877116;    float pDGzqEdEENjyAujEoefuorm74228932 = -959931570;    float pDGzqEdEENjyAujEoefuorm45165396 = -775937751;    float pDGzqEdEENjyAujEoefuorm31001749 = -296871197;    float pDGzqEdEENjyAujEoefuorm51027316 = -258343344;    float pDGzqEdEENjyAujEoefuorm40393818 = -912074302;    float pDGzqEdEENjyAujEoefuorm15354905 = -557186800;    float pDGzqEdEENjyAujEoefuorm52675298 = -744719973;    float pDGzqEdEENjyAujEoefuorm75175103 = -736006255;    float pDGzqEdEENjyAujEoefuorm20575570 = -874138953;    float pDGzqEdEENjyAujEoefuorm26747262 = -674598478;    float pDGzqEdEENjyAujEoefuorm63728654 = -144818207;    float pDGzqEdEENjyAujEoefuorm94280980 = -646108115;    float pDGzqEdEENjyAujEoefuorm58742270 = -647371323;    float pDGzqEdEENjyAujEoefuorm66152752 = -592976493;    float pDGzqEdEENjyAujEoefuorm50313896 = -493730350;    float pDGzqEdEENjyAujEoefuorm93226166 = -773774399;    float pDGzqEdEENjyAujEoefuorm53420136 = -633308430;    float pDGzqEdEENjyAujEoefuorm21412350 = -238454189;    float pDGzqEdEENjyAujEoefuorm1523652 = -76573900;    float pDGzqEdEENjyAujEoefuorm18545734 = -291673115;    float pDGzqEdEENjyAujEoefuorm34829915 = -199861049;    float pDGzqEdEENjyAujEoefuorm77545530 = -785555529;    float pDGzqEdEENjyAujEoefuorm43213840 = -625738428;    float pDGzqEdEENjyAujEoefuorm72510720 = -432584440;    float pDGzqEdEENjyAujEoefuorm57260882 = -222606391;    float pDGzqEdEENjyAujEoefuorm100129 = -823763906;    float pDGzqEdEENjyAujEoefuorm84618016 = -209888525;    float pDGzqEdEENjyAujEoefuorm48140138 = -298338833;    float pDGzqEdEENjyAujEoefuorm94657605 = -191223217;    float pDGzqEdEENjyAujEoefuorm21312249 = -964343935;    float pDGzqEdEENjyAujEoefuorm4007102 = -667699484;    float pDGzqEdEENjyAujEoefuorm43572072 = -344433026;    float pDGzqEdEENjyAujEoefuorm97426979 = -790060021;    float pDGzqEdEENjyAujEoefuorm73280613 = -994350253;    float pDGzqEdEENjyAujEoefuorm55626461 = -415661167;    float pDGzqEdEENjyAujEoefuorm40796653 = -187101316;    float pDGzqEdEENjyAujEoefuorm17847866 = -491248629;    float pDGzqEdEENjyAujEoefuorm87679126 = 88552631;     pDGzqEdEENjyAujEoefuorm63530417 = pDGzqEdEENjyAujEoefuorm18673493;     pDGzqEdEENjyAujEoefuorm18673493 = pDGzqEdEENjyAujEoefuorm51543468;     pDGzqEdEENjyAujEoefuorm51543468 = pDGzqEdEENjyAujEoefuorm27838143;     pDGzqEdEENjyAujEoefuorm27838143 = pDGzqEdEENjyAujEoefuorm43925292;     pDGzqEdEENjyAujEoefuorm43925292 = pDGzqEdEENjyAujEoefuorm19754413;     pDGzqEdEENjyAujEoefuorm19754413 = pDGzqEdEENjyAujEoefuorm9246806;     pDGzqEdEENjyAujEoefuorm9246806 = pDGzqEdEENjyAujEoefuorm30955960;     pDGzqEdEENjyAujEoefuorm30955960 = pDGzqEdEENjyAujEoefuorm88560771;     pDGzqEdEENjyAujEoefuorm88560771 = pDGzqEdEENjyAujEoefuorm13317969;     pDGzqEdEENjyAujEoefuorm13317969 = pDGzqEdEENjyAujEoefuorm3065766;     pDGzqEdEENjyAujEoefuorm3065766 = pDGzqEdEENjyAujEoefuorm5067171;     pDGzqEdEENjyAujEoefuorm5067171 = pDGzqEdEENjyAujEoefuorm40572764;     pDGzqEdEENjyAujEoefuorm40572764 = pDGzqEdEENjyAujEoefuorm28069909;     pDGzqEdEENjyAujEoefuorm28069909 = pDGzqEdEENjyAujEoefuorm46430421;     pDGzqEdEENjyAujEoefuorm46430421 = pDGzqEdEENjyAujEoefuorm1304709;     pDGzqEdEENjyAujEoefuorm1304709 = pDGzqEdEENjyAujEoefuorm97827007;     pDGzqEdEENjyAujEoefuorm97827007 = pDGzqEdEENjyAujEoefuorm4979773;     pDGzqEdEENjyAujEoefuorm4979773 = pDGzqEdEENjyAujEoefuorm30321625;     pDGzqEdEENjyAujEoefuorm30321625 = pDGzqEdEENjyAujEoefuorm88695533;     pDGzqEdEENjyAujEoefuorm88695533 = pDGzqEdEENjyAujEoefuorm96008145;     pDGzqEdEENjyAujEoefuorm96008145 = pDGzqEdEENjyAujEoefuorm36275945;     pDGzqEdEENjyAujEoefuorm36275945 = pDGzqEdEENjyAujEoefuorm42075781;     pDGzqEdEENjyAujEoefuorm42075781 = pDGzqEdEENjyAujEoefuorm92126578;     pDGzqEdEENjyAujEoefuorm92126578 = pDGzqEdEENjyAujEoefuorm60765498;     pDGzqEdEENjyAujEoefuorm60765498 = pDGzqEdEENjyAujEoefuorm46246246;     pDGzqEdEENjyAujEoefuorm46246246 = pDGzqEdEENjyAujEoefuorm81140748;     pDGzqEdEENjyAujEoefuorm81140748 = pDGzqEdEENjyAujEoefuorm52574156;     pDGzqEdEENjyAujEoefuorm52574156 = pDGzqEdEENjyAujEoefuorm56727027;     pDGzqEdEENjyAujEoefuorm56727027 = pDGzqEdEENjyAujEoefuorm43395376;     pDGzqEdEENjyAujEoefuorm43395376 = pDGzqEdEENjyAujEoefuorm82316219;     pDGzqEdEENjyAujEoefuorm82316219 = pDGzqEdEENjyAujEoefuorm52038449;     pDGzqEdEENjyAujEoefuorm52038449 = pDGzqEdEENjyAujEoefuorm64673352;     pDGzqEdEENjyAujEoefuorm64673352 = pDGzqEdEENjyAujEoefuorm25217859;     pDGzqEdEENjyAujEoefuorm25217859 = pDGzqEdEENjyAujEoefuorm75394610;     pDGzqEdEENjyAujEoefuorm75394610 = pDGzqEdEENjyAujEoefuorm71255318;     pDGzqEdEENjyAujEoefuorm71255318 = pDGzqEdEENjyAujEoefuorm80729138;     pDGzqEdEENjyAujEoefuorm80729138 = pDGzqEdEENjyAujEoefuorm71079746;     pDGzqEdEENjyAujEoefuorm71079746 = pDGzqEdEENjyAujEoefuorm41251118;     pDGzqEdEENjyAujEoefuorm41251118 = pDGzqEdEENjyAujEoefuorm36040644;     pDGzqEdEENjyAujEoefuorm36040644 = pDGzqEdEENjyAujEoefuorm29953263;     pDGzqEdEENjyAujEoefuorm29953263 = pDGzqEdEENjyAujEoefuorm29855394;     pDGzqEdEENjyAujEoefuorm29855394 = pDGzqEdEENjyAujEoefuorm85962048;     pDGzqEdEENjyAujEoefuorm85962048 = pDGzqEdEENjyAujEoefuorm48849614;     pDGzqEdEENjyAujEoefuorm48849614 = pDGzqEdEENjyAujEoefuorm38706443;     pDGzqEdEENjyAujEoefuorm38706443 = pDGzqEdEENjyAujEoefuorm39353149;     pDGzqEdEENjyAujEoefuorm39353149 = pDGzqEdEENjyAujEoefuorm44722594;     pDGzqEdEENjyAujEoefuorm44722594 = pDGzqEdEENjyAujEoefuorm62595015;     pDGzqEdEENjyAujEoefuorm62595015 = pDGzqEdEENjyAujEoefuorm17744241;     pDGzqEdEENjyAujEoefuorm17744241 = pDGzqEdEENjyAujEoefuorm79181497;     pDGzqEdEENjyAujEoefuorm79181497 = pDGzqEdEENjyAujEoefuorm181536;     pDGzqEdEENjyAujEoefuorm181536 = pDGzqEdEENjyAujEoefuorm9805500;     pDGzqEdEENjyAujEoefuorm9805500 = pDGzqEdEENjyAujEoefuorm94777566;     pDGzqEdEENjyAujEoefuorm94777566 = pDGzqEdEENjyAujEoefuorm64573223;     pDGzqEdEENjyAujEoefuorm64573223 = pDGzqEdEENjyAujEoefuorm40599843;     pDGzqEdEENjyAujEoefuorm40599843 = pDGzqEdEENjyAujEoefuorm27254472;     pDGzqEdEENjyAujEoefuorm27254472 = pDGzqEdEENjyAujEoefuorm76597712;     pDGzqEdEENjyAujEoefuorm76597712 = pDGzqEdEENjyAujEoefuorm59416890;     pDGzqEdEENjyAujEoefuorm59416890 = pDGzqEdEENjyAujEoefuorm67072644;     pDGzqEdEENjyAujEoefuorm67072644 = pDGzqEdEENjyAujEoefuorm97679045;     pDGzqEdEENjyAujEoefuorm97679045 = pDGzqEdEENjyAujEoefuorm38613664;     pDGzqEdEENjyAujEoefuorm38613664 = pDGzqEdEENjyAujEoefuorm56672650;     pDGzqEdEENjyAujEoefuorm56672650 = pDGzqEdEENjyAujEoefuorm74228932;     pDGzqEdEENjyAujEoefuorm74228932 = pDGzqEdEENjyAujEoefuorm45165396;     pDGzqEdEENjyAujEoefuorm45165396 = pDGzqEdEENjyAujEoefuorm31001749;     pDGzqEdEENjyAujEoefuorm31001749 = pDGzqEdEENjyAujEoefuorm51027316;     pDGzqEdEENjyAujEoefuorm51027316 = pDGzqEdEENjyAujEoefuorm40393818;     pDGzqEdEENjyAujEoefuorm40393818 = pDGzqEdEENjyAujEoefuorm15354905;     pDGzqEdEENjyAujEoefuorm15354905 = pDGzqEdEENjyAujEoefuorm52675298;     pDGzqEdEENjyAujEoefuorm52675298 = pDGzqEdEENjyAujEoefuorm75175103;     pDGzqEdEENjyAujEoefuorm75175103 = pDGzqEdEENjyAujEoefuorm20575570;     pDGzqEdEENjyAujEoefuorm20575570 = pDGzqEdEENjyAujEoefuorm26747262;     pDGzqEdEENjyAujEoefuorm26747262 = pDGzqEdEENjyAujEoefuorm63728654;     pDGzqEdEENjyAujEoefuorm63728654 = pDGzqEdEENjyAujEoefuorm94280980;     pDGzqEdEENjyAujEoefuorm94280980 = pDGzqEdEENjyAujEoefuorm58742270;     pDGzqEdEENjyAujEoefuorm58742270 = pDGzqEdEENjyAujEoefuorm66152752;     pDGzqEdEENjyAujEoefuorm66152752 = pDGzqEdEENjyAujEoefuorm50313896;     pDGzqEdEENjyAujEoefuorm50313896 = pDGzqEdEENjyAujEoefuorm93226166;     pDGzqEdEENjyAujEoefuorm93226166 = pDGzqEdEENjyAujEoefuorm53420136;     pDGzqEdEENjyAujEoefuorm53420136 = pDGzqEdEENjyAujEoefuorm21412350;     pDGzqEdEENjyAujEoefuorm21412350 = pDGzqEdEENjyAujEoefuorm1523652;     pDGzqEdEENjyAujEoefuorm1523652 = pDGzqEdEENjyAujEoefuorm18545734;     pDGzqEdEENjyAujEoefuorm18545734 = pDGzqEdEENjyAujEoefuorm34829915;     pDGzqEdEENjyAujEoefuorm34829915 = pDGzqEdEENjyAujEoefuorm77545530;     pDGzqEdEENjyAujEoefuorm77545530 = pDGzqEdEENjyAujEoefuorm43213840;     pDGzqEdEENjyAujEoefuorm43213840 = pDGzqEdEENjyAujEoefuorm72510720;     pDGzqEdEENjyAujEoefuorm72510720 = pDGzqEdEENjyAujEoefuorm57260882;     pDGzqEdEENjyAujEoefuorm57260882 = pDGzqEdEENjyAujEoefuorm100129;     pDGzqEdEENjyAujEoefuorm100129 = pDGzqEdEENjyAujEoefuorm84618016;     pDGzqEdEENjyAujEoefuorm84618016 = pDGzqEdEENjyAujEoefuorm48140138;     pDGzqEdEENjyAujEoefuorm48140138 = pDGzqEdEENjyAujEoefuorm94657605;     pDGzqEdEENjyAujEoefuorm94657605 = pDGzqEdEENjyAujEoefuorm21312249;     pDGzqEdEENjyAujEoefuorm21312249 = pDGzqEdEENjyAujEoefuorm4007102;     pDGzqEdEENjyAujEoefuorm4007102 = pDGzqEdEENjyAujEoefuorm43572072;     pDGzqEdEENjyAujEoefuorm43572072 = pDGzqEdEENjyAujEoefuorm97426979;     pDGzqEdEENjyAujEoefuorm97426979 = pDGzqEdEENjyAujEoefuorm73280613;     pDGzqEdEENjyAujEoefuorm73280613 = pDGzqEdEENjyAujEoefuorm55626461;     pDGzqEdEENjyAujEoefuorm55626461 = pDGzqEdEENjyAujEoefuorm40796653;     pDGzqEdEENjyAujEoefuorm40796653 = pDGzqEdEENjyAujEoefuorm17847866;     pDGzqEdEENjyAujEoefuorm17847866 = pDGzqEdEENjyAujEoefuorm87679126;     pDGzqEdEENjyAujEoefuorm87679126 = pDGzqEdEENjyAujEoefuorm63530417;}



void SeItxAGCpDIxmUaHArnhDlADVS21670826() {     float AJZmpRedAGpGDrqpmBUWBzc47253935 = -261469436;    float AJZmpRedAGpGDrqpmBUWBzc16271589 = -480607271;    float AJZmpRedAGpGDrqpmBUWBzc40129586 = -759190810;    float AJZmpRedAGpGDrqpmBUWBzc24986096 = -536621419;    float AJZmpRedAGpGDrqpmBUWBzc23486628 = -753282996;    float AJZmpRedAGpGDrqpmBUWBzc31093930 = -295543658;    float AJZmpRedAGpGDrqpmBUWBzc46127368 = -514668846;    float AJZmpRedAGpGDrqpmBUWBzc74296042 = -514992143;    float AJZmpRedAGpGDrqpmBUWBzc38780300 = -533342214;    float AJZmpRedAGpGDrqpmBUWBzc59423556 = -404123012;    float AJZmpRedAGpGDrqpmBUWBzc45954801 = 6061075;    float AJZmpRedAGpGDrqpmBUWBzc95278941 = -12052265;    float AJZmpRedAGpGDrqpmBUWBzc91626615 = -776867946;    float AJZmpRedAGpGDrqpmBUWBzc22443054 = -847419621;    float AJZmpRedAGpGDrqpmBUWBzc50609680 = -967987972;    float AJZmpRedAGpGDrqpmBUWBzc73118737 = -703380416;    float AJZmpRedAGpGDrqpmBUWBzc97692418 = -918609783;    float AJZmpRedAGpGDrqpmBUWBzc19057042 = -647334146;    float AJZmpRedAGpGDrqpmBUWBzc71298105 = -767182125;    float AJZmpRedAGpGDrqpmBUWBzc62803177 = 27108392;    float AJZmpRedAGpGDrqpmBUWBzc63347655 = -643035750;    float AJZmpRedAGpGDrqpmBUWBzc37278016 = -469924702;    float AJZmpRedAGpGDrqpmBUWBzc11251646 = -691288962;    float AJZmpRedAGpGDrqpmBUWBzc93269273 = -489345895;    float AJZmpRedAGpGDrqpmBUWBzc97367590 = -192638293;    float AJZmpRedAGpGDrqpmBUWBzc99239003 = -351070492;    float AJZmpRedAGpGDrqpmBUWBzc2732688 = -93733661;    float AJZmpRedAGpGDrqpmBUWBzc95173355 = -564719081;    float AJZmpRedAGpGDrqpmBUWBzc28645169 = -458801888;    float AJZmpRedAGpGDrqpmBUWBzc78943703 = -732528141;    float AJZmpRedAGpGDrqpmBUWBzc63680643 = -3308821;    float AJZmpRedAGpGDrqpmBUWBzc76831737 = -344507546;    float AJZmpRedAGpGDrqpmBUWBzc78798053 = -836052785;    float AJZmpRedAGpGDrqpmBUWBzc60942573 = -680945551;    float AJZmpRedAGpGDrqpmBUWBzc42997936 = -487307394;    float AJZmpRedAGpGDrqpmBUWBzc41116552 = -184680889;    float AJZmpRedAGpGDrqpmBUWBzc80492728 = -125455109;    float AJZmpRedAGpGDrqpmBUWBzc21461537 = -984274660;    float AJZmpRedAGpGDrqpmBUWBzc1866837 = 2776753;    float AJZmpRedAGpGDrqpmBUWBzc75229759 = -179071651;    float AJZmpRedAGpGDrqpmBUWBzc94720783 = -359267495;    float AJZmpRedAGpGDrqpmBUWBzc59195120 = 18381594;    float AJZmpRedAGpGDrqpmBUWBzc18762195 = -715443321;    float AJZmpRedAGpGDrqpmBUWBzc96045133 = -467063559;    float AJZmpRedAGpGDrqpmBUWBzc66693694 = -542818890;    float AJZmpRedAGpGDrqpmBUWBzc83620030 = -490885034;    float AJZmpRedAGpGDrqpmBUWBzc77901563 = -853175471;    float AJZmpRedAGpGDrqpmBUWBzc1336862 = -120307021;    float AJZmpRedAGpGDrqpmBUWBzc51618454 = -178200695;    float AJZmpRedAGpGDrqpmBUWBzc15054827 = -781065895;    float AJZmpRedAGpGDrqpmBUWBzc40272367 = -599955741;    float AJZmpRedAGpGDrqpmBUWBzc61311219 = -103679147;    float AJZmpRedAGpGDrqpmBUWBzc40159969 = -584636299;    float AJZmpRedAGpGDrqpmBUWBzc10505830 = -923783975;    float AJZmpRedAGpGDrqpmBUWBzc58323170 = -283687324;    float AJZmpRedAGpGDrqpmBUWBzc9975919 = -791544734;    float AJZmpRedAGpGDrqpmBUWBzc5019943 = -789318310;    float AJZmpRedAGpGDrqpmBUWBzc46860312 = -169844916;    float AJZmpRedAGpGDrqpmBUWBzc27618505 = -243983127;    float AJZmpRedAGpGDrqpmBUWBzc24247625 = -302212504;    float AJZmpRedAGpGDrqpmBUWBzc28361243 = -101809997;    float AJZmpRedAGpGDrqpmBUWBzc50954013 = -949949765;    float AJZmpRedAGpGDrqpmBUWBzc45650874 = 43809745;    float AJZmpRedAGpGDrqpmBUWBzc59836597 = -800814073;    float AJZmpRedAGpGDrqpmBUWBzc95742913 = -300814192;    float AJZmpRedAGpGDrqpmBUWBzc69123064 = -649431379;    float AJZmpRedAGpGDrqpmBUWBzc16480888 = -175999481;    float AJZmpRedAGpGDrqpmBUWBzc30684043 = 4077604;    float AJZmpRedAGpGDrqpmBUWBzc79445117 = -260112228;    float AJZmpRedAGpGDrqpmBUWBzc9493128 = -683307083;    float AJZmpRedAGpGDrqpmBUWBzc92626008 = -477925308;    float AJZmpRedAGpGDrqpmBUWBzc76230881 = -934335124;    float AJZmpRedAGpGDrqpmBUWBzc17190205 = -550110899;    float AJZmpRedAGpGDrqpmBUWBzc96068345 = -488110474;    float AJZmpRedAGpGDrqpmBUWBzc68082394 = -613624113;    float AJZmpRedAGpGDrqpmBUWBzc4152536 = -561417344;    float AJZmpRedAGpGDrqpmBUWBzc18515821 = -754481382;    float AJZmpRedAGpGDrqpmBUWBzc15206512 = -124225404;    float AJZmpRedAGpGDrqpmBUWBzc26575580 = -946527005;    float AJZmpRedAGpGDrqpmBUWBzc13747561 = -701753259;    float AJZmpRedAGpGDrqpmBUWBzc21337440 = -497895021;    float AJZmpRedAGpGDrqpmBUWBzc1395826 = -973426640;    float AJZmpRedAGpGDrqpmBUWBzc43554902 = -286518387;    float AJZmpRedAGpGDrqpmBUWBzc13590342 = -677735993;    float AJZmpRedAGpGDrqpmBUWBzc38671336 = -32572401;    float AJZmpRedAGpGDrqpmBUWBzc2369424 = -899629674;    float AJZmpRedAGpGDrqpmBUWBzc36671769 = -759871248;    float AJZmpRedAGpGDrqpmBUWBzc68292224 = -912268810;    float AJZmpRedAGpGDrqpmBUWBzc2619403 = -297258227;    float AJZmpRedAGpGDrqpmBUWBzc33022017 = -695762660;    float AJZmpRedAGpGDrqpmBUWBzc36096609 = -395362580;    float AJZmpRedAGpGDrqpmBUWBzc33632417 = -955610193;    float AJZmpRedAGpGDrqpmBUWBzc93843032 = -640291534;    float AJZmpRedAGpGDrqpmBUWBzc77619212 = -695010744;    float AJZmpRedAGpGDrqpmBUWBzc46868517 = 22738345;    float AJZmpRedAGpGDrqpmBUWBzc43766771 = -409317730;    float AJZmpRedAGpGDrqpmBUWBzc13544247 = 74571849;    float AJZmpRedAGpGDrqpmBUWBzc58925598 = -914629248;    float AJZmpRedAGpGDrqpmBUWBzc302220 = -66249367;    float AJZmpRedAGpGDrqpmBUWBzc97570629 = -261469436;     AJZmpRedAGpGDrqpmBUWBzc47253935 = AJZmpRedAGpGDrqpmBUWBzc16271589;     AJZmpRedAGpGDrqpmBUWBzc16271589 = AJZmpRedAGpGDrqpmBUWBzc40129586;     AJZmpRedAGpGDrqpmBUWBzc40129586 = AJZmpRedAGpGDrqpmBUWBzc24986096;     AJZmpRedAGpGDrqpmBUWBzc24986096 = AJZmpRedAGpGDrqpmBUWBzc23486628;     AJZmpRedAGpGDrqpmBUWBzc23486628 = AJZmpRedAGpGDrqpmBUWBzc31093930;     AJZmpRedAGpGDrqpmBUWBzc31093930 = AJZmpRedAGpGDrqpmBUWBzc46127368;     AJZmpRedAGpGDrqpmBUWBzc46127368 = AJZmpRedAGpGDrqpmBUWBzc74296042;     AJZmpRedAGpGDrqpmBUWBzc74296042 = AJZmpRedAGpGDrqpmBUWBzc38780300;     AJZmpRedAGpGDrqpmBUWBzc38780300 = AJZmpRedAGpGDrqpmBUWBzc59423556;     AJZmpRedAGpGDrqpmBUWBzc59423556 = AJZmpRedAGpGDrqpmBUWBzc45954801;     AJZmpRedAGpGDrqpmBUWBzc45954801 = AJZmpRedAGpGDrqpmBUWBzc95278941;     AJZmpRedAGpGDrqpmBUWBzc95278941 = AJZmpRedAGpGDrqpmBUWBzc91626615;     AJZmpRedAGpGDrqpmBUWBzc91626615 = AJZmpRedAGpGDrqpmBUWBzc22443054;     AJZmpRedAGpGDrqpmBUWBzc22443054 = AJZmpRedAGpGDrqpmBUWBzc50609680;     AJZmpRedAGpGDrqpmBUWBzc50609680 = AJZmpRedAGpGDrqpmBUWBzc73118737;     AJZmpRedAGpGDrqpmBUWBzc73118737 = AJZmpRedAGpGDrqpmBUWBzc97692418;     AJZmpRedAGpGDrqpmBUWBzc97692418 = AJZmpRedAGpGDrqpmBUWBzc19057042;     AJZmpRedAGpGDrqpmBUWBzc19057042 = AJZmpRedAGpGDrqpmBUWBzc71298105;     AJZmpRedAGpGDrqpmBUWBzc71298105 = AJZmpRedAGpGDrqpmBUWBzc62803177;     AJZmpRedAGpGDrqpmBUWBzc62803177 = AJZmpRedAGpGDrqpmBUWBzc63347655;     AJZmpRedAGpGDrqpmBUWBzc63347655 = AJZmpRedAGpGDrqpmBUWBzc37278016;     AJZmpRedAGpGDrqpmBUWBzc37278016 = AJZmpRedAGpGDrqpmBUWBzc11251646;     AJZmpRedAGpGDrqpmBUWBzc11251646 = AJZmpRedAGpGDrqpmBUWBzc93269273;     AJZmpRedAGpGDrqpmBUWBzc93269273 = AJZmpRedAGpGDrqpmBUWBzc97367590;     AJZmpRedAGpGDrqpmBUWBzc97367590 = AJZmpRedAGpGDrqpmBUWBzc99239003;     AJZmpRedAGpGDrqpmBUWBzc99239003 = AJZmpRedAGpGDrqpmBUWBzc2732688;     AJZmpRedAGpGDrqpmBUWBzc2732688 = AJZmpRedAGpGDrqpmBUWBzc95173355;     AJZmpRedAGpGDrqpmBUWBzc95173355 = AJZmpRedAGpGDrqpmBUWBzc28645169;     AJZmpRedAGpGDrqpmBUWBzc28645169 = AJZmpRedAGpGDrqpmBUWBzc78943703;     AJZmpRedAGpGDrqpmBUWBzc78943703 = AJZmpRedAGpGDrqpmBUWBzc63680643;     AJZmpRedAGpGDrqpmBUWBzc63680643 = AJZmpRedAGpGDrqpmBUWBzc76831737;     AJZmpRedAGpGDrqpmBUWBzc76831737 = AJZmpRedAGpGDrqpmBUWBzc78798053;     AJZmpRedAGpGDrqpmBUWBzc78798053 = AJZmpRedAGpGDrqpmBUWBzc60942573;     AJZmpRedAGpGDrqpmBUWBzc60942573 = AJZmpRedAGpGDrqpmBUWBzc42997936;     AJZmpRedAGpGDrqpmBUWBzc42997936 = AJZmpRedAGpGDrqpmBUWBzc41116552;     AJZmpRedAGpGDrqpmBUWBzc41116552 = AJZmpRedAGpGDrqpmBUWBzc80492728;     AJZmpRedAGpGDrqpmBUWBzc80492728 = AJZmpRedAGpGDrqpmBUWBzc21461537;     AJZmpRedAGpGDrqpmBUWBzc21461537 = AJZmpRedAGpGDrqpmBUWBzc1866837;     AJZmpRedAGpGDrqpmBUWBzc1866837 = AJZmpRedAGpGDrqpmBUWBzc75229759;     AJZmpRedAGpGDrqpmBUWBzc75229759 = AJZmpRedAGpGDrqpmBUWBzc94720783;     AJZmpRedAGpGDrqpmBUWBzc94720783 = AJZmpRedAGpGDrqpmBUWBzc59195120;     AJZmpRedAGpGDrqpmBUWBzc59195120 = AJZmpRedAGpGDrqpmBUWBzc18762195;     AJZmpRedAGpGDrqpmBUWBzc18762195 = AJZmpRedAGpGDrqpmBUWBzc96045133;     AJZmpRedAGpGDrqpmBUWBzc96045133 = AJZmpRedAGpGDrqpmBUWBzc66693694;     AJZmpRedAGpGDrqpmBUWBzc66693694 = AJZmpRedAGpGDrqpmBUWBzc83620030;     AJZmpRedAGpGDrqpmBUWBzc83620030 = AJZmpRedAGpGDrqpmBUWBzc77901563;     AJZmpRedAGpGDrqpmBUWBzc77901563 = AJZmpRedAGpGDrqpmBUWBzc1336862;     AJZmpRedAGpGDrqpmBUWBzc1336862 = AJZmpRedAGpGDrqpmBUWBzc51618454;     AJZmpRedAGpGDrqpmBUWBzc51618454 = AJZmpRedAGpGDrqpmBUWBzc15054827;     AJZmpRedAGpGDrqpmBUWBzc15054827 = AJZmpRedAGpGDrqpmBUWBzc40272367;     AJZmpRedAGpGDrqpmBUWBzc40272367 = AJZmpRedAGpGDrqpmBUWBzc61311219;     AJZmpRedAGpGDrqpmBUWBzc61311219 = AJZmpRedAGpGDrqpmBUWBzc40159969;     AJZmpRedAGpGDrqpmBUWBzc40159969 = AJZmpRedAGpGDrqpmBUWBzc10505830;     AJZmpRedAGpGDrqpmBUWBzc10505830 = AJZmpRedAGpGDrqpmBUWBzc58323170;     AJZmpRedAGpGDrqpmBUWBzc58323170 = AJZmpRedAGpGDrqpmBUWBzc9975919;     AJZmpRedAGpGDrqpmBUWBzc9975919 = AJZmpRedAGpGDrqpmBUWBzc5019943;     AJZmpRedAGpGDrqpmBUWBzc5019943 = AJZmpRedAGpGDrqpmBUWBzc46860312;     AJZmpRedAGpGDrqpmBUWBzc46860312 = AJZmpRedAGpGDrqpmBUWBzc27618505;     AJZmpRedAGpGDrqpmBUWBzc27618505 = AJZmpRedAGpGDrqpmBUWBzc24247625;     AJZmpRedAGpGDrqpmBUWBzc24247625 = AJZmpRedAGpGDrqpmBUWBzc28361243;     AJZmpRedAGpGDrqpmBUWBzc28361243 = AJZmpRedAGpGDrqpmBUWBzc50954013;     AJZmpRedAGpGDrqpmBUWBzc50954013 = AJZmpRedAGpGDrqpmBUWBzc45650874;     AJZmpRedAGpGDrqpmBUWBzc45650874 = AJZmpRedAGpGDrqpmBUWBzc59836597;     AJZmpRedAGpGDrqpmBUWBzc59836597 = AJZmpRedAGpGDrqpmBUWBzc95742913;     AJZmpRedAGpGDrqpmBUWBzc95742913 = AJZmpRedAGpGDrqpmBUWBzc69123064;     AJZmpRedAGpGDrqpmBUWBzc69123064 = AJZmpRedAGpGDrqpmBUWBzc16480888;     AJZmpRedAGpGDrqpmBUWBzc16480888 = AJZmpRedAGpGDrqpmBUWBzc30684043;     AJZmpRedAGpGDrqpmBUWBzc30684043 = AJZmpRedAGpGDrqpmBUWBzc79445117;     AJZmpRedAGpGDrqpmBUWBzc79445117 = AJZmpRedAGpGDrqpmBUWBzc9493128;     AJZmpRedAGpGDrqpmBUWBzc9493128 = AJZmpRedAGpGDrqpmBUWBzc92626008;     AJZmpRedAGpGDrqpmBUWBzc92626008 = AJZmpRedAGpGDrqpmBUWBzc76230881;     AJZmpRedAGpGDrqpmBUWBzc76230881 = AJZmpRedAGpGDrqpmBUWBzc17190205;     AJZmpRedAGpGDrqpmBUWBzc17190205 = AJZmpRedAGpGDrqpmBUWBzc96068345;     AJZmpRedAGpGDrqpmBUWBzc96068345 = AJZmpRedAGpGDrqpmBUWBzc68082394;     AJZmpRedAGpGDrqpmBUWBzc68082394 = AJZmpRedAGpGDrqpmBUWBzc4152536;     AJZmpRedAGpGDrqpmBUWBzc4152536 = AJZmpRedAGpGDrqpmBUWBzc18515821;     AJZmpRedAGpGDrqpmBUWBzc18515821 = AJZmpRedAGpGDrqpmBUWBzc15206512;     AJZmpRedAGpGDrqpmBUWBzc15206512 = AJZmpRedAGpGDrqpmBUWBzc26575580;     AJZmpRedAGpGDrqpmBUWBzc26575580 = AJZmpRedAGpGDrqpmBUWBzc13747561;     AJZmpRedAGpGDrqpmBUWBzc13747561 = AJZmpRedAGpGDrqpmBUWBzc21337440;     AJZmpRedAGpGDrqpmBUWBzc21337440 = AJZmpRedAGpGDrqpmBUWBzc1395826;     AJZmpRedAGpGDrqpmBUWBzc1395826 = AJZmpRedAGpGDrqpmBUWBzc43554902;     AJZmpRedAGpGDrqpmBUWBzc43554902 = AJZmpRedAGpGDrqpmBUWBzc13590342;     AJZmpRedAGpGDrqpmBUWBzc13590342 = AJZmpRedAGpGDrqpmBUWBzc38671336;     AJZmpRedAGpGDrqpmBUWBzc38671336 = AJZmpRedAGpGDrqpmBUWBzc2369424;     AJZmpRedAGpGDrqpmBUWBzc2369424 = AJZmpRedAGpGDrqpmBUWBzc36671769;     AJZmpRedAGpGDrqpmBUWBzc36671769 = AJZmpRedAGpGDrqpmBUWBzc68292224;     AJZmpRedAGpGDrqpmBUWBzc68292224 = AJZmpRedAGpGDrqpmBUWBzc2619403;     AJZmpRedAGpGDrqpmBUWBzc2619403 = AJZmpRedAGpGDrqpmBUWBzc33022017;     AJZmpRedAGpGDrqpmBUWBzc33022017 = AJZmpRedAGpGDrqpmBUWBzc36096609;     AJZmpRedAGpGDrqpmBUWBzc36096609 = AJZmpRedAGpGDrqpmBUWBzc33632417;     AJZmpRedAGpGDrqpmBUWBzc33632417 = AJZmpRedAGpGDrqpmBUWBzc93843032;     AJZmpRedAGpGDrqpmBUWBzc93843032 = AJZmpRedAGpGDrqpmBUWBzc77619212;     AJZmpRedAGpGDrqpmBUWBzc77619212 = AJZmpRedAGpGDrqpmBUWBzc46868517;     AJZmpRedAGpGDrqpmBUWBzc46868517 = AJZmpRedAGpGDrqpmBUWBzc43766771;     AJZmpRedAGpGDrqpmBUWBzc43766771 = AJZmpRedAGpGDrqpmBUWBzc13544247;     AJZmpRedAGpGDrqpmBUWBzc13544247 = AJZmpRedAGpGDrqpmBUWBzc58925598;     AJZmpRedAGpGDrqpmBUWBzc58925598 = AJZmpRedAGpGDrqpmBUWBzc302220;     AJZmpRedAGpGDrqpmBUWBzc302220 = AJZmpRedAGpGDrqpmBUWBzc97570629;     AJZmpRedAGpGDrqpmBUWBzc97570629 = AJZmpRedAGpGDrqpmBUWBzc47253935;}



void KgmYRwecZlPXDkicoXPkZIFfSt6733664() {     float klkipsYKBHbWmmNkazaBFbA30977453 = -611491503;    float klkipsYKBHbWmmNkazaBFbA13869684 = -284259122;    float klkipsYKBHbWmmNkazaBFbA28715703 = -627498501;    float klkipsYKBHbWmmNkazaBFbA22134049 = -541503348;    float klkipsYKBHbWmmNkazaBFbA3047965 = -51231187;    float klkipsYKBHbWmmNkazaBFbA42433448 = -398864327;    float klkipsYKBHbWmmNkazaBFbA83007931 = -536182984;    float klkipsYKBHbWmmNkazaBFbA17636126 = -35446729;    float klkipsYKBHbWmmNkazaBFbA88999828 = -130824910;    float klkipsYKBHbWmmNkazaBFbA5529145 = -627164028;    float klkipsYKBHbWmmNkazaBFbA88843837 = -934224182;    float klkipsYKBHbWmmNkazaBFbA85490712 = 58808463;    float klkipsYKBHbWmmNkazaBFbA42680468 = -619700190;    float klkipsYKBHbWmmNkazaBFbA16816198 = -97102484;    float klkipsYKBHbWmmNkazaBFbA54788939 = -893685277;    float klkipsYKBHbWmmNkazaBFbA44932766 = -627508068;    float klkipsYKBHbWmmNkazaBFbA97557829 = 22510354;    float klkipsYKBHbWmmNkazaBFbA33134311 = -258185720;    float klkipsYKBHbWmmNkazaBFbA12274586 = -555831363;    float klkipsYKBHbWmmNkazaBFbA36910822 = -689184525;    float klkipsYKBHbWmmNkazaBFbA30687166 = -217502270;    float klkipsYKBHbWmmNkazaBFbA38280087 = -383079988;    float klkipsYKBHbWmmNkazaBFbA80427511 = -720683699;    float klkipsYKBHbWmmNkazaBFbA94411968 = -28578548;    float klkipsYKBHbWmmNkazaBFbA33969684 = -270969055;    float klkipsYKBHbWmmNkazaBFbA52231761 = -794037520;    float klkipsYKBHbWmmNkazaBFbA24324627 = -537609084;    float klkipsYKBHbWmmNkazaBFbA37772556 = -351160569;    float klkipsYKBHbWmmNkazaBFbA563311 = -982997789;    float klkipsYKBHbWmmNkazaBFbA14492031 = -305134516;    float klkipsYKBHbWmmNkazaBFbA45045066 = -222406841;    float klkipsYKBHbWmmNkazaBFbA1625026 = -893704769;    float klkipsYKBHbWmmNkazaBFbA92922755 = -401266876;    float klkipsYKBHbWmmNkazaBFbA96667287 = 14957802;    float klkipsYKBHbWmmNkazaBFbA10601262 = -221598002;    float klkipsYKBHbWmmNkazaBFbA10977786 = -163077366;    float klkipsYKBHbWmmNkazaBFbA80256319 = -445796405;    float klkipsYKBHbWmmNkazaBFbA71843328 = -883417877;    float klkipsYKBHbWmmNkazaBFbA62482556 = -302782129;    float klkipsYKBHbWmmNkazaBFbA14418876 = -125718531;    float klkipsYKBHbWmmNkazaBFbA59488304 = -9307622;    float klkipsYKBHbWmmNkazaBFbA88534846 = -687644075;    float klkipsYKBHbWmmNkazaBFbA51562341 = -367847575;    float klkipsYKBHbWmmNkazaBFbA43240653 = -46007291;    float klkipsYKBHbWmmNkazaBFbA94680944 = -868832969;    float klkipsYKBHbWmmNkazaBFbA27886912 = -105916726;    float klkipsYKBHbWmmNkazaBFbA11080533 = -874821378;    float klkipsYKBHbWmmNkazaBFbA40078709 = -982428919;    float klkipsYKBHbWmmNkazaBFbA85492667 = -977984846;    float klkipsYKBHbWmmNkazaBFbA50928157 = -313081331;    float klkipsYKBHbWmmNkazaBFbA80363199 = -765728142;    float klkipsYKBHbWmmNkazaBFbA12816939 = -955731933;    float klkipsYKBHbWmmNkazaBFbA85542371 = -596568665;    float klkipsYKBHbWmmNkazaBFbA56438435 = -400493163;    float klkipsYKBHbWmmNkazaBFbA76046498 = -600414269;    float klkipsYKBHbWmmNkazaBFbA92697365 = -128411515;    float klkipsYKBHbWmmNkazaBFbA33442173 = -563575424;    float klkipsYKBHbWmmNkazaBFbA34303734 = -498919953;    float klkipsYKBHbWmmNkazaBFbA88164364 = -170534294;    float klkipsYKBHbWmmNkazaBFbA50816203 = -257193668;    float klkipsYKBHbWmmNkazaBFbA18108821 = -861255243;    float klkipsYKBHbWmmNkazaBFbA45235376 = -85022415;    float klkipsYKBHbWmmNkazaBFbA17072815 = -52448941;    float klkipsYKBHbWmmNkazaBFbA74507798 = -825690395;    float klkipsYKBHbWmmNkazaBFbA60484079 = -304757187;    float klkipsYKBHbWmmNkazaBFbA87218811 = 59480586;    float klkipsYKBHbWmmNkazaBFbA92567957 = -539924661;    float klkipsYKBHbWmmNkazaBFbA46013180 = -534657992;    float klkipsYKBHbWmmNkazaBFbA6214937 = -875504482;    float klkipsYKBHbWmmNkazaBFbA43811153 = -630607911;    float klkipsYKBHbWmmNkazaBFbA64676447 = -81711663;    float klkipsYKBHbWmmNkazaBFbA25714502 = -94071770;    float klkipsYKBHbWmmNkazaBFbA70651755 = -955403592;    float klkipsYKBHbWmmNkazaBFbA97855710 = -330112833;    float klkipsYKBHbWmmNkazaBFbA77422518 = -579876904;    float klkipsYKBHbWmmNkazaBFbA42152319 = -529858196;    float klkipsYKBHbWmmNkazaBFbA86717746 = 84767586;    float klkipsYKBHbWmmNkazaBFbA37186858 = -574676408;    float klkipsYKBHbWmmNkazaBFbA99731024 = -159745580;    float klkipsYKBHbWmmNkazaBFbA6082773 = -65052329;    float klkipsYKBHbWmmNkazaBFbA41151229 = -919216142;    float klkipsYKBHbWmmNkazaBFbA84245917 = -555180166;    float klkipsYKBHbWmmNkazaBFbA52279889 = -373175724;    float klkipsYKBHbWmmNkazaBFbA49635153 = -569916458;    float klkipsYKBHbWmmNkazaBFbA34128831 = -539406374;    float klkipsYKBHbWmmNkazaBFbA32228127 = -266674908;    float klkipsYKBHbWmmNkazaBFbA16082655 = -197136105;    float klkipsYKBHbWmmNkazaBFbA36484320 = 99226287;    float klkipsYKBHbWmmNkazaBFbA20620790 = -384627930;    float klkipsYKBHbWmmNkazaBFbA17903896 = 6813513;    float klkipsYKBHbWmmNkazaBFbA77535612 = -599501943;    float klkipsYKBHbWmmNkazaBFbA45952585 = -946876452;    float klkipsYKBHbWmmNkazaBFbA83678963 = -612883583;    float klkipsYKBHbWmmNkazaBFbA11666353 = 54411539;    float klkipsYKBHbWmmNkazaBFbA96310054 = -264463288;    float klkipsYKBHbWmmNkazaBFbA14252929 = -924285207;    float klkipsYKBHbWmmNkazaBFbA71462031 = -535195134;    float klkipsYKBHbWmmNkazaBFbA77054543 = -542157181;    float klkipsYKBHbWmmNkazaBFbA82756574 = -741250104;    float klkipsYKBHbWmmNkazaBFbA7462133 = -611491503;     klkipsYKBHbWmmNkazaBFbA30977453 = klkipsYKBHbWmmNkazaBFbA13869684;     klkipsYKBHbWmmNkazaBFbA13869684 = klkipsYKBHbWmmNkazaBFbA28715703;     klkipsYKBHbWmmNkazaBFbA28715703 = klkipsYKBHbWmmNkazaBFbA22134049;     klkipsYKBHbWmmNkazaBFbA22134049 = klkipsYKBHbWmmNkazaBFbA3047965;     klkipsYKBHbWmmNkazaBFbA3047965 = klkipsYKBHbWmmNkazaBFbA42433448;     klkipsYKBHbWmmNkazaBFbA42433448 = klkipsYKBHbWmmNkazaBFbA83007931;     klkipsYKBHbWmmNkazaBFbA83007931 = klkipsYKBHbWmmNkazaBFbA17636126;     klkipsYKBHbWmmNkazaBFbA17636126 = klkipsYKBHbWmmNkazaBFbA88999828;     klkipsYKBHbWmmNkazaBFbA88999828 = klkipsYKBHbWmmNkazaBFbA5529145;     klkipsYKBHbWmmNkazaBFbA5529145 = klkipsYKBHbWmmNkazaBFbA88843837;     klkipsYKBHbWmmNkazaBFbA88843837 = klkipsYKBHbWmmNkazaBFbA85490712;     klkipsYKBHbWmmNkazaBFbA85490712 = klkipsYKBHbWmmNkazaBFbA42680468;     klkipsYKBHbWmmNkazaBFbA42680468 = klkipsYKBHbWmmNkazaBFbA16816198;     klkipsYKBHbWmmNkazaBFbA16816198 = klkipsYKBHbWmmNkazaBFbA54788939;     klkipsYKBHbWmmNkazaBFbA54788939 = klkipsYKBHbWmmNkazaBFbA44932766;     klkipsYKBHbWmmNkazaBFbA44932766 = klkipsYKBHbWmmNkazaBFbA97557829;     klkipsYKBHbWmmNkazaBFbA97557829 = klkipsYKBHbWmmNkazaBFbA33134311;     klkipsYKBHbWmmNkazaBFbA33134311 = klkipsYKBHbWmmNkazaBFbA12274586;     klkipsYKBHbWmmNkazaBFbA12274586 = klkipsYKBHbWmmNkazaBFbA36910822;     klkipsYKBHbWmmNkazaBFbA36910822 = klkipsYKBHbWmmNkazaBFbA30687166;     klkipsYKBHbWmmNkazaBFbA30687166 = klkipsYKBHbWmmNkazaBFbA38280087;     klkipsYKBHbWmmNkazaBFbA38280087 = klkipsYKBHbWmmNkazaBFbA80427511;     klkipsYKBHbWmmNkazaBFbA80427511 = klkipsYKBHbWmmNkazaBFbA94411968;     klkipsYKBHbWmmNkazaBFbA94411968 = klkipsYKBHbWmmNkazaBFbA33969684;     klkipsYKBHbWmmNkazaBFbA33969684 = klkipsYKBHbWmmNkazaBFbA52231761;     klkipsYKBHbWmmNkazaBFbA52231761 = klkipsYKBHbWmmNkazaBFbA24324627;     klkipsYKBHbWmmNkazaBFbA24324627 = klkipsYKBHbWmmNkazaBFbA37772556;     klkipsYKBHbWmmNkazaBFbA37772556 = klkipsYKBHbWmmNkazaBFbA563311;     klkipsYKBHbWmmNkazaBFbA563311 = klkipsYKBHbWmmNkazaBFbA14492031;     klkipsYKBHbWmmNkazaBFbA14492031 = klkipsYKBHbWmmNkazaBFbA45045066;     klkipsYKBHbWmmNkazaBFbA45045066 = klkipsYKBHbWmmNkazaBFbA1625026;     klkipsYKBHbWmmNkazaBFbA1625026 = klkipsYKBHbWmmNkazaBFbA92922755;     klkipsYKBHbWmmNkazaBFbA92922755 = klkipsYKBHbWmmNkazaBFbA96667287;     klkipsYKBHbWmmNkazaBFbA96667287 = klkipsYKBHbWmmNkazaBFbA10601262;     klkipsYKBHbWmmNkazaBFbA10601262 = klkipsYKBHbWmmNkazaBFbA10977786;     klkipsYKBHbWmmNkazaBFbA10977786 = klkipsYKBHbWmmNkazaBFbA80256319;     klkipsYKBHbWmmNkazaBFbA80256319 = klkipsYKBHbWmmNkazaBFbA71843328;     klkipsYKBHbWmmNkazaBFbA71843328 = klkipsYKBHbWmmNkazaBFbA62482556;     klkipsYKBHbWmmNkazaBFbA62482556 = klkipsYKBHbWmmNkazaBFbA14418876;     klkipsYKBHbWmmNkazaBFbA14418876 = klkipsYKBHbWmmNkazaBFbA59488304;     klkipsYKBHbWmmNkazaBFbA59488304 = klkipsYKBHbWmmNkazaBFbA88534846;     klkipsYKBHbWmmNkazaBFbA88534846 = klkipsYKBHbWmmNkazaBFbA51562341;     klkipsYKBHbWmmNkazaBFbA51562341 = klkipsYKBHbWmmNkazaBFbA43240653;     klkipsYKBHbWmmNkazaBFbA43240653 = klkipsYKBHbWmmNkazaBFbA94680944;     klkipsYKBHbWmmNkazaBFbA94680944 = klkipsYKBHbWmmNkazaBFbA27886912;     klkipsYKBHbWmmNkazaBFbA27886912 = klkipsYKBHbWmmNkazaBFbA11080533;     klkipsYKBHbWmmNkazaBFbA11080533 = klkipsYKBHbWmmNkazaBFbA40078709;     klkipsYKBHbWmmNkazaBFbA40078709 = klkipsYKBHbWmmNkazaBFbA85492667;     klkipsYKBHbWmmNkazaBFbA85492667 = klkipsYKBHbWmmNkazaBFbA50928157;     klkipsYKBHbWmmNkazaBFbA50928157 = klkipsYKBHbWmmNkazaBFbA80363199;     klkipsYKBHbWmmNkazaBFbA80363199 = klkipsYKBHbWmmNkazaBFbA12816939;     klkipsYKBHbWmmNkazaBFbA12816939 = klkipsYKBHbWmmNkazaBFbA85542371;     klkipsYKBHbWmmNkazaBFbA85542371 = klkipsYKBHbWmmNkazaBFbA56438435;     klkipsYKBHbWmmNkazaBFbA56438435 = klkipsYKBHbWmmNkazaBFbA76046498;     klkipsYKBHbWmmNkazaBFbA76046498 = klkipsYKBHbWmmNkazaBFbA92697365;     klkipsYKBHbWmmNkazaBFbA92697365 = klkipsYKBHbWmmNkazaBFbA33442173;     klkipsYKBHbWmmNkazaBFbA33442173 = klkipsYKBHbWmmNkazaBFbA34303734;     klkipsYKBHbWmmNkazaBFbA34303734 = klkipsYKBHbWmmNkazaBFbA88164364;     klkipsYKBHbWmmNkazaBFbA88164364 = klkipsYKBHbWmmNkazaBFbA50816203;     klkipsYKBHbWmmNkazaBFbA50816203 = klkipsYKBHbWmmNkazaBFbA18108821;     klkipsYKBHbWmmNkazaBFbA18108821 = klkipsYKBHbWmmNkazaBFbA45235376;     klkipsYKBHbWmmNkazaBFbA45235376 = klkipsYKBHbWmmNkazaBFbA17072815;     klkipsYKBHbWmmNkazaBFbA17072815 = klkipsYKBHbWmmNkazaBFbA74507798;     klkipsYKBHbWmmNkazaBFbA74507798 = klkipsYKBHbWmmNkazaBFbA60484079;     klkipsYKBHbWmmNkazaBFbA60484079 = klkipsYKBHbWmmNkazaBFbA87218811;     klkipsYKBHbWmmNkazaBFbA87218811 = klkipsYKBHbWmmNkazaBFbA92567957;     klkipsYKBHbWmmNkazaBFbA92567957 = klkipsYKBHbWmmNkazaBFbA46013180;     klkipsYKBHbWmmNkazaBFbA46013180 = klkipsYKBHbWmmNkazaBFbA6214937;     klkipsYKBHbWmmNkazaBFbA6214937 = klkipsYKBHbWmmNkazaBFbA43811153;     klkipsYKBHbWmmNkazaBFbA43811153 = klkipsYKBHbWmmNkazaBFbA64676447;     klkipsYKBHbWmmNkazaBFbA64676447 = klkipsYKBHbWmmNkazaBFbA25714502;     klkipsYKBHbWmmNkazaBFbA25714502 = klkipsYKBHbWmmNkazaBFbA70651755;     klkipsYKBHbWmmNkazaBFbA70651755 = klkipsYKBHbWmmNkazaBFbA97855710;     klkipsYKBHbWmmNkazaBFbA97855710 = klkipsYKBHbWmmNkazaBFbA77422518;     klkipsYKBHbWmmNkazaBFbA77422518 = klkipsYKBHbWmmNkazaBFbA42152319;     klkipsYKBHbWmmNkazaBFbA42152319 = klkipsYKBHbWmmNkazaBFbA86717746;     klkipsYKBHbWmmNkazaBFbA86717746 = klkipsYKBHbWmmNkazaBFbA37186858;     klkipsYKBHbWmmNkazaBFbA37186858 = klkipsYKBHbWmmNkazaBFbA99731024;     klkipsYKBHbWmmNkazaBFbA99731024 = klkipsYKBHbWmmNkazaBFbA6082773;     klkipsYKBHbWmmNkazaBFbA6082773 = klkipsYKBHbWmmNkazaBFbA41151229;     klkipsYKBHbWmmNkazaBFbA41151229 = klkipsYKBHbWmmNkazaBFbA84245917;     klkipsYKBHbWmmNkazaBFbA84245917 = klkipsYKBHbWmmNkazaBFbA52279889;     klkipsYKBHbWmmNkazaBFbA52279889 = klkipsYKBHbWmmNkazaBFbA49635153;     klkipsYKBHbWmmNkazaBFbA49635153 = klkipsYKBHbWmmNkazaBFbA34128831;     klkipsYKBHbWmmNkazaBFbA34128831 = klkipsYKBHbWmmNkazaBFbA32228127;     klkipsYKBHbWmmNkazaBFbA32228127 = klkipsYKBHbWmmNkazaBFbA16082655;     klkipsYKBHbWmmNkazaBFbA16082655 = klkipsYKBHbWmmNkazaBFbA36484320;     klkipsYKBHbWmmNkazaBFbA36484320 = klkipsYKBHbWmmNkazaBFbA20620790;     klkipsYKBHbWmmNkazaBFbA20620790 = klkipsYKBHbWmmNkazaBFbA17903896;     klkipsYKBHbWmmNkazaBFbA17903896 = klkipsYKBHbWmmNkazaBFbA77535612;     klkipsYKBHbWmmNkazaBFbA77535612 = klkipsYKBHbWmmNkazaBFbA45952585;     klkipsYKBHbWmmNkazaBFbA45952585 = klkipsYKBHbWmmNkazaBFbA83678963;     klkipsYKBHbWmmNkazaBFbA83678963 = klkipsYKBHbWmmNkazaBFbA11666353;     klkipsYKBHbWmmNkazaBFbA11666353 = klkipsYKBHbWmmNkazaBFbA96310054;     klkipsYKBHbWmmNkazaBFbA96310054 = klkipsYKBHbWmmNkazaBFbA14252929;     klkipsYKBHbWmmNkazaBFbA14252929 = klkipsYKBHbWmmNkazaBFbA71462031;     klkipsYKBHbWmmNkazaBFbA71462031 = klkipsYKBHbWmmNkazaBFbA77054543;     klkipsYKBHbWmmNkazaBFbA77054543 = klkipsYKBHbWmmNkazaBFbA82756574;     klkipsYKBHbWmmNkazaBFbA82756574 = klkipsYKBHbWmmNkazaBFbA7462133;     klkipsYKBHbWmmNkazaBFbA7462133 = klkipsYKBHbWmmNkazaBFbA30977453;}



void SeUkePdjfGrAUMHwjQyLpRcpiK91796501() {     float newhJfvHykzaNHrxvzbMvqa14700971 = -961513570;    float newhJfvHykzaNHrxvzbMvqa11467780 = -87910973;    float newhJfvHykzaNHrxvzbMvqa17301820 = -495806192;    float newhJfvHykzaNHrxvzbMvqa19282002 = -546385277;    float newhJfvHykzaNHrxvzbMvqa82609301 = -449179379;    float newhJfvHykzaNHrxvzbMvqa53772965 = -502184995;    float newhJfvHykzaNHrxvzbMvqa19888495 = -557697122;    float newhJfvHykzaNHrxvzbMvqa60976208 = -655901315;    float newhJfvHykzaNHrxvzbMvqa39219357 = -828307606;    float newhJfvHykzaNHrxvzbMvqa51634733 = -850205044;    float newhJfvHykzaNHrxvzbMvqa31732873 = -774509440;    float newhJfvHykzaNHrxvzbMvqa75702482 = -970330808;    float newhJfvHykzaNHrxvzbMvqa93734319 = -462532433;    float newhJfvHykzaNHrxvzbMvqa11189343 = -446785346;    float newhJfvHykzaNHrxvzbMvqa58968197 = -819382582;    float newhJfvHykzaNHrxvzbMvqa16746794 = -551635719;    float newhJfvHykzaNHrxvzbMvqa97423240 = -136369508;    float newhJfvHykzaNHrxvzbMvqa47211581 = -969037294;    float newhJfvHykzaNHrxvzbMvqa53251067 = -344480601;    float newhJfvHykzaNHrxvzbMvqa11018467 = -305477442;    float newhJfvHykzaNHrxvzbMvqa98026675 = -891968791;    float newhJfvHykzaNHrxvzbMvqa39282159 = -296235275;    float newhJfvHykzaNHrxvzbMvqa49603376 = -750078435;    float newhJfvHykzaNHrxvzbMvqa95554663 = -667811201;    float newhJfvHykzaNHrxvzbMvqa70571776 = -349299816;    float newhJfvHykzaNHrxvzbMvqa5224520 = -137004548;    float newhJfvHykzaNHrxvzbMvqa45916566 = -981484507;    float newhJfvHykzaNHrxvzbMvqa80371756 = -137602058;    float newhJfvHykzaNHrxvzbMvqa72481452 = -407193689;    float newhJfvHykzaNHrxvzbMvqa50040357 = -977740890;    float newhJfvHykzaNHrxvzbMvqa26409489 = -441504862;    float newhJfvHykzaNHrxvzbMvqa26418314 = -342901991;    float newhJfvHykzaNHrxvzbMvqa7047457 = 33519033;    float newhJfvHykzaNHrxvzbMvqa32392002 = -389138846;    float newhJfvHykzaNHrxvzbMvqa78204586 = 44111391;    float newhJfvHykzaNHrxvzbMvqa80839019 = -141473843;    float newhJfvHykzaNHrxvzbMvqa80019909 = -766137701;    float newhJfvHykzaNHrxvzbMvqa22225120 = -782561093;    float newhJfvHykzaNHrxvzbMvqa23098275 = -608341010;    float newhJfvHykzaNHrxvzbMvqa53607991 = -72365410;    float newhJfvHykzaNHrxvzbMvqa24255825 = -759347748;    float newhJfvHykzaNHrxvzbMvqa17874574 = -293669744;    float newhJfvHykzaNHrxvzbMvqa84362487 = -20251829;    float newhJfvHykzaNHrxvzbMvqa90436172 = -724951024;    float newhJfvHykzaNHrxvzbMvqa22668195 = -94847047;    float newhJfvHykzaNHrxvzbMvqa72153793 = -820948418;    float newhJfvHykzaNHrxvzbMvqa44259502 = -896467285;    float newhJfvHykzaNHrxvzbMvqa78820556 = -744550817;    float newhJfvHykzaNHrxvzbMvqa19366881 = -677768997;    float newhJfvHykzaNHrxvzbMvqa86801487 = -945096766;    float newhJfvHykzaNHrxvzbMvqa20454031 = -931500544;    float newhJfvHykzaNHrxvzbMvqa64322658 = -707784720;    float newhJfvHykzaNHrxvzbMvqa30924774 = -608501030;    float newhJfvHykzaNHrxvzbMvqa2371042 = -977202351;    float newhJfvHykzaNHrxvzbMvqa93769825 = -917141214;    float newhJfvHykzaNHrxvzbMvqa75418812 = -565278296;    float newhJfvHykzaNHrxvzbMvqa61864403 = -337832538;    float newhJfvHykzaNHrxvzbMvqa21747156 = -827994991;    float newhJfvHykzaNHrxvzbMvqa48710225 = -97085461;    float newhJfvHykzaNHrxvzbMvqa77384782 = -212174832;    float newhJfvHykzaNHrxvzbMvqa7856399 = -520700489;    float newhJfvHykzaNHrxvzbMvqa39516739 = -320095064;    float newhJfvHykzaNHrxvzbMvqa88494756 = -148707627;    float newhJfvHykzaNHrxvzbMvqa89178999 = -850566717;    float newhJfvHykzaNHrxvzbMvqa25225245 = -308700182;    float newhJfvHykzaNHrxvzbMvqa5314560 = -331607449;    float newhJfvHykzaNHrxvzbMvqa68655026 = -903849841;    float newhJfvHykzaNHrxvzbMvqa61342318 = 26606412;    float newhJfvHykzaNHrxvzbMvqa32984756 = -390896737;    float newhJfvHykzaNHrxvzbMvqa78129178 = -577908739;    float newhJfvHykzaNHrxvzbMvqa36726885 = -785498018;    float newhJfvHykzaNHrxvzbMvqa75198121 = -353808416;    float newhJfvHykzaNHrxvzbMvqa24113306 = -260696285;    float newhJfvHykzaNHrxvzbMvqa99643075 = -172115192;    float newhJfvHykzaNHrxvzbMvqa86762641 = -546129694;    float newhJfvHykzaNHrxvzbMvqa80152102 = -498299047;    float newhJfvHykzaNHrxvzbMvqa54919671 = -175983446;    float newhJfvHykzaNHrxvzbMvqa59167204 = 74872588;    float newhJfvHykzaNHrxvzbMvqa72886468 = -472964155;    float newhJfvHykzaNHrxvzbMvqa98417983 = -528351399;    float newhJfvHykzaNHrxvzbMvqa60965017 = -240537263;    float newhJfvHykzaNHrxvzbMvqa67096010 = -136933691;    float newhJfvHykzaNHrxvzbMvqa61004875 = -459833061;    float newhJfvHykzaNHrxvzbMvqa85679964 = -462096923;    float newhJfvHykzaNHrxvzbMvqa29586327 = 53759653;    float newhJfvHykzaNHrxvzbMvqa62086830 = -733720142;    float newhJfvHykzaNHrxvzbMvqa95493540 = -734400961;    float newhJfvHykzaNHrxvzbMvqa4676415 = 10721383;    float newhJfvHykzaNHrxvzbMvqa38622176 = -471997633;    float newhJfvHykzaNHrxvzbMvqa2785774 = -390610314;    float newhJfvHykzaNHrxvzbMvqa18974616 = -803641305;    float newhJfvHykzaNHrxvzbMvqa58272753 = -938142711;    float newhJfvHykzaNHrxvzbMvqa73514894 = -585475632;    float newhJfvHykzaNHrxvzbMvqa45713493 = -296166179;    float newhJfvHykzaNHrxvzbMvqa45751592 = -551664922;    float newhJfvHykzaNHrxvzbMvqa84739086 = -339252684;    float newhJfvHykzaNHrxvzbMvqa29379817 = -44962118;    float newhJfvHykzaNHrxvzbMvqa95183488 = -169685113;    float newhJfvHykzaNHrxvzbMvqa65210928 = -316250842;    float newhJfvHykzaNHrxvzbMvqa17353636 = -961513570;     newhJfvHykzaNHrxvzbMvqa14700971 = newhJfvHykzaNHrxvzbMvqa11467780;     newhJfvHykzaNHrxvzbMvqa11467780 = newhJfvHykzaNHrxvzbMvqa17301820;     newhJfvHykzaNHrxvzbMvqa17301820 = newhJfvHykzaNHrxvzbMvqa19282002;     newhJfvHykzaNHrxvzbMvqa19282002 = newhJfvHykzaNHrxvzbMvqa82609301;     newhJfvHykzaNHrxvzbMvqa82609301 = newhJfvHykzaNHrxvzbMvqa53772965;     newhJfvHykzaNHrxvzbMvqa53772965 = newhJfvHykzaNHrxvzbMvqa19888495;     newhJfvHykzaNHrxvzbMvqa19888495 = newhJfvHykzaNHrxvzbMvqa60976208;     newhJfvHykzaNHrxvzbMvqa60976208 = newhJfvHykzaNHrxvzbMvqa39219357;     newhJfvHykzaNHrxvzbMvqa39219357 = newhJfvHykzaNHrxvzbMvqa51634733;     newhJfvHykzaNHrxvzbMvqa51634733 = newhJfvHykzaNHrxvzbMvqa31732873;     newhJfvHykzaNHrxvzbMvqa31732873 = newhJfvHykzaNHrxvzbMvqa75702482;     newhJfvHykzaNHrxvzbMvqa75702482 = newhJfvHykzaNHrxvzbMvqa93734319;     newhJfvHykzaNHrxvzbMvqa93734319 = newhJfvHykzaNHrxvzbMvqa11189343;     newhJfvHykzaNHrxvzbMvqa11189343 = newhJfvHykzaNHrxvzbMvqa58968197;     newhJfvHykzaNHrxvzbMvqa58968197 = newhJfvHykzaNHrxvzbMvqa16746794;     newhJfvHykzaNHrxvzbMvqa16746794 = newhJfvHykzaNHrxvzbMvqa97423240;     newhJfvHykzaNHrxvzbMvqa97423240 = newhJfvHykzaNHrxvzbMvqa47211581;     newhJfvHykzaNHrxvzbMvqa47211581 = newhJfvHykzaNHrxvzbMvqa53251067;     newhJfvHykzaNHrxvzbMvqa53251067 = newhJfvHykzaNHrxvzbMvqa11018467;     newhJfvHykzaNHrxvzbMvqa11018467 = newhJfvHykzaNHrxvzbMvqa98026675;     newhJfvHykzaNHrxvzbMvqa98026675 = newhJfvHykzaNHrxvzbMvqa39282159;     newhJfvHykzaNHrxvzbMvqa39282159 = newhJfvHykzaNHrxvzbMvqa49603376;     newhJfvHykzaNHrxvzbMvqa49603376 = newhJfvHykzaNHrxvzbMvqa95554663;     newhJfvHykzaNHrxvzbMvqa95554663 = newhJfvHykzaNHrxvzbMvqa70571776;     newhJfvHykzaNHrxvzbMvqa70571776 = newhJfvHykzaNHrxvzbMvqa5224520;     newhJfvHykzaNHrxvzbMvqa5224520 = newhJfvHykzaNHrxvzbMvqa45916566;     newhJfvHykzaNHrxvzbMvqa45916566 = newhJfvHykzaNHrxvzbMvqa80371756;     newhJfvHykzaNHrxvzbMvqa80371756 = newhJfvHykzaNHrxvzbMvqa72481452;     newhJfvHykzaNHrxvzbMvqa72481452 = newhJfvHykzaNHrxvzbMvqa50040357;     newhJfvHykzaNHrxvzbMvqa50040357 = newhJfvHykzaNHrxvzbMvqa26409489;     newhJfvHykzaNHrxvzbMvqa26409489 = newhJfvHykzaNHrxvzbMvqa26418314;     newhJfvHykzaNHrxvzbMvqa26418314 = newhJfvHykzaNHrxvzbMvqa7047457;     newhJfvHykzaNHrxvzbMvqa7047457 = newhJfvHykzaNHrxvzbMvqa32392002;     newhJfvHykzaNHrxvzbMvqa32392002 = newhJfvHykzaNHrxvzbMvqa78204586;     newhJfvHykzaNHrxvzbMvqa78204586 = newhJfvHykzaNHrxvzbMvqa80839019;     newhJfvHykzaNHrxvzbMvqa80839019 = newhJfvHykzaNHrxvzbMvqa80019909;     newhJfvHykzaNHrxvzbMvqa80019909 = newhJfvHykzaNHrxvzbMvqa22225120;     newhJfvHykzaNHrxvzbMvqa22225120 = newhJfvHykzaNHrxvzbMvqa23098275;     newhJfvHykzaNHrxvzbMvqa23098275 = newhJfvHykzaNHrxvzbMvqa53607991;     newhJfvHykzaNHrxvzbMvqa53607991 = newhJfvHykzaNHrxvzbMvqa24255825;     newhJfvHykzaNHrxvzbMvqa24255825 = newhJfvHykzaNHrxvzbMvqa17874574;     newhJfvHykzaNHrxvzbMvqa17874574 = newhJfvHykzaNHrxvzbMvqa84362487;     newhJfvHykzaNHrxvzbMvqa84362487 = newhJfvHykzaNHrxvzbMvqa90436172;     newhJfvHykzaNHrxvzbMvqa90436172 = newhJfvHykzaNHrxvzbMvqa22668195;     newhJfvHykzaNHrxvzbMvqa22668195 = newhJfvHykzaNHrxvzbMvqa72153793;     newhJfvHykzaNHrxvzbMvqa72153793 = newhJfvHykzaNHrxvzbMvqa44259502;     newhJfvHykzaNHrxvzbMvqa44259502 = newhJfvHykzaNHrxvzbMvqa78820556;     newhJfvHykzaNHrxvzbMvqa78820556 = newhJfvHykzaNHrxvzbMvqa19366881;     newhJfvHykzaNHrxvzbMvqa19366881 = newhJfvHykzaNHrxvzbMvqa86801487;     newhJfvHykzaNHrxvzbMvqa86801487 = newhJfvHykzaNHrxvzbMvqa20454031;     newhJfvHykzaNHrxvzbMvqa20454031 = newhJfvHykzaNHrxvzbMvqa64322658;     newhJfvHykzaNHrxvzbMvqa64322658 = newhJfvHykzaNHrxvzbMvqa30924774;     newhJfvHykzaNHrxvzbMvqa30924774 = newhJfvHykzaNHrxvzbMvqa2371042;     newhJfvHykzaNHrxvzbMvqa2371042 = newhJfvHykzaNHrxvzbMvqa93769825;     newhJfvHykzaNHrxvzbMvqa93769825 = newhJfvHykzaNHrxvzbMvqa75418812;     newhJfvHykzaNHrxvzbMvqa75418812 = newhJfvHykzaNHrxvzbMvqa61864403;     newhJfvHykzaNHrxvzbMvqa61864403 = newhJfvHykzaNHrxvzbMvqa21747156;     newhJfvHykzaNHrxvzbMvqa21747156 = newhJfvHykzaNHrxvzbMvqa48710225;     newhJfvHykzaNHrxvzbMvqa48710225 = newhJfvHykzaNHrxvzbMvqa77384782;     newhJfvHykzaNHrxvzbMvqa77384782 = newhJfvHykzaNHrxvzbMvqa7856399;     newhJfvHykzaNHrxvzbMvqa7856399 = newhJfvHykzaNHrxvzbMvqa39516739;     newhJfvHykzaNHrxvzbMvqa39516739 = newhJfvHykzaNHrxvzbMvqa88494756;     newhJfvHykzaNHrxvzbMvqa88494756 = newhJfvHykzaNHrxvzbMvqa89178999;     newhJfvHykzaNHrxvzbMvqa89178999 = newhJfvHykzaNHrxvzbMvqa25225245;     newhJfvHykzaNHrxvzbMvqa25225245 = newhJfvHykzaNHrxvzbMvqa5314560;     newhJfvHykzaNHrxvzbMvqa5314560 = newhJfvHykzaNHrxvzbMvqa68655026;     newhJfvHykzaNHrxvzbMvqa68655026 = newhJfvHykzaNHrxvzbMvqa61342318;     newhJfvHykzaNHrxvzbMvqa61342318 = newhJfvHykzaNHrxvzbMvqa32984756;     newhJfvHykzaNHrxvzbMvqa32984756 = newhJfvHykzaNHrxvzbMvqa78129178;     newhJfvHykzaNHrxvzbMvqa78129178 = newhJfvHykzaNHrxvzbMvqa36726885;     newhJfvHykzaNHrxvzbMvqa36726885 = newhJfvHykzaNHrxvzbMvqa75198121;     newhJfvHykzaNHrxvzbMvqa75198121 = newhJfvHykzaNHrxvzbMvqa24113306;     newhJfvHykzaNHrxvzbMvqa24113306 = newhJfvHykzaNHrxvzbMvqa99643075;     newhJfvHykzaNHrxvzbMvqa99643075 = newhJfvHykzaNHrxvzbMvqa86762641;     newhJfvHykzaNHrxvzbMvqa86762641 = newhJfvHykzaNHrxvzbMvqa80152102;     newhJfvHykzaNHrxvzbMvqa80152102 = newhJfvHykzaNHrxvzbMvqa54919671;     newhJfvHykzaNHrxvzbMvqa54919671 = newhJfvHykzaNHrxvzbMvqa59167204;     newhJfvHykzaNHrxvzbMvqa59167204 = newhJfvHykzaNHrxvzbMvqa72886468;     newhJfvHykzaNHrxvzbMvqa72886468 = newhJfvHykzaNHrxvzbMvqa98417983;     newhJfvHykzaNHrxvzbMvqa98417983 = newhJfvHykzaNHrxvzbMvqa60965017;     newhJfvHykzaNHrxvzbMvqa60965017 = newhJfvHykzaNHrxvzbMvqa67096010;     newhJfvHykzaNHrxvzbMvqa67096010 = newhJfvHykzaNHrxvzbMvqa61004875;     newhJfvHykzaNHrxvzbMvqa61004875 = newhJfvHykzaNHrxvzbMvqa85679964;     newhJfvHykzaNHrxvzbMvqa85679964 = newhJfvHykzaNHrxvzbMvqa29586327;     newhJfvHykzaNHrxvzbMvqa29586327 = newhJfvHykzaNHrxvzbMvqa62086830;     newhJfvHykzaNHrxvzbMvqa62086830 = newhJfvHykzaNHrxvzbMvqa95493540;     newhJfvHykzaNHrxvzbMvqa95493540 = newhJfvHykzaNHrxvzbMvqa4676415;     newhJfvHykzaNHrxvzbMvqa4676415 = newhJfvHykzaNHrxvzbMvqa38622176;     newhJfvHykzaNHrxvzbMvqa38622176 = newhJfvHykzaNHrxvzbMvqa2785774;     newhJfvHykzaNHrxvzbMvqa2785774 = newhJfvHykzaNHrxvzbMvqa18974616;     newhJfvHykzaNHrxvzbMvqa18974616 = newhJfvHykzaNHrxvzbMvqa58272753;     newhJfvHykzaNHrxvzbMvqa58272753 = newhJfvHykzaNHrxvzbMvqa73514894;     newhJfvHykzaNHrxvzbMvqa73514894 = newhJfvHykzaNHrxvzbMvqa45713493;     newhJfvHykzaNHrxvzbMvqa45713493 = newhJfvHykzaNHrxvzbMvqa45751592;     newhJfvHykzaNHrxvzbMvqa45751592 = newhJfvHykzaNHrxvzbMvqa84739086;     newhJfvHykzaNHrxvzbMvqa84739086 = newhJfvHykzaNHrxvzbMvqa29379817;     newhJfvHykzaNHrxvzbMvqa29379817 = newhJfvHykzaNHrxvzbMvqa95183488;     newhJfvHykzaNHrxvzbMvqa95183488 = newhJfvHykzaNHrxvzbMvqa65210928;     newhJfvHykzaNHrxvzbMvqa65210928 = newhJfvHykzaNHrxvzbMvqa17353636;     newhJfvHykzaNHrxvzbMvqa17353636 = newhJfvHykzaNHrxvzbMvqa14700971;}



void esUvBbTTwqPwJfzccKryEmVLRA76859339() {     float reNVMUQICbCjBnfrIYbLBYh98424489 = -211535637;    float reNVMUQICbCjBnfrIYbLBYh9065875 = -991562825;    float reNVMUQICbCjBnfrIYbLBYh5887937 = -364113882;    float reNVMUQICbCjBnfrIYbLBYh16429955 = -551267206;    float reNVMUQICbCjBnfrIYbLBYh62170638 = -847127570;    float reNVMUQICbCjBnfrIYbLBYh65112483 = -605505664;    float reNVMUQICbCjBnfrIYbLBYh56769057 = -579211260;    float reNVMUQICbCjBnfrIYbLBYh4316291 = -176355901;    float reNVMUQICbCjBnfrIYbLBYh89438885 = -425790303;    float reNVMUQICbCjBnfrIYbLBYh97740321 = 26753941;    float reNVMUQICbCjBnfrIYbLBYh74621909 = -614794698;    float reNVMUQICbCjBnfrIYbLBYh65914253 = -899470079;    float reNVMUQICbCjBnfrIYbLBYh44788171 = -305364677;    float reNVMUQICbCjBnfrIYbLBYh5562487 = -796468208;    float reNVMUQICbCjBnfrIYbLBYh63147456 = -745079887;    float reNVMUQICbCjBnfrIYbLBYh88560822 = -475763370;    float reNVMUQICbCjBnfrIYbLBYh97288651 = -295249371;    float reNVMUQICbCjBnfrIYbLBYh61288850 = -579888868;    float reNVMUQICbCjBnfrIYbLBYh94227547 = -133129840;    float reNVMUQICbCjBnfrIYbLBYh85126111 = 78229641;    float reNVMUQICbCjBnfrIYbLBYh65366186 = -466435312;    float reNVMUQICbCjBnfrIYbLBYh40284230 = -209390561;    float reNVMUQICbCjBnfrIYbLBYh18779242 = -779473172;    float reNVMUQICbCjBnfrIYbLBYh96697358 = -207043854;    float reNVMUQICbCjBnfrIYbLBYh7173870 = -427630578;    float reNVMUQICbCjBnfrIYbLBYh58217277 = -579971575;    float reNVMUQICbCjBnfrIYbLBYh67508506 = -325359930;    float reNVMUQICbCjBnfrIYbLBYh22970956 = 75956454;    float reNVMUQICbCjBnfrIYbLBYh44399593 = -931389589;    float reNVMUQICbCjBnfrIYbLBYh85588684 = -550347265;    float reNVMUQICbCjBnfrIYbLBYh7773912 = -660602882;    float reNVMUQICbCjBnfrIYbLBYh51211602 = -892099214;    float reNVMUQICbCjBnfrIYbLBYh21172158 = -631695059;    float reNVMUQICbCjBnfrIYbLBYh68116715 = -793235494;    float reNVMUQICbCjBnfrIYbLBYh45807912 = -790179217;    float reNVMUQICbCjBnfrIYbLBYh50700253 = -119870321;    float reNVMUQICbCjBnfrIYbLBYh79783499 = 13521002;    float reNVMUQICbCjBnfrIYbLBYh72606910 = -681704310;    float reNVMUQICbCjBnfrIYbLBYh83713994 = -913899891;    float reNVMUQICbCjBnfrIYbLBYh92797107 = -19012290;    float reNVMUQICbCjBnfrIYbLBYh89023345 = -409387875;    float reNVMUQICbCjBnfrIYbLBYh47214300 = -999695414;    float reNVMUQICbCjBnfrIYbLBYh17162634 = -772656084;    float reNVMUQICbCjBnfrIYbLBYh37631692 = -303894756;    float reNVMUQICbCjBnfrIYbLBYh50655446 = -420861125;    float reNVMUQICbCjBnfrIYbLBYh16420675 = -435980109;    float reNVMUQICbCjBnfrIYbLBYh77438472 = -918113192;    float reNVMUQICbCjBnfrIYbLBYh17562404 = -506672715;    float reNVMUQICbCjBnfrIYbLBYh53241094 = -377553148;    float reNVMUQICbCjBnfrIYbLBYh22674817 = -477112201;    float reNVMUQICbCjBnfrIYbLBYh60544862 = 2727055;    float reNVMUQICbCjBnfrIYbLBYh15828379 = -459837506;    float reNVMUQICbCjBnfrIYbLBYh76307176 = -620433396;    float reNVMUQICbCjBnfrIYbLBYh48303647 = -453911538;    float reNVMUQICbCjBnfrIYbLBYh11493154 = -133868159;    float reNVMUQICbCjBnfrIYbLBYh58140259 = 97854923;    float reNVMUQICbCjBnfrIYbLBYh90286633 = -112089653;    float reNVMUQICbCjBnfrIYbLBYh9190579 = -57070029;    float reNVMUQICbCjBnfrIYbLBYh9256086 = -23636629;    float reNVMUQICbCjBnfrIYbLBYh3953361 = -167155995;    float reNVMUQICbCjBnfrIYbLBYh97603977 = -180145734;    float reNVMUQICbCjBnfrIYbLBYh33798101 = -555167714;    float reNVMUQICbCjBnfrIYbLBYh59916697 = -244966313;    float reNVMUQICbCjBnfrIYbLBYh3850201 = -875443039;    float reNVMUQICbCjBnfrIYbLBYh89966409 = -312643177;    float reNVMUQICbCjBnfrIYbLBYh23410307 = -722695485;    float reNVMUQICbCjBnfrIYbLBYh44742096 = -167775021;    float reNVMUQICbCjBnfrIYbLBYh76671456 = -512129184;    float reNVMUQICbCjBnfrIYbLBYh59754575 = 93711008;    float reNVMUQICbCjBnfrIYbLBYh12447204 = -525209567;    float reNVMUQICbCjBnfrIYbLBYh8777324 = -389284373;    float reNVMUQICbCjBnfrIYbLBYh24681741 = -613545062;    float reNVMUQICbCjBnfrIYbLBYh77574856 = -665988977;    float reNVMUQICbCjBnfrIYbLBYh1430441 = -14117550;    float reNVMUQICbCjBnfrIYbLBYh96102765 = -512382485;    float reNVMUQICbCjBnfrIYbLBYh18151886 = -466739899;    float reNVMUQICbCjBnfrIYbLBYh23121596 = -436734478;    float reNVMUQICbCjBnfrIYbLBYh81147549 = -375578416;    float reNVMUQICbCjBnfrIYbLBYh46041913 = -786182730;    float reNVMUQICbCjBnfrIYbLBYh90753195 = -991650469;    float reNVMUQICbCjBnfrIYbLBYh80778805 = -661858383;    float reNVMUQICbCjBnfrIYbLBYh49946102 = -818687216;    float reNVMUQICbCjBnfrIYbLBYh69729862 = -546490399;    float reNVMUQICbCjBnfrIYbLBYh21724777 = -354277388;    float reNVMUQICbCjBnfrIYbLBYh25043823 = -453074320;    float reNVMUQICbCjBnfrIYbLBYh91945533 = -100765377;    float reNVMUQICbCjBnfrIYbLBYh74904426 = -171665818;    float reNVMUQICbCjBnfrIYbLBYh72868510 = -77783521;    float reNVMUQICbCjBnfrIYbLBYh56623562 = -559367336;    float reNVMUQICbCjBnfrIYbLBYh87667652 = -788034141;    float reNVMUQICbCjBnfrIYbLBYh60413619 = 92219332;    float reNVMUQICbCjBnfrIYbLBYh70592921 = -929408970;    float reNVMUQICbCjBnfrIYbLBYh63350825 = -558067682;    float reNVMUQICbCjBnfrIYbLBYh79760633 = -646743896;    float reNVMUQICbCjBnfrIYbLBYh95193129 = -838866556;    float reNVMUQICbCjBnfrIYbLBYh55225244 = -854220161;    float reNVMUQICbCjBnfrIYbLBYh87297602 = -654729101;    float reNVMUQICbCjBnfrIYbLBYh13312434 = -897213045;    float reNVMUQICbCjBnfrIYbLBYh47665282 = -991251579;    float reNVMUQICbCjBnfrIYbLBYh27245139 = -211535637;     reNVMUQICbCjBnfrIYbLBYh98424489 = reNVMUQICbCjBnfrIYbLBYh9065875;     reNVMUQICbCjBnfrIYbLBYh9065875 = reNVMUQICbCjBnfrIYbLBYh5887937;     reNVMUQICbCjBnfrIYbLBYh5887937 = reNVMUQICbCjBnfrIYbLBYh16429955;     reNVMUQICbCjBnfrIYbLBYh16429955 = reNVMUQICbCjBnfrIYbLBYh62170638;     reNVMUQICbCjBnfrIYbLBYh62170638 = reNVMUQICbCjBnfrIYbLBYh65112483;     reNVMUQICbCjBnfrIYbLBYh65112483 = reNVMUQICbCjBnfrIYbLBYh56769057;     reNVMUQICbCjBnfrIYbLBYh56769057 = reNVMUQICbCjBnfrIYbLBYh4316291;     reNVMUQICbCjBnfrIYbLBYh4316291 = reNVMUQICbCjBnfrIYbLBYh89438885;     reNVMUQICbCjBnfrIYbLBYh89438885 = reNVMUQICbCjBnfrIYbLBYh97740321;     reNVMUQICbCjBnfrIYbLBYh97740321 = reNVMUQICbCjBnfrIYbLBYh74621909;     reNVMUQICbCjBnfrIYbLBYh74621909 = reNVMUQICbCjBnfrIYbLBYh65914253;     reNVMUQICbCjBnfrIYbLBYh65914253 = reNVMUQICbCjBnfrIYbLBYh44788171;     reNVMUQICbCjBnfrIYbLBYh44788171 = reNVMUQICbCjBnfrIYbLBYh5562487;     reNVMUQICbCjBnfrIYbLBYh5562487 = reNVMUQICbCjBnfrIYbLBYh63147456;     reNVMUQICbCjBnfrIYbLBYh63147456 = reNVMUQICbCjBnfrIYbLBYh88560822;     reNVMUQICbCjBnfrIYbLBYh88560822 = reNVMUQICbCjBnfrIYbLBYh97288651;     reNVMUQICbCjBnfrIYbLBYh97288651 = reNVMUQICbCjBnfrIYbLBYh61288850;     reNVMUQICbCjBnfrIYbLBYh61288850 = reNVMUQICbCjBnfrIYbLBYh94227547;     reNVMUQICbCjBnfrIYbLBYh94227547 = reNVMUQICbCjBnfrIYbLBYh85126111;     reNVMUQICbCjBnfrIYbLBYh85126111 = reNVMUQICbCjBnfrIYbLBYh65366186;     reNVMUQICbCjBnfrIYbLBYh65366186 = reNVMUQICbCjBnfrIYbLBYh40284230;     reNVMUQICbCjBnfrIYbLBYh40284230 = reNVMUQICbCjBnfrIYbLBYh18779242;     reNVMUQICbCjBnfrIYbLBYh18779242 = reNVMUQICbCjBnfrIYbLBYh96697358;     reNVMUQICbCjBnfrIYbLBYh96697358 = reNVMUQICbCjBnfrIYbLBYh7173870;     reNVMUQICbCjBnfrIYbLBYh7173870 = reNVMUQICbCjBnfrIYbLBYh58217277;     reNVMUQICbCjBnfrIYbLBYh58217277 = reNVMUQICbCjBnfrIYbLBYh67508506;     reNVMUQICbCjBnfrIYbLBYh67508506 = reNVMUQICbCjBnfrIYbLBYh22970956;     reNVMUQICbCjBnfrIYbLBYh22970956 = reNVMUQICbCjBnfrIYbLBYh44399593;     reNVMUQICbCjBnfrIYbLBYh44399593 = reNVMUQICbCjBnfrIYbLBYh85588684;     reNVMUQICbCjBnfrIYbLBYh85588684 = reNVMUQICbCjBnfrIYbLBYh7773912;     reNVMUQICbCjBnfrIYbLBYh7773912 = reNVMUQICbCjBnfrIYbLBYh51211602;     reNVMUQICbCjBnfrIYbLBYh51211602 = reNVMUQICbCjBnfrIYbLBYh21172158;     reNVMUQICbCjBnfrIYbLBYh21172158 = reNVMUQICbCjBnfrIYbLBYh68116715;     reNVMUQICbCjBnfrIYbLBYh68116715 = reNVMUQICbCjBnfrIYbLBYh45807912;     reNVMUQICbCjBnfrIYbLBYh45807912 = reNVMUQICbCjBnfrIYbLBYh50700253;     reNVMUQICbCjBnfrIYbLBYh50700253 = reNVMUQICbCjBnfrIYbLBYh79783499;     reNVMUQICbCjBnfrIYbLBYh79783499 = reNVMUQICbCjBnfrIYbLBYh72606910;     reNVMUQICbCjBnfrIYbLBYh72606910 = reNVMUQICbCjBnfrIYbLBYh83713994;     reNVMUQICbCjBnfrIYbLBYh83713994 = reNVMUQICbCjBnfrIYbLBYh92797107;     reNVMUQICbCjBnfrIYbLBYh92797107 = reNVMUQICbCjBnfrIYbLBYh89023345;     reNVMUQICbCjBnfrIYbLBYh89023345 = reNVMUQICbCjBnfrIYbLBYh47214300;     reNVMUQICbCjBnfrIYbLBYh47214300 = reNVMUQICbCjBnfrIYbLBYh17162634;     reNVMUQICbCjBnfrIYbLBYh17162634 = reNVMUQICbCjBnfrIYbLBYh37631692;     reNVMUQICbCjBnfrIYbLBYh37631692 = reNVMUQICbCjBnfrIYbLBYh50655446;     reNVMUQICbCjBnfrIYbLBYh50655446 = reNVMUQICbCjBnfrIYbLBYh16420675;     reNVMUQICbCjBnfrIYbLBYh16420675 = reNVMUQICbCjBnfrIYbLBYh77438472;     reNVMUQICbCjBnfrIYbLBYh77438472 = reNVMUQICbCjBnfrIYbLBYh17562404;     reNVMUQICbCjBnfrIYbLBYh17562404 = reNVMUQICbCjBnfrIYbLBYh53241094;     reNVMUQICbCjBnfrIYbLBYh53241094 = reNVMUQICbCjBnfrIYbLBYh22674817;     reNVMUQICbCjBnfrIYbLBYh22674817 = reNVMUQICbCjBnfrIYbLBYh60544862;     reNVMUQICbCjBnfrIYbLBYh60544862 = reNVMUQICbCjBnfrIYbLBYh15828379;     reNVMUQICbCjBnfrIYbLBYh15828379 = reNVMUQICbCjBnfrIYbLBYh76307176;     reNVMUQICbCjBnfrIYbLBYh76307176 = reNVMUQICbCjBnfrIYbLBYh48303647;     reNVMUQICbCjBnfrIYbLBYh48303647 = reNVMUQICbCjBnfrIYbLBYh11493154;     reNVMUQICbCjBnfrIYbLBYh11493154 = reNVMUQICbCjBnfrIYbLBYh58140259;     reNVMUQICbCjBnfrIYbLBYh58140259 = reNVMUQICbCjBnfrIYbLBYh90286633;     reNVMUQICbCjBnfrIYbLBYh90286633 = reNVMUQICbCjBnfrIYbLBYh9190579;     reNVMUQICbCjBnfrIYbLBYh9190579 = reNVMUQICbCjBnfrIYbLBYh9256086;     reNVMUQICbCjBnfrIYbLBYh9256086 = reNVMUQICbCjBnfrIYbLBYh3953361;     reNVMUQICbCjBnfrIYbLBYh3953361 = reNVMUQICbCjBnfrIYbLBYh97603977;     reNVMUQICbCjBnfrIYbLBYh97603977 = reNVMUQICbCjBnfrIYbLBYh33798101;     reNVMUQICbCjBnfrIYbLBYh33798101 = reNVMUQICbCjBnfrIYbLBYh59916697;     reNVMUQICbCjBnfrIYbLBYh59916697 = reNVMUQICbCjBnfrIYbLBYh3850201;     reNVMUQICbCjBnfrIYbLBYh3850201 = reNVMUQICbCjBnfrIYbLBYh89966409;     reNVMUQICbCjBnfrIYbLBYh89966409 = reNVMUQICbCjBnfrIYbLBYh23410307;     reNVMUQICbCjBnfrIYbLBYh23410307 = reNVMUQICbCjBnfrIYbLBYh44742096;     reNVMUQICbCjBnfrIYbLBYh44742096 = reNVMUQICbCjBnfrIYbLBYh76671456;     reNVMUQICbCjBnfrIYbLBYh76671456 = reNVMUQICbCjBnfrIYbLBYh59754575;     reNVMUQICbCjBnfrIYbLBYh59754575 = reNVMUQICbCjBnfrIYbLBYh12447204;     reNVMUQICbCjBnfrIYbLBYh12447204 = reNVMUQICbCjBnfrIYbLBYh8777324;     reNVMUQICbCjBnfrIYbLBYh8777324 = reNVMUQICbCjBnfrIYbLBYh24681741;     reNVMUQICbCjBnfrIYbLBYh24681741 = reNVMUQICbCjBnfrIYbLBYh77574856;     reNVMUQICbCjBnfrIYbLBYh77574856 = reNVMUQICbCjBnfrIYbLBYh1430441;     reNVMUQICbCjBnfrIYbLBYh1430441 = reNVMUQICbCjBnfrIYbLBYh96102765;     reNVMUQICbCjBnfrIYbLBYh96102765 = reNVMUQICbCjBnfrIYbLBYh18151886;     reNVMUQICbCjBnfrIYbLBYh18151886 = reNVMUQICbCjBnfrIYbLBYh23121596;     reNVMUQICbCjBnfrIYbLBYh23121596 = reNVMUQICbCjBnfrIYbLBYh81147549;     reNVMUQICbCjBnfrIYbLBYh81147549 = reNVMUQICbCjBnfrIYbLBYh46041913;     reNVMUQICbCjBnfrIYbLBYh46041913 = reNVMUQICbCjBnfrIYbLBYh90753195;     reNVMUQICbCjBnfrIYbLBYh90753195 = reNVMUQICbCjBnfrIYbLBYh80778805;     reNVMUQICbCjBnfrIYbLBYh80778805 = reNVMUQICbCjBnfrIYbLBYh49946102;     reNVMUQICbCjBnfrIYbLBYh49946102 = reNVMUQICbCjBnfrIYbLBYh69729862;     reNVMUQICbCjBnfrIYbLBYh69729862 = reNVMUQICbCjBnfrIYbLBYh21724777;     reNVMUQICbCjBnfrIYbLBYh21724777 = reNVMUQICbCjBnfrIYbLBYh25043823;     reNVMUQICbCjBnfrIYbLBYh25043823 = reNVMUQICbCjBnfrIYbLBYh91945533;     reNVMUQICbCjBnfrIYbLBYh91945533 = reNVMUQICbCjBnfrIYbLBYh74904426;     reNVMUQICbCjBnfrIYbLBYh74904426 = reNVMUQICbCjBnfrIYbLBYh72868510;     reNVMUQICbCjBnfrIYbLBYh72868510 = reNVMUQICbCjBnfrIYbLBYh56623562;     reNVMUQICbCjBnfrIYbLBYh56623562 = reNVMUQICbCjBnfrIYbLBYh87667652;     reNVMUQICbCjBnfrIYbLBYh87667652 = reNVMUQICbCjBnfrIYbLBYh60413619;     reNVMUQICbCjBnfrIYbLBYh60413619 = reNVMUQICbCjBnfrIYbLBYh70592921;     reNVMUQICbCjBnfrIYbLBYh70592921 = reNVMUQICbCjBnfrIYbLBYh63350825;     reNVMUQICbCjBnfrIYbLBYh63350825 = reNVMUQICbCjBnfrIYbLBYh79760633;     reNVMUQICbCjBnfrIYbLBYh79760633 = reNVMUQICbCjBnfrIYbLBYh95193129;     reNVMUQICbCjBnfrIYbLBYh95193129 = reNVMUQICbCjBnfrIYbLBYh55225244;     reNVMUQICbCjBnfrIYbLBYh55225244 = reNVMUQICbCjBnfrIYbLBYh87297602;     reNVMUQICbCjBnfrIYbLBYh87297602 = reNVMUQICbCjBnfrIYbLBYh13312434;     reNVMUQICbCjBnfrIYbLBYh13312434 = reNVMUQICbCjBnfrIYbLBYh47665282;     reNVMUQICbCjBnfrIYbLBYh47665282 = reNVMUQICbCjBnfrIYbLBYh27245139;     reNVMUQICbCjBnfrIYbLBYh27245139 = reNVMUQICbCjBnfrIYbLBYh98424489;}



void HCDuCUvZtrsROwUKljtdZkGMhR61922177() {     float QRrGlvHYSQNtCLzBIbIzRax82148007 = -561557704;    float QRrGlvHYSQNtCLzBIbIzRax6663971 = -795214676;    float QRrGlvHYSQNtCLzBIbIzRax94474053 = -232421573;    float QRrGlvHYSQNtCLzBIbIzRax13577908 = -556149135;    float QRrGlvHYSQNtCLzBIbIzRax41731974 = -145075762;    float QRrGlvHYSQNtCLzBIbIzRax76452001 = -708826333;    float QRrGlvHYSQNtCLzBIbIzRax93649620 = -600725398;    float QRrGlvHYSQNtCLzBIbIzRax47656374 = -796810488;    float QRrGlvHYSQNtCLzBIbIzRax39658414 = -23272999;    float QRrGlvHYSQNtCLzBIbIzRax43845910 = -196287075;    float QRrGlvHYSQNtCLzBIbIzRax17510945 = -455079956;    float QRrGlvHYSQNtCLzBIbIzRax56126024 = -828609350;    float QRrGlvHYSQNtCLzBIbIzRax95842023 = -148196920;    float QRrGlvHYSQNtCLzBIbIzRax99935631 = -46151071;    float QRrGlvHYSQNtCLzBIbIzRax67326714 = -670777192;    float QRrGlvHYSQNtCLzBIbIzRax60374851 = -399891022;    float QRrGlvHYSQNtCLzBIbIzRax97154062 = -454129234;    float QRrGlvHYSQNtCLzBIbIzRax75366120 = -190740442;    float QRrGlvHYSQNtCLzBIbIzRax35204028 = 78220922;    float QRrGlvHYSQNtCLzBIbIzRax59233755 = -638063276;    float QRrGlvHYSQNtCLzBIbIzRax32705696 = -40901832;    float QRrGlvHYSQNtCLzBIbIzRax41286301 = -122545847;    float QRrGlvHYSQNtCLzBIbIzRax87955106 = -808867909;    float QRrGlvHYSQNtCLzBIbIzRax97840053 = -846276507;    float QRrGlvHYSQNtCLzBIbIzRax43775962 = -505961339;    float QRrGlvHYSQNtCLzBIbIzRax11210035 = 77061397;    float QRrGlvHYSQNtCLzBIbIzRax89100445 = -769235354;    float QRrGlvHYSQNtCLzBIbIzRax65570156 = -810485035;    float QRrGlvHYSQNtCLzBIbIzRax16317735 = -355585489;    float QRrGlvHYSQNtCLzBIbIzRax21137012 = -122953639;    float QRrGlvHYSQNtCLzBIbIzRax89138334 = -879700903;    float QRrGlvHYSQNtCLzBIbIzRax76004890 = -341296436;    float QRrGlvHYSQNtCLzBIbIzRax35296859 = -196909150;    float QRrGlvHYSQNtCLzBIbIzRax3841430 = -97332141;    float QRrGlvHYSQNtCLzBIbIzRax13411238 = -524469825;    float QRrGlvHYSQNtCLzBIbIzRax20561487 = -98266798;    float QRrGlvHYSQNtCLzBIbIzRax79547089 = -306820294;    float QRrGlvHYSQNtCLzBIbIzRax22988702 = -580847527;    float QRrGlvHYSQNtCLzBIbIzRax44329713 = -119458773;    float QRrGlvHYSQNtCLzBIbIzRax31986223 = 34340831;    float QRrGlvHYSQNtCLzBIbIzRax53790866 = -59428001;    float QRrGlvHYSQNtCLzBIbIzRax76554026 = -605721083;    float QRrGlvHYSQNtCLzBIbIzRax49962780 = -425060338;    float QRrGlvHYSQNtCLzBIbIzRax84827211 = -982838489;    float QRrGlvHYSQNtCLzBIbIzRax78642696 = -746875203;    float QRrGlvHYSQNtCLzBIbIzRax60687556 = -51011801;    float QRrGlvHYSQNtCLzBIbIzRax10617442 = -939759099;    float QRrGlvHYSQNtCLzBIbIzRax56304251 = -268794612;    float QRrGlvHYSQNtCLzBIbIzRax87115307 = -77337299;    float QRrGlvHYSQNtCLzBIbIzRax58548147 = -9127637;    float QRrGlvHYSQNtCLzBIbIzRax635694 = -163045347;    float QRrGlvHYSQNtCLzBIbIzRax67334098 = -211890292;    float QRrGlvHYSQNtCLzBIbIzRax21689579 = -632365762;    float QRrGlvHYSQNtCLzBIbIzRax94236253 = 69379274;    float QRrGlvHYSQNtCLzBIbIzRax29216481 = -450595103;    float QRrGlvHYSQNtCLzBIbIzRax40861706 = -339011858;    float QRrGlvHYSQNtCLzBIbIzRax18708864 = -986346767;    float QRrGlvHYSQNtCLzBIbIzRax96634000 = -386145066;    float QRrGlvHYSQNtCLzBIbIzRax69801945 = 49812204;    float QRrGlvHYSQNtCLzBIbIzRax30521940 = -122137159;    float QRrGlvHYSQNtCLzBIbIzRax87351555 = -939590980;    float QRrGlvHYSQNtCLzBIbIzRax28079464 = -790240364;    float QRrGlvHYSQNtCLzBIbIzRax31338639 = -341224999;    float QRrGlvHYSQNtCLzBIbIzRax18521402 = -900319361;    float QRrGlvHYSQNtCLzBIbIzRax54707575 = -316586172;    float QRrGlvHYSQNtCLzBIbIzRax41506054 = -13783520;    float QRrGlvHYSQNtCLzBIbIzRax20829165 = -531700200;    float QRrGlvHYSQNtCLzBIbIzRax92000593 = 49135220;    float QRrGlvHYSQNtCLzBIbIzRax86524394 = -521681247;    float QRrGlvHYSQNtCLzBIbIzRax46765228 = -472510395;    float QRrGlvHYSQNtCLzBIbIzRax80827761 = 6929272;    float QRrGlvHYSQNtCLzBIbIzRax74165360 = -873281708;    float QRrGlvHYSQNtCLzBIbIzRax31036407 = 28718330;    float QRrGlvHYSQNtCLzBIbIzRax3217805 = -956119909;    float QRrGlvHYSQNtCLzBIbIzRax5442890 = -478635275;    float QRrGlvHYSQNtCLzBIbIzRax56151669 = -435180750;    float QRrGlvHYSQNtCLzBIbIzRax91323520 = -697485510;    float QRrGlvHYSQNtCLzBIbIzRax3127896 = -826029421;    float QRrGlvHYSQNtCLzBIbIzRax19197357 = 598696;    float QRrGlvHYSQNtCLzBIbIzRax83088406 = -354949539;    float QRrGlvHYSQNtCLzBIbIzRax592594 = 16820496;    float QRrGlvHYSQNtCLzBIbIzRax32796194 = -400440742;    float QRrGlvHYSQNtCLzBIbIzRax78454849 = -633147736;    float QRrGlvHYSQNtCLzBIbIzRax57769588 = -246457853;    float QRrGlvHYSQNtCLzBIbIzRax20501318 = -959908293;    float QRrGlvHYSQNtCLzBIbIzRax21804237 = -567810611;    float QRrGlvHYSQNtCLzBIbIzRax54315312 = -708930675;    float QRrGlvHYSQNtCLzBIbIzRax41060606 = -166288424;    float QRrGlvHYSQNtCLzBIbIzRax74624949 = -646737038;    float QRrGlvHYSQNtCLzBIbIzRax72549531 = -85457968;    float QRrGlvHYSQNtCLzBIbIzRax1852623 = -111920031;    float QRrGlvHYSQNtCLzBIbIzRax82913089 = -920675228;    float QRrGlvHYSQNtCLzBIbIzRax53186756 = -530659731;    float QRrGlvHYSQNtCLzBIbIzRax13807774 = -997321614;    float QRrGlvHYSQNtCLzBIbIzRax44634668 = -26068190;    float QRrGlvHYSQNtCLzBIbIzRax25711402 = -269187638;    float QRrGlvHYSQNtCLzBIbIzRax45215388 = -164496085;    float QRrGlvHYSQNtCLzBIbIzRax31441378 = -524740978;    float QRrGlvHYSQNtCLzBIbIzRax30119636 = -566252317;    float QRrGlvHYSQNtCLzBIbIzRax37136642 = -561557704;     QRrGlvHYSQNtCLzBIbIzRax82148007 = QRrGlvHYSQNtCLzBIbIzRax6663971;     QRrGlvHYSQNtCLzBIbIzRax6663971 = QRrGlvHYSQNtCLzBIbIzRax94474053;     QRrGlvHYSQNtCLzBIbIzRax94474053 = QRrGlvHYSQNtCLzBIbIzRax13577908;     QRrGlvHYSQNtCLzBIbIzRax13577908 = QRrGlvHYSQNtCLzBIbIzRax41731974;     QRrGlvHYSQNtCLzBIbIzRax41731974 = QRrGlvHYSQNtCLzBIbIzRax76452001;     QRrGlvHYSQNtCLzBIbIzRax76452001 = QRrGlvHYSQNtCLzBIbIzRax93649620;     QRrGlvHYSQNtCLzBIbIzRax93649620 = QRrGlvHYSQNtCLzBIbIzRax47656374;     QRrGlvHYSQNtCLzBIbIzRax47656374 = QRrGlvHYSQNtCLzBIbIzRax39658414;     QRrGlvHYSQNtCLzBIbIzRax39658414 = QRrGlvHYSQNtCLzBIbIzRax43845910;     QRrGlvHYSQNtCLzBIbIzRax43845910 = QRrGlvHYSQNtCLzBIbIzRax17510945;     QRrGlvHYSQNtCLzBIbIzRax17510945 = QRrGlvHYSQNtCLzBIbIzRax56126024;     QRrGlvHYSQNtCLzBIbIzRax56126024 = QRrGlvHYSQNtCLzBIbIzRax95842023;     QRrGlvHYSQNtCLzBIbIzRax95842023 = QRrGlvHYSQNtCLzBIbIzRax99935631;     QRrGlvHYSQNtCLzBIbIzRax99935631 = QRrGlvHYSQNtCLzBIbIzRax67326714;     QRrGlvHYSQNtCLzBIbIzRax67326714 = QRrGlvHYSQNtCLzBIbIzRax60374851;     QRrGlvHYSQNtCLzBIbIzRax60374851 = QRrGlvHYSQNtCLzBIbIzRax97154062;     QRrGlvHYSQNtCLzBIbIzRax97154062 = QRrGlvHYSQNtCLzBIbIzRax75366120;     QRrGlvHYSQNtCLzBIbIzRax75366120 = QRrGlvHYSQNtCLzBIbIzRax35204028;     QRrGlvHYSQNtCLzBIbIzRax35204028 = QRrGlvHYSQNtCLzBIbIzRax59233755;     QRrGlvHYSQNtCLzBIbIzRax59233755 = QRrGlvHYSQNtCLzBIbIzRax32705696;     QRrGlvHYSQNtCLzBIbIzRax32705696 = QRrGlvHYSQNtCLzBIbIzRax41286301;     QRrGlvHYSQNtCLzBIbIzRax41286301 = QRrGlvHYSQNtCLzBIbIzRax87955106;     QRrGlvHYSQNtCLzBIbIzRax87955106 = QRrGlvHYSQNtCLzBIbIzRax97840053;     QRrGlvHYSQNtCLzBIbIzRax97840053 = QRrGlvHYSQNtCLzBIbIzRax43775962;     QRrGlvHYSQNtCLzBIbIzRax43775962 = QRrGlvHYSQNtCLzBIbIzRax11210035;     QRrGlvHYSQNtCLzBIbIzRax11210035 = QRrGlvHYSQNtCLzBIbIzRax89100445;     QRrGlvHYSQNtCLzBIbIzRax89100445 = QRrGlvHYSQNtCLzBIbIzRax65570156;     QRrGlvHYSQNtCLzBIbIzRax65570156 = QRrGlvHYSQNtCLzBIbIzRax16317735;     QRrGlvHYSQNtCLzBIbIzRax16317735 = QRrGlvHYSQNtCLzBIbIzRax21137012;     QRrGlvHYSQNtCLzBIbIzRax21137012 = QRrGlvHYSQNtCLzBIbIzRax89138334;     QRrGlvHYSQNtCLzBIbIzRax89138334 = QRrGlvHYSQNtCLzBIbIzRax76004890;     QRrGlvHYSQNtCLzBIbIzRax76004890 = QRrGlvHYSQNtCLzBIbIzRax35296859;     QRrGlvHYSQNtCLzBIbIzRax35296859 = QRrGlvHYSQNtCLzBIbIzRax3841430;     QRrGlvHYSQNtCLzBIbIzRax3841430 = QRrGlvHYSQNtCLzBIbIzRax13411238;     QRrGlvHYSQNtCLzBIbIzRax13411238 = QRrGlvHYSQNtCLzBIbIzRax20561487;     QRrGlvHYSQNtCLzBIbIzRax20561487 = QRrGlvHYSQNtCLzBIbIzRax79547089;     QRrGlvHYSQNtCLzBIbIzRax79547089 = QRrGlvHYSQNtCLzBIbIzRax22988702;     QRrGlvHYSQNtCLzBIbIzRax22988702 = QRrGlvHYSQNtCLzBIbIzRax44329713;     QRrGlvHYSQNtCLzBIbIzRax44329713 = QRrGlvHYSQNtCLzBIbIzRax31986223;     QRrGlvHYSQNtCLzBIbIzRax31986223 = QRrGlvHYSQNtCLzBIbIzRax53790866;     QRrGlvHYSQNtCLzBIbIzRax53790866 = QRrGlvHYSQNtCLzBIbIzRax76554026;     QRrGlvHYSQNtCLzBIbIzRax76554026 = QRrGlvHYSQNtCLzBIbIzRax49962780;     QRrGlvHYSQNtCLzBIbIzRax49962780 = QRrGlvHYSQNtCLzBIbIzRax84827211;     QRrGlvHYSQNtCLzBIbIzRax84827211 = QRrGlvHYSQNtCLzBIbIzRax78642696;     QRrGlvHYSQNtCLzBIbIzRax78642696 = QRrGlvHYSQNtCLzBIbIzRax60687556;     QRrGlvHYSQNtCLzBIbIzRax60687556 = QRrGlvHYSQNtCLzBIbIzRax10617442;     QRrGlvHYSQNtCLzBIbIzRax10617442 = QRrGlvHYSQNtCLzBIbIzRax56304251;     QRrGlvHYSQNtCLzBIbIzRax56304251 = QRrGlvHYSQNtCLzBIbIzRax87115307;     QRrGlvHYSQNtCLzBIbIzRax87115307 = QRrGlvHYSQNtCLzBIbIzRax58548147;     QRrGlvHYSQNtCLzBIbIzRax58548147 = QRrGlvHYSQNtCLzBIbIzRax635694;     QRrGlvHYSQNtCLzBIbIzRax635694 = QRrGlvHYSQNtCLzBIbIzRax67334098;     QRrGlvHYSQNtCLzBIbIzRax67334098 = QRrGlvHYSQNtCLzBIbIzRax21689579;     QRrGlvHYSQNtCLzBIbIzRax21689579 = QRrGlvHYSQNtCLzBIbIzRax94236253;     QRrGlvHYSQNtCLzBIbIzRax94236253 = QRrGlvHYSQNtCLzBIbIzRax29216481;     QRrGlvHYSQNtCLzBIbIzRax29216481 = QRrGlvHYSQNtCLzBIbIzRax40861706;     QRrGlvHYSQNtCLzBIbIzRax40861706 = QRrGlvHYSQNtCLzBIbIzRax18708864;     QRrGlvHYSQNtCLzBIbIzRax18708864 = QRrGlvHYSQNtCLzBIbIzRax96634000;     QRrGlvHYSQNtCLzBIbIzRax96634000 = QRrGlvHYSQNtCLzBIbIzRax69801945;     QRrGlvHYSQNtCLzBIbIzRax69801945 = QRrGlvHYSQNtCLzBIbIzRax30521940;     QRrGlvHYSQNtCLzBIbIzRax30521940 = QRrGlvHYSQNtCLzBIbIzRax87351555;     QRrGlvHYSQNtCLzBIbIzRax87351555 = QRrGlvHYSQNtCLzBIbIzRax28079464;     QRrGlvHYSQNtCLzBIbIzRax28079464 = QRrGlvHYSQNtCLzBIbIzRax31338639;     QRrGlvHYSQNtCLzBIbIzRax31338639 = QRrGlvHYSQNtCLzBIbIzRax18521402;     QRrGlvHYSQNtCLzBIbIzRax18521402 = QRrGlvHYSQNtCLzBIbIzRax54707575;     QRrGlvHYSQNtCLzBIbIzRax54707575 = QRrGlvHYSQNtCLzBIbIzRax41506054;     QRrGlvHYSQNtCLzBIbIzRax41506054 = QRrGlvHYSQNtCLzBIbIzRax20829165;     QRrGlvHYSQNtCLzBIbIzRax20829165 = QRrGlvHYSQNtCLzBIbIzRax92000593;     QRrGlvHYSQNtCLzBIbIzRax92000593 = QRrGlvHYSQNtCLzBIbIzRax86524394;     QRrGlvHYSQNtCLzBIbIzRax86524394 = QRrGlvHYSQNtCLzBIbIzRax46765228;     QRrGlvHYSQNtCLzBIbIzRax46765228 = QRrGlvHYSQNtCLzBIbIzRax80827761;     QRrGlvHYSQNtCLzBIbIzRax80827761 = QRrGlvHYSQNtCLzBIbIzRax74165360;     QRrGlvHYSQNtCLzBIbIzRax74165360 = QRrGlvHYSQNtCLzBIbIzRax31036407;     QRrGlvHYSQNtCLzBIbIzRax31036407 = QRrGlvHYSQNtCLzBIbIzRax3217805;     QRrGlvHYSQNtCLzBIbIzRax3217805 = QRrGlvHYSQNtCLzBIbIzRax5442890;     QRrGlvHYSQNtCLzBIbIzRax5442890 = QRrGlvHYSQNtCLzBIbIzRax56151669;     QRrGlvHYSQNtCLzBIbIzRax56151669 = QRrGlvHYSQNtCLzBIbIzRax91323520;     QRrGlvHYSQNtCLzBIbIzRax91323520 = QRrGlvHYSQNtCLzBIbIzRax3127896;     QRrGlvHYSQNtCLzBIbIzRax3127896 = QRrGlvHYSQNtCLzBIbIzRax19197357;     QRrGlvHYSQNtCLzBIbIzRax19197357 = QRrGlvHYSQNtCLzBIbIzRax83088406;     QRrGlvHYSQNtCLzBIbIzRax83088406 = QRrGlvHYSQNtCLzBIbIzRax592594;     QRrGlvHYSQNtCLzBIbIzRax592594 = QRrGlvHYSQNtCLzBIbIzRax32796194;     QRrGlvHYSQNtCLzBIbIzRax32796194 = QRrGlvHYSQNtCLzBIbIzRax78454849;     QRrGlvHYSQNtCLzBIbIzRax78454849 = QRrGlvHYSQNtCLzBIbIzRax57769588;     QRrGlvHYSQNtCLzBIbIzRax57769588 = QRrGlvHYSQNtCLzBIbIzRax20501318;     QRrGlvHYSQNtCLzBIbIzRax20501318 = QRrGlvHYSQNtCLzBIbIzRax21804237;     QRrGlvHYSQNtCLzBIbIzRax21804237 = QRrGlvHYSQNtCLzBIbIzRax54315312;     QRrGlvHYSQNtCLzBIbIzRax54315312 = QRrGlvHYSQNtCLzBIbIzRax41060606;     QRrGlvHYSQNtCLzBIbIzRax41060606 = QRrGlvHYSQNtCLzBIbIzRax74624949;     QRrGlvHYSQNtCLzBIbIzRax74624949 = QRrGlvHYSQNtCLzBIbIzRax72549531;     QRrGlvHYSQNtCLzBIbIzRax72549531 = QRrGlvHYSQNtCLzBIbIzRax1852623;     QRrGlvHYSQNtCLzBIbIzRax1852623 = QRrGlvHYSQNtCLzBIbIzRax82913089;     QRrGlvHYSQNtCLzBIbIzRax82913089 = QRrGlvHYSQNtCLzBIbIzRax53186756;     QRrGlvHYSQNtCLzBIbIzRax53186756 = QRrGlvHYSQNtCLzBIbIzRax13807774;     QRrGlvHYSQNtCLzBIbIzRax13807774 = QRrGlvHYSQNtCLzBIbIzRax44634668;     QRrGlvHYSQNtCLzBIbIzRax44634668 = QRrGlvHYSQNtCLzBIbIzRax25711402;     QRrGlvHYSQNtCLzBIbIzRax25711402 = QRrGlvHYSQNtCLzBIbIzRax45215388;     QRrGlvHYSQNtCLzBIbIzRax45215388 = QRrGlvHYSQNtCLzBIbIzRax31441378;     QRrGlvHYSQNtCLzBIbIzRax31441378 = QRrGlvHYSQNtCLzBIbIzRax30119636;     QRrGlvHYSQNtCLzBIbIzRax30119636 = QRrGlvHYSQNtCLzBIbIzRax37136642;     QRrGlvHYSQNtCLzBIbIzRax37136642 = QRrGlvHYSQNtCLzBIbIzRax82148007;}



void TlOwWyLIVPXMBBOzUrZdOCMEgA46985015() {     float ngdSFkfdWAlqPDEStTeXfEw65871525 = -911579772;    float ngdSFkfdWAlqPDEStTeXfEw4262066 = -598866527;    float ngdSFkfdWAlqPDEStTeXfEw83060171 = -100729264;    float ngdSFkfdWAlqPDEStTeXfEw10725861 = -561031063;    float ngdSFkfdWAlqPDEStTeXfEw21293311 = -543023953;    float ngdSFkfdWAlqPDEStTeXfEw87791518 = -812147002;    float ngdSFkfdWAlqPDEStTeXfEw30530183 = -622239536;    float ngdSFkfdWAlqPDEStTeXfEw90996456 = -317265074;    float ngdSFkfdWAlqPDEStTeXfEw89877942 = -720755696;    float ngdSFkfdWAlqPDEStTeXfEw89951498 = -419328090;    float ngdSFkfdWAlqPDEStTeXfEw60399981 = -295365213;    float ngdSFkfdWAlqPDEStTeXfEw46337795 = -757748621;    float ngdSFkfdWAlqPDEStTeXfEw46895875 = 8970836;    float ngdSFkfdWAlqPDEStTeXfEw94308776 = -395833933;    float ngdSFkfdWAlqPDEStTeXfEw71505973 = -596474498;    float ngdSFkfdWAlqPDEStTeXfEw32188880 = -324018673;    float ngdSFkfdWAlqPDEStTeXfEw97019473 = -613009097;    float ngdSFkfdWAlqPDEStTeXfEw89443389 = -901592016;    float ngdSFkfdWAlqPDEStTeXfEw76180508 = -810428316;    float ngdSFkfdWAlqPDEStTeXfEw33341400 = -254356193;    float ngdSFkfdWAlqPDEStTeXfEw45207 = -715368353;    float ngdSFkfdWAlqPDEStTeXfEw42288372 = -35701134;    float ngdSFkfdWAlqPDEStTeXfEw57130972 = -838262646;    float ngdSFkfdWAlqPDEStTeXfEw98982748 = -385509160;    float ngdSFkfdWAlqPDEStTeXfEw80378055 = -584292101;    float ngdSFkfdWAlqPDEStTeXfEw64202792 = -365905631;    float ngdSFkfdWAlqPDEStTeXfEw10692385 = -113110777;    float ngdSFkfdWAlqPDEStTeXfEw8169357 = -596926523;    float ngdSFkfdWAlqPDEStTeXfEw88235876 = -879781390;    float ngdSFkfdWAlqPDEStTeXfEw56685339 = -795560014;    float ngdSFkfdWAlqPDEStTeXfEw70502757 = 1201077;    float ngdSFkfdWAlqPDEStTeXfEw798179 = -890493659;    float ngdSFkfdWAlqPDEStTeXfEw49421560 = -862123241;    float ngdSFkfdWAlqPDEStTeXfEw39566144 = -501428789;    float ngdSFkfdWAlqPDEStTeXfEw81014563 = -258760432;    float ngdSFkfdWAlqPDEStTeXfEw90422720 = -76663275;    float ngdSFkfdWAlqPDEStTeXfEw79310680 = -627161590;    float ngdSFkfdWAlqPDEStTeXfEw73370493 = -479990743;    float ngdSFkfdWAlqPDEStTeXfEw4945433 = -425017654;    float ngdSFkfdWAlqPDEStTeXfEw71175339 = 87693951;    float ngdSFkfdWAlqPDEStTeXfEw18558387 = -809468128;    float ngdSFkfdWAlqPDEStTeXfEw5893754 = -211746752;    float ngdSFkfdWAlqPDEStTeXfEw82762926 = -77464592;    float ngdSFkfdWAlqPDEStTeXfEw32022731 = -561782221;    float ngdSFkfdWAlqPDEStTeXfEw6629948 = 27110718;    float ngdSFkfdWAlqPDEStTeXfEw4954438 = -766043493;    float ngdSFkfdWAlqPDEStTeXfEw43796411 = -961405006;    float ngdSFkfdWAlqPDEStTeXfEw95046098 = -30916510;    float ngdSFkfdWAlqPDEStTeXfEw20989521 = -877121450;    float ngdSFkfdWAlqPDEStTeXfEw94421477 = -641143072;    float ngdSFkfdWAlqPDEStTeXfEw40726526 = -328817748;    float ngdSFkfdWAlqPDEStTeXfEw18839818 = 36056921;    float ngdSFkfdWAlqPDEStTeXfEw67071981 = -644298128;    float ngdSFkfdWAlqPDEStTeXfEw40168859 = -507329914;    float ngdSFkfdWAlqPDEStTeXfEw46939809 = -767322048;    float ngdSFkfdWAlqPDEStTeXfEw23583153 = -775878638;    float ngdSFkfdWAlqPDEStTeXfEw47131094 = -760603882;    float ngdSFkfdWAlqPDEStTeXfEw84077422 = -715220104;    float ngdSFkfdWAlqPDEStTeXfEw30347806 = -976738963;    float ngdSFkfdWAlqPDEStTeXfEw57090518 = -77118323;    float ngdSFkfdWAlqPDEStTeXfEw77099134 = -599036226;    float ngdSFkfdWAlqPDEStTeXfEw22360827 = 74686987;    float ngdSFkfdWAlqPDEStTeXfEw2760580 = -437483684;    float ngdSFkfdWAlqPDEStTeXfEw33192603 = -925195682;    float ngdSFkfdWAlqPDEStTeXfEw19448741 = -320529167;    float ngdSFkfdWAlqPDEStTeXfEw59601802 = -404871555;    float ngdSFkfdWAlqPDEStTeXfEw96916234 = -895625380;    float ngdSFkfdWAlqPDEStTeXfEw7329732 = -489600376;    float ngdSFkfdWAlqPDEStTeXfEw13294214 = -37073502;    float ngdSFkfdWAlqPDEStTeXfEw81083253 = -419811223;    float ngdSFkfdWAlqPDEStTeXfEw52878200 = -696857083;    float ngdSFkfdWAlqPDEStTeXfEw23648980 = -33018354;    float ngdSFkfdWAlqPDEStTeXfEw84497957 = -376574362;    float ngdSFkfdWAlqPDEStTeXfEw5005170 = -798122268;    float ngdSFkfdWAlqPDEStTeXfEw14783013 = -444888066;    float ngdSFkfdWAlqPDEStTeXfEw94151453 = -403621601;    float ngdSFkfdWAlqPDEStTeXfEw59525445 = -958236542;    float ngdSFkfdWAlqPDEStTeXfEw25108241 = -176480425;    float ngdSFkfdWAlqPDEStTeXfEw92352801 = -312619879;    float ngdSFkfdWAlqPDEStTeXfEw75423618 = -818248608;    float ngdSFkfdWAlqPDEStTeXfEw20406382 = -404500625;    float ngdSFkfdWAlqPDEStTeXfEw15646286 = 17805733;    float ngdSFkfdWAlqPDEStTeXfEw87179835 = -719805073;    float ngdSFkfdWAlqPDEStTeXfEw93814399 = -138638318;    float ngdSFkfdWAlqPDEStTeXfEw15958814 = -366742266;    float ngdSFkfdWAlqPDEStTeXfEw51662940 = 65144155;    float ngdSFkfdWAlqPDEStTeXfEw33726198 = -146195532;    float ngdSFkfdWAlqPDEStTeXfEw9252702 = -254793328;    float ngdSFkfdWAlqPDEStTeXfEw92626335 = -734106741;    float ngdSFkfdWAlqPDEStTeXfEw57431410 = -482881794;    float ngdSFkfdWAlqPDEStTeXfEw43291626 = -316059394;    float ngdSFkfdWAlqPDEStTeXfEw95233257 = -911941487;    float ngdSFkfdWAlqPDEStTeXfEw43022687 = -503251781;    float ngdSFkfdWAlqPDEStTeXfEw47854914 = -247899332;    float ngdSFkfdWAlqPDEStTeXfEw94076205 = -313269823;    float ngdSFkfdWAlqPDEStTeXfEw96197559 = -784155115;    float ngdSFkfdWAlqPDEStTeXfEw3133174 = -774263068;    float ngdSFkfdWAlqPDEStTeXfEw49570323 = -152268910;    float ngdSFkfdWAlqPDEStTeXfEw12573991 = -141253054;    float ngdSFkfdWAlqPDEStTeXfEw47028145 = -911579772;     ngdSFkfdWAlqPDEStTeXfEw65871525 = ngdSFkfdWAlqPDEStTeXfEw4262066;     ngdSFkfdWAlqPDEStTeXfEw4262066 = ngdSFkfdWAlqPDEStTeXfEw83060171;     ngdSFkfdWAlqPDEStTeXfEw83060171 = ngdSFkfdWAlqPDEStTeXfEw10725861;     ngdSFkfdWAlqPDEStTeXfEw10725861 = ngdSFkfdWAlqPDEStTeXfEw21293311;     ngdSFkfdWAlqPDEStTeXfEw21293311 = ngdSFkfdWAlqPDEStTeXfEw87791518;     ngdSFkfdWAlqPDEStTeXfEw87791518 = ngdSFkfdWAlqPDEStTeXfEw30530183;     ngdSFkfdWAlqPDEStTeXfEw30530183 = ngdSFkfdWAlqPDEStTeXfEw90996456;     ngdSFkfdWAlqPDEStTeXfEw90996456 = ngdSFkfdWAlqPDEStTeXfEw89877942;     ngdSFkfdWAlqPDEStTeXfEw89877942 = ngdSFkfdWAlqPDEStTeXfEw89951498;     ngdSFkfdWAlqPDEStTeXfEw89951498 = ngdSFkfdWAlqPDEStTeXfEw60399981;     ngdSFkfdWAlqPDEStTeXfEw60399981 = ngdSFkfdWAlqPDEStTeXfEw46337795;     ngdSFkfdWAlqPDEStTeXfEw46337795 = ngdSFkfdWAlqPDEStTeXfEw46895875;     ngdSFkfdWAlqPDEStTeXfEw46895875 = ngdSFkfdWAlqPDEStTeXfEw94308776;     ngdSFkfdWAlqPDEStTeXfEw94308776 = ngdSFkfdWAlqPDEStTeXfEw71505973;     ngdSFkfdWAlqPDEStTeXfEw71505973 = ngdSFkfdWAlqPDEStTeXfEw32188880;     ngdSFkfdWAlqPDEStTeXfEw32188880 = ngdSFkfdWAlqPDEStTeXfEw97019473;     ngdSFkfdWAlqPDEStTeXfEw97019473 = ngdSFkfdWAlqPDEStTeXfEw89443389;     ngdSFkfdWAlqPDEStTeXfEw89443389 = ngdSFkfdWAlqPDEStTeXfEw76180508;     ngdSFkfdWAlqPDEStTeXfEw76180508 = ngdSFkfdWAlqPDEStTeXfEw33341400;     ngdSFkfdWAlqPDEStTeXfEw33341400 = ngdSFkfdWAlqPDEStTeXfEw45207;     ngdSFkfdWAlqPDEStTeXfEw45207 = ngdSFkfdWAlqPDEStTeXfEw42288372;     ngdSFkfdWAlqPDEStTeXfEw42288372 = ngdSFkfdWAlqPDEStTeXfEw57130972;     ngdSFkfdWAlqPDEStTeXfEw57130972 = ngdSFkfdWAlqPDEStTeXfEw98982748;     ngdSFkfdWAlqPDEStTeXfEw98982748 = ngdSFkfdWAlqPDEStTeXfEw80378055;     ngdSFkfdWAlqPDEStTeXfEw80378055 = ngdSFkfdWAlqPDEStTeXfEw64202792;     ngdSFkfdWAlqPDEStTeXfEw64202792 = ngdSFkfdWAlqPDEStTeXfEw10692385;     ngdSFkfdWAlqPDEStTeXfEw10692385 = ngdSFkfdWAlqPDEStTeXfEw8169357;     ngdSFkfdWAlqPDEStTeXfEw8169357 = ngdSFkfdWAlqPDEStTeXfEw88235876;     ngdSFkfdWAlqPDEStTeXfEw88235876 = ngdSFkfdWAlqPDEStTeXfEw56685339;     ngdSFkfdWAlqPDEStTeXfEw56685339 = ngdSFkfdWAlqPDEStTeXfEw70502757;     ngdSFkfdWAlqPDEStTeXfEw70502757 = ngdSFkfdWAlqPDEStTeXfEw798179;     ngdSFkfdWAlqPDEStTeXfEw798179 = ngdSFkfdWAlqPDEStTeXfEw49421560;     ngdSFkfdWAlqPDEStTeXfEw49421560 = ngdSFkfdWAlqPDEStTeXfEw39566144;     ngdSFkfdWAlqPDEStTeXfEw39566144 = ngdSFkfdWAlqPDEStTeXfEw81014563;     ngdSFkfdWAlqPDEStTeXfEw81014563 = ngdSFkfdWAlqPDEStTeXfEw90422720;     ngdSFkfdWAlqPDEStTeXfEw90422720 = ngdSFkfdWAlqPDEStTeXfEw79310680;     ngdSFkfdWAlqPDEStTeXfEw79310680 = ngdSFkfdWAlqPDEStTeXfEw73370493;     ngdSFkfdWAlqPDEStTeXfEw73370493 = ngdSFkfdWAlqPDEStTeXfEw4945433;     ngdSFkfdWAlqPDEStTeXfEw4945433 = ngdSFkfdWAlqPDEStTeXfEw71175339;     ngdSFkfdWAlqPDEStTeXfEw71175339 = ngdSFkfdWAlqPDEStTeXfEw18558387;     ngdSFkfdWAlqPDEStTeXfEw18558387 = ngdSFkfdWAlqPDEStTeXfEw5893754;     ngdSFkfdWAlqPDEStTeXfEw5893754 = ngdSFkfdWAlqPDEStTeXfEw82762926;     ngdSFkfdWAlqPDEStTeXfEw82762926 = ngdSFkfdWAlqPDEStTeXfEw32022731;     ngdSFkfdWAlqPDEStTeXfEw32022731 = ngdSFkfdWAlqPDEStTeXfEw6629948;     ngdSFkfdWAlqPDEStTeXfEw6629948 = ngdSFkfdWAlqPDEStTeXfEw4954438;     ngdSFkfdWAlqPDEStTeXfEw4954438 = ngdSFkfdWAlqPDEStTeXfEw43796411;     ngdSFkfdWAlqPDEStTeXfEw43796411 = ngdSFkfdWAlqPDEStTeXfEw95046098;     ngdSFkfdWAlqPDEStTeXfEw95046098 = ngdSFkfdWAlqPDEStTeXfEw20989521;     ngdSFkfdWAlqPDEStTeXfEw20989521 = ngdSFkfdWAlqPDEStTeXfEw94421477;     ngdSFkfdWAlqPDEStTeXfEw94421477 = ngdSFkfdWAlqPDEStTeXfEw40726526;     ngdSFkfdWAlqPDEStTeXfEw40726526 = ngdSFkfdWAlqPDEStTeXfEw18839818;     ngdSFkfdWAlqPDEStTeXfEw18839818 = ngdSFkfdWAlqPDEStTeXfEw67071981;     ngdSFkfdWAlqPDEStTeXfEw67071981 = ngdSFkfdWAlqPDEStTeXfEw40168859;     ngdSFkfdWAlqPDEStTeXfEw40168859 = ngdSFkfdWAlqPDEStTeXfEw46939809;     ngdSFkfdWAlqPDEStTeXfEw46939809 = ngdSFkfdWAlqPDEStTeXfEw23583153;     ngdSFkfdWAlqPDEStTeXfEw23583153 = ngdSFkfdWAlqPDEStTeXfEw47131094;     ngdSFkfdWAlqPDEStTeXfEw47131094 = ngdSFkfdWAlqPDEStTeXfEw84077422;     ngdSFkfdWAlqPDEStTeXfEw84077422 = ngdSFkfdWAlqPDEStTeXfEw30347806;     ngdSFkfdWAlqPDEStTeXfEw30347806 = ngdSFkfdWAlqPDEStTeXfEw57090518;     ngdSFkfdWAlqPDEStTeXfEw57090518 = ngdSFkfdWAlqPDEStTeXfEw77099134;     ngdSFkfdWAlqPDEStTeXfEw77099134 = ngdSFkfdWAlqPDEStTeXfEw22360827;     ngdSFkfdWAlqPDEStTeXfEw22360827 = ngdSFkfdWAlqPDEStTeXfEw2760580;     ngdSFkfdWAlqPDEStTeXfEw2760580 = ngdSFkfdWAlqPDEStTeXfEw33192603;     ngdSFkfdWAlqPDEStTeXfEw33192603 = ngdSFkfdWAlqPDEStTeXfEw19448741;     ngdSFkfdWAlqPDEStTeXfEw19448741 = ngdSFkfdWAlqPDEStTeXfEw59601802;     ngdSFkfdWAlqPDEStTeXfEw59601802 = ngdSFkfdWAlqPDEStTeXfEw96916234;     ngdSFkfdWAlqPDEStTeXfEw96916234 = ngdSFkfdWAlqPDEStTeXfEw7329732;     ngdSFkfdWAlqPDEStTeXfEw7329732 = ngdSFkfdWAlqPDEStTeXfEw13294214;     ngdSFkfdWAlqPDEStTeXfEw13294214 = ngdSFkfdWAlqPDEStTeXfEw81083253;     ngdSFkfdWAlqPDEStTeXfEw81083253 = ngdSFkfdWAlqPDEStTeXfEw52878200;     ngdSFkfdWAlqPDEStTeXfEw52878200 = ngdSFkfdWAlqPDEStTeXfEw23648980;     ngdSFkfdWAlqPDEStTeXfEw23648980 = ngdSFkfdWAlqPDEStTeXfEw84497957;     ngdSFkfdWAlqPDEStTeXfEw84497957 = ngdSFkfdWAlqPDEStTeXfEw5005170;     ngdSFkfdWAlqPDEStTeXfEw5005170 = ngdSFkfdWAlqPDEStTeXfEw14783013;     ngdSFkfdWAlqPDEStTeXfEw14783013 = ngdSFkfdWAlqPDEStTeXfEw94151453;     ngdSFkfdWAlqPDEStTeXfEw94151453 = ngdSFkfdWAlqPDEStTeXfEw59525445;     ngdSFkfdWAlqPDEStTeXfEw59525445 = ngdSFkfdWAlqPDEStTeXfEw25108241;     ngdSFkfdWAlqPDEStTeXfEw25108241 = ngdSFkfdWAlqPDEStTeXfEw92352801;     ngdSFkfdWAlqPDEStTeXfEw92352801 = ngdSFkfdWAlqPDEStTeXfEw75423618;     ngdSFkfdWAlqPDEStTeXfEw75423618 = ngdSFkfdWAlqPDEStTeXfEw20406382;     ngdSFkfdWAlqPDEStTeXfEw20406382 = ngdSFkfdWAlqPDEStTeXfEw15646286;     ngdSFkfdWAlqPDEStTeXfEw15646286 = ngdSFkfdWAlqPDEStTeXfEw87179835;     ngdSFkfdWAlqPDEStTeXfEw87179835 = ngdSFkfdWAlqPDEStTeXfEw93814399;     ngdSFkfdWAlqPDEStTeXfEw93814399 = ngdSFkfdWAlqPDEStTeXfEw15958814;     ngdSFkfdWAlqPDEStTeXfEw15958814 = ngdSFkfdWAlqPDEStTeXfEw51662940;     ngdSFkfdWAlqPDEStTeXfEw51662940 = ngdSFkfdWAlqPDEStTeXfEw33726198;     ngdSFkfdWAlqPDEStTeXfEw33726198 = ngdSFkfdWAlqPDEStTeXfEw9252702;     ngdSFkfdWAlqPDEStTeXfEw9252702 = ngdSFkfdWAlqPDEStTeXfEw92626335;     ngdSFkfdWAlqPDEStTeXfEw92626335 = ngdSFkfdWAlqPDEStTeXfEw57431410;     ngdSFkfdWAlqPDEStTeXfEw57431410 = ngdSFkfdWAlqPDEStTeXfEw43291626;     ngdSFkfdWAlqPDEStTeXfEw43291626 = ngdSFkfdWAlqPDEStTeXfEw95233257;     ngdSFkfdWAlqPDEStTeXfEw95233257 = ngdSFkfdWAlqPDEStTeXfEw43022687;     ngdSFkfdWAlqPDEStTeXfEw43022687 = ngdSFkfdWAlqPDEStTeXfEw47854914;     ngdSFkfdWAlqPDEStTeXfEw47854914 = ngdSFkfdWAlqPDEStTeXfEw94076205;     ngdSFkfdWAlqPDEStTeXfEw94076205 = ngdSFkfdWAlqPDEStTeXfEw96197559;     ngdSFkfdWAlqPDEStTeXfEw96197559 = ngdSFkfdWAlqPDEStTeXfEw3133174;     ngdSFkfdWAlqPDEStTeXfEw3133174 = ngdSFkfdWAlqPDEStTeXfEw49570323;     ngdSFkfdWAlqPDEStTeXfEw49570323 = ngdSFkfdWAlqPDEStTeXfEw12573991;     ngdSFkfdWAlqPDEStTeXfEw12573991 = ngdSFkfdWAlqPDEStTeXfEw47028145;     ngdSFkfdWAlqPDEStTeXfEw47028145 = ngdSFkfdWAlqPDEStTeXfEw65871525;}



void LMdrZOxVwvkISUGeiDxpUHxfsF32047853() {     float aZZlaujFvyYVhhJcaCyEGbO49595043 = -161601839;    float aZZlaujFvyYVhhJcaCyEGbO1860162 = -402518378;    float aZZlaujFvyYVhhJcaCyEGbO71646288 = 30963046;    float aZZlaujFvyYVhhJcaCyEGbO7873814 = -565912992;    float aZZlaujFvyYVhhJcaCyEGbO854648 = -940972144;    float aZZlaujFvyYVhhJcaCyEGbO99131036 = -915467671;    float aZZlaujFvyYVhhJcaCyEGbO67410746 = -643753674;    float aZZlaujFvyYVhhJcaCyEGbO34336539 = -937719660;    float aZZlaujFvyYVhhJcaCyEGbO40097471 = -318238392;    float aZZlaujFvyYVhhJcaCyEGbO36057086 = -642369106;    float aZZlaujFvyYVhhJcaCyEGbO3289017 = -135650471;    float aZZlaujFvyYVhhJcaCyEGbO36549565 = -686887892;    float aZZlaujFvyYVhhJcaCyEGbO97949727 = -933861408;    float aZZlaujFvyYVhhJcaCyEGbO88681920 = -745516796;    float aZZlaujFvyYVhhJcaCyEGbO75685232 = -522171803;    float aZZlaujFvyYVhhJcaCyEGbO4002909 = -248146325;    float aZZlaujFvyYVhhJcaCyEGbO96884883 = -771888959;    float aZZlaujFvyYVhhJcaCyEGbO3520660 = -512443590;    float aZZlaujFvyYVhhJcaCyEGbO17156990 = -599077554;    float aZZlaujFvyYVhhJcaCyEGbO7449045 = -970649110;    float aZZlaujFvyYVhhJcaCyEGbO67384716 = -289834874;    float aZZlaujFvyYVhhJcaCyEGbO43290443 = 51143580;    float aZZlaujFvyYVhhJcaCyEGbO26306837 = -867657383;    float aZZlaujFvyYVhhJcaCyEGbO125444 = 75258186;    float aZZlaujFvyYVhhJcaCyEGbO16980148 = -662622862;    float aZZlaujFvyYVhhJcaCyEGbO17195550 = -808872658;    float aZZlaujFvyYVhhJcaCyEGbO32284324 = -556986200;    float aZZlaujFvyYVhhJcaCyEGbO50768556 = -383368011;    float aZZlaujFvyYVhhJcaCyEGbO60154018 = -303977290;    float aZZlaujFvyYVhhJcaCyEGbO92233666 = -368166388;    float aZZlaujFvyYVhhJcaCyEGbO51867181 = -217896944;    float aZZlaujFvyYVhhJcaCyEGbO25591467 = -339690882;    float aZZlaujFvyYVhhJcaCyEGbO63546261 = -427337333;    float aZZlaujFvyYVhhJcaCyEGbO75290858 = -905525437;    float aZZlaujFvyYVhhJcaCyEGbO48617888 = 6948960;    float aZZlaujFvyYVhhJcaCyEGbO60283954 = -55059753;    float aZZlaujFvyYVhhJcaCyEGbO79074270 = -947502887;    float aZZlaujFvyYVhhJcaCyEGbO23752284 = -379133960;    float aZZlaujFvyYVhhJcaCyEGbO65561151 = -730576535;    float aZZlaujFvyYVhhJcaCyEGbO10364455 = -958952928;    float aZZlaujFvyYVhhJcaCyEGbO83325907 = -459508254;    float aZZlaujFvyYVhhJcaCyEGbO35233480 = -917772422;    float aZZlaujFvyYVhhJcaCyEGbO15563073 = -829868846;    float aZZlaujFvyYVhhJcaCyEGbO79218250 = -140725954;    float aZZlaujFvyYVhhJcaCyEGbO34617198 = -298903360;    float aZZlaujFvyYVhhJcaCyEGbO49221319 = -381075185;    float aZZlaujFvyYVhhJcaCyEGbO76975380 = -983050913;    float aZZlaujFvyYVhhJcaCyEGbO33787946 = -893038408;    float aZZlaujFvyYVhhJcaCyEGbO54863734 = -576905601;    float aZZlaujFvyYVhhJcaCyEGbO30294807 = -173158508;    float aZZlaujFvyYVhhJcaCyEGbO80817357 = -494590150;    float aZZlaujFvyYVhhJcaCyEGbO70345537 = -815995865;    float aZZlaujFvyYVhhJcaCyEGbO12454384 = -656230494;    float aZZlaujFvyYVhhJcaCyEGbO86101464 = 15960899;    float aZZlaujFvyYVhhJcaCyEGbO64663136 = 15951007;    float aZZlaujFvyYVhhJcaCyEGbO6304601 = -112745419;    float aZZlaujFvyYVhhJcaCyEGbO75553324 = -534860996;    float aZZlaujFvyYVhhJcaCyEGbO71520844 = 55704859;    float aZZlaujFvyYVhhJcaCyEGbO90893666 = -903290130;    float aZZlaujFvyYVhhJcaCyEGbO83659097 = -32099487;    float aZZlaujFvyYVhhJcaCyEGbO66846712 = -258481472;    float aZZlaujFvyYVhhJcaCyEGbO16642190 = -160385663;    float aZZlaujFvyYVhhJcaCyEGbO74182521 = -533742370;    float aZZlaujFvyYVhhJcaCyEGbO47863804 = -950072004;    float aZZlaujFvyYVhhJcaCyEGbO84189905 = -324472162;    float aZZlaujFvyYVhhJcaCyEGbO77697549 = -795959590;    float aZZlaujFvyYVhhJcaCyEGbO73003304 = -159550560;    float aZZlaujFvyYVhhJcaCyEGbO22658869 = 71664029;    float aZZlaujFvyYVhhJcaCyEGbO40064033 = -652465756;    float aZZlaujFvyYVhhJcaCyEGbO15401279 = -367112051;    float aZZlaujFvyYVhhJcaCyEGbO24928639 = -300643438;    float aZZlaujFvyYVhhJcaCyEGbO73132600 = -292755000;    float aZZlaujFvyYVhhJcaCyEGbO37959508 = -781867055;    float aZZlaujFvyYVhhJcaCyEGbO6792535 = -640124627;    float aZZlaujFvyYVhhJcaCyEGbO24123137 = -411140856;    float aZZlaujFvyYVhhJcaCyEGbO32151237 = -372062453;    float aZZlaujFvyYVhhJcaCyEGbO27727370 = -118987574;    float aZZlaujFvyYVhhJcaCyEGbO47088587 = -626931429;    float aZZlaujFvyYVhhJcaCyEGbO65508245 = -625838454;    float aZZlaujFvyYVhhJcaCyEGbO67758829 = -181547678;    float aZZlaujFvyYVhhJcaCyEGbO40220170 = -825821746;    float aZZlaujFvyYVhhJcaCyEGbO98496378 = -663947792;    float aZZlaujFvyYVhhJcaCyEGbO95904822 = -806462411;    float aZZlaujFvyYVhhJcaCyEGbO29859211 = -30818783;    float aZZlaujFvyYVhhJcaCyEGbO11416310 = -873576239;    float aZZlaujFvyYVhhJcaCyEGbO81521643 = -401901080;    float aZZlaujFvyYVhhJcaCyEGbO13137084 = -683460388;    float aZZlaujFvyYVhhJcaCyEGbO77444796 = -343298232;    float aZZlaujFvyYVhhJcaCyEGbO10627722 = -821476444;    float aZZlaujFvyYVhhJcaCyEGbO42313288 = -880305621;    float aZZlaujFvyYVhhJcaCyEGbO84730629 = -520198757;    float aZZlaujFvyYVhhJcaCyEGbO7553426 = -903207746;    float aZZlaujFvyYVhhJcaCyEGbO32858618 = -475843830;    float aZZlaujFvyYVhhJcaCyEGbO81902054 = -598477049;    float aZZlaujFvyYVhhJcaCyEGbO43517743 = -600471457;    float aZZlaujFvyYVhhJcaCyEGbO66683717 = -199122592;    float aZZlaujFvyYVhhJcaCyEGbO61050959 = -284030052;    float aZZlaujFvyYVhhJcaCyEGbO67699268 = -879796843;    float aZZlaujFvyYVhhJcaCyEGbO95028344 = -816253792;    float aZZlaujFvyYVhhJcaCyEGbO56919648 = -161601839;     aZZlaujFvyYVhhJcaCyEGbO49595043 = aZZlaujFvyYVhhJcaCyEGbO1860162;     aZZlaujFvyYVhhJcaCyEGbO1860162 = aZZlaujFvyYVhhJcaCyEGbO71646288;     aZZlaujFvyYVhhJcaCyEGbO71646288 = aZZlaujFvyYVhhJcaCyEGbO7873814;     aZZlaujFvyYVhhJcaCyEGbO7873814 = aZZlaujFvyYVhhJcaCyEGbO854648;     aZZlaujFvyYVhhJcaCyEGbO854648 = aZZlaujFvyYVhhJcaCyEGbO99131036;     aZZlaujFvyYVhhJcaCyEGbO99131036 = aZZlaujFvyYVhhJcaCyEGbO67410746;     aZZlaujFvyYVhhJcaCyEGbO67410746 = aZZlaujFvyYVhhJcaCyEGbO34336539;     aZZlaujFvyYVhhJcaCyEGbO34336539 = aZZlaujFvyYVhhJcaCyEGbO40097471;     aZZlaujFvyYVhhJcaCyEGbO40097471 = aZZlaujFvyYVhhJcaCyEGbO36057086;     aZZlaujFvyYVhhJcaCyEGbO36057086 = aZZlaujFvyYVhhJcaCyEGbO3289017;     aZZlaujFvyYVhhJcaCyEGbO3289017 = aZZlaujFvyYVhhJcaCyEGbO36549565;     aZZlaujFvyYVhhJcaCyEGbO36549565 = aZZlaujFvyYVhhJcaCyEGbO97949727;     aZZlaujFvyYVhhJcaCyEGbO97949727 = aZZlaujFvyYVhhJcaCyEGbO88681920;     aZZlaujFvyYVhhJcaCyEGbO88681920 = aZZlaujFvyYVhhJcaCyEGbO75685232;     aZZlaujFvyYVhhJcaCyEGbO75685232 = aZZlaujFvyYVhhJcaCyEGbO4002909;     aZZlaujFvyYVhhJcaCyEGbO4002909 = aZZlaujFvyYVhhJcaCyEGbO96884883;     aZZlaujFvyYVhhJcaCyEGbO96884883 = aZZlaujFvyYVhhJcaCyEGbO3520660;     aZZlaujFvyYVhhJcaCyEGbO3520660 = aZZlaujFvyYVhhJcaCyEGbO17156990;     aZZlaujFvyYVhhJcaCyEGbO17156990 = aZZlaujFvyYVhhJcaCyEGbO7449045;     aZZlaujFvyYVhhJcaCyEGbO7449045 = aZZlaujFvyYVhhJcaCyEGbO67384716;     aZZlaujFvyYVhhJcaCyEGbO67384716 = aZZlaujFvyYVhhJcaCyEGbO43290443;     aZZlaujFvyYVhhJcaCyEGbO43290443 = aZZlaujFvyYVhhJcaCyEGbO26306837;     aZZlaujFvyYVhhJcaCyEGbO26306837 = aZZlaujFvyYVhhJcaCyEGbO125444;     aZZlaujFvyYVhhJcaCyEGbO125444 = aZZlaujFvyYVhhJcaCyEGbO16980148;     aZZlaujFvyYVhhJcaCyEGbO16980148 = aZZlaujFvyYVhhJcaCyEGbO17195550;     aZZlaujFvyYVhhJcaCyEGbO17195550 = aZZlaujFvyYVhhJcaCyEGbO32284324;     aZZlaujFvyYVhhJcaCyEGbO32284324 = aZZlaujFvyYVhhJcaCyEGbO50768556;     aZZlaujFvyYVhhJcaCyEGbO50768556 = aZZlaujFvyYVhhJcaCyEGbO60154018;     aZZlaujFvyYVhhJcaCyEGbO60154018 = aZZlaujFvyYVhhJcaCyEGbO92233666;     aZZlaujFvyYVhhJcaCyEGbO92233666 = aZZlaujFvyYVhhJcaCyEGbO51867181;     aZZlaujFvyYVhhJcaCyEGbO51867181 = aZZlaujFvyYVhhJcaCyEGbO25591467;     aZZlaujFvyYVhhJcaCyEGbO25591467 = aZZlaujFvyYVhhJcaCyEGbO63546261;     aZZlaujFvyYVhhJcaCyEGbO63546261 = aZZlaujFvyYVhhJcaCyEGbO75290858;     aZZlaujFvyYVhhJcaCyEGbO75290858 = aZZlaujFvyYVhhJcaCyEGbO48617888;     aZZlaujFvyYVhhJcaCyEGbO48617888 = aZZlaujFvyYVhhJcaCyEGbO60283954;     aZZlaujFvyYVhhJcaCyEGbO60283954 = aZZlaujFvyYVhhJcaCyEGbO79074270;     aZZlaujFvyYVhhJcaCyEGbO79074270 = aZZlaujFvyYVhhJcaCyEGbO23752284;     aZZlaujFvyYVhhJcaCyEGbO23752284 = aZZlaujFvyYVhhJcaCyEGbO65561151;     aZZlaujFvyYVhhJcaCyEGbO65561151 = aZZlaujFvyYVhhJcaCyEGbO10364455;     aZZlaujFvyYVhhJcaCyEGbO10364455 = aZZlaujFvyYVhhJcaCyEGbO83325907;     aZZlaujFvyYVhhJcaCyEGbO83325907 = aZZlaujFvyYVhhJcaCyEGbO35233480;     aZZlaujFvyYVhhJcaCyEGbO35233480 = aZZlaujFvyYVhhJcaCyEGbO15563073;     aZZlaujFvyYVhhJcaCyEGbO15563073 = aZZlaujFvyYVhhJcaCyEGbO79218250;     aZZlaujFvyYVhhJcaCyEGbO79218250 = aZZlaujFvyYVhhJcaCyEGbO34617198;     aZZlaujFvyYVhhJcaCyEGbO34617198 = aZZlaujFvyYVhhJcaCyEGbO49221319;     aZZlaujFvyYVhhJcaCyEGbO49221319 = aZZlaujFvyYVhhJcaCyEGbO76975380;     aZZlaujFvyYVhhJcaCyEGbO76975380 = aZZlaujFvyYVhhJcaCyEGbO33787946;     aZZlaujFvyYVhhJcaCyEGbO33787946 = aZZlaujFvyYVhhJcaCyEGbO54863734;     aZZlaujFvyYVhhJcaCyEGbO54863734 = aZZlaujFvyYVhhJcaCyEGbO30294807;     aZZlaujFvyYVhhJcaCyEGbO30294807 = aZZlaujFvyYVhhJcaCyEGbO80817357;     aZZlaujFvyYVhhJcaCyEGbO80817357 = aZZlaujFvyYVhhJcaCyEGbO70345537;     aZZlaujFvyYVhhJcaCyEGbO70345537 = aZZlaujFvyYVhhJcaCyEGbO12454384;     aZZlaujFvyYVhhJcaCyEGbO12454384 = aZZlaujFvyYVhhJcaCyEGbO86101464;     aZZlaujFvyYVhhJcaCyEGbO86101464 = aZZlaujFvyYVhhJcaCyEGbO64663136;     aZZlaujFvyYVhhJcaCyEGbO64663136 = aZZlaujFvyYVhhJcaCyEGbO6304601;     aZZlaujFvyYVhhJcaCyEGbO6304601 = aZZlaujFvyYVhhJcaCyEGbO75553324;     aZZlaujFvyYVhhJcaCyEGbO75553324 = aZZlaujFvyYVhhJcaCyEGbO71520844;     aZZlaujFvyYVhhJcaCyEGbO71520844 = aZZlaujFvyYVhhJcaCyEGbO90893666;     aZZlaujFvyYVhhJcaCyEGbO90893666 = aZZlaujFvyYVhhJcaCyEGbO83659097;     aZZlaujFvyYVhhJcaCyEGbO83659097 = aZZlaujFvyYVhhJcaCyEGbO66846712;     aZZlaujFvyYVhhJcaCyEGbO66846712 = aZZlaujFvyYVhhJcaCyEGbO16642190;     aZZlaujFvyYVhhJcaCyEGbO16642190 = aZZlaujFvyYVhhJcaCyEGbO74182521;     aZZlaujFvyYVhhJcaCyEGbO74182521 = aZZlaujFvyYVhhJcaCyEGbO47863804;     aZZlaujFvyYVhhJcaCyEGbO47863804 = aZZlaujFvyYVhhJcaCyEGbO84189905;     aZZlaujFvyYVhhJcaCyEGbO84189905 = aZZlaujFvyYVhhJcaCyEGbO77697549;     aZZlaujFvyYVhhJcaCyEGbO77697549 = aZZlaujFvyYVhhJcaCyEGbO73003304;     aZZlaujFvyYVhhJcaCyEGbO73003304 = aZZlaujFvyYVhhJcaCyEGbO22658869;     aZZlaujFvyYVhhJcaCyEGbO22658869 = aZZlaujFvyYVhhJcaCyEGbO40064033;     aZZlaujFvyYVhhJcaCyEGbO40064033 = aZZlaujFvyYVhhJcaCyEGbO15401279;     aZZlaujFvyYVhhJcaCyEGbO15401279 = aZZlaujFvyYVhhJcaCyEGbO24928639;     aZZlaujFvyYVhhJcaCyEGbO24928639 = aZZlaujFvyYVhhJcaCyEGbO73132600;     aZZlaujFvyYVhhJcaCyEGbO73132600 = aZZlaujFvyYVhhJcaCyEGbO37959508;     aZZlaujFvyYVhhJcaCyEGbO37959508 = aZZlaujFvyYVhhJcaCyEGbO6792535;     aZZlaujFvyYVhhJcaCyEGbO6792535 = aZZlaujFvyYVhhJcaCyEGbO24123137;     aZZlaujFvyYVhhJcaCyEGbO24123137 = aZZlaujFvyYVhhJcaCyEGbO32151237;     aZZlaujFvyYVhhJcaCyEGbO32151237 = aZZlaujFvyYVhhJcaCyEGbO27727370;     aZZlaujFvyYVhhJcaCyEGbO27727370 = aZZlaujFvyYVhhJcaCyEGbO47088587;     aZZlaujFvyYVhhJcaCyEGbO47088587 = aZZlaujFvyYVhhJcaCyEGbO65508245;     aZZlaujFvyYVhhJcaCyEGbO65508245 = aZZlaujFvyYVhhJcaCyEGbO67758829;     aZZlaujFvyYVhhJcaCyEGbO67758829 = aZZlaujFvyYVhhJcaCyEGbO40220170;     aZZlaujFvyYVhhJcaCyEGbO40220170 = aZZlaujFvyYVhhJcaCyEGbO98496378;     aZZlaujFvyYVhhJcaCyEGbO98496378 = aZZlaujFvyYVhhJcaCyEGbO95904822;     aZZlaujFvyYVhhJcaCyEGbO95904822 = aZZlaujFvyYVhhJcaCyEGbO29859211;     aZZlaujFvyYVhhJcaCyEGbO29859211 = aZZlaujFvyYVhhJcaCyEGbO11416310;     aZZlaujFvyYVhhJcaCyEGbO11416310 = aZZlaujFvyYVhhJcaCyEGbO81521643;     aZZlaujFvyYVhhJcaCyEGbO81521643 = aZZlaujFvyYVhhJcaCyEGbO13137084;     aZZlaujFvyYVhhJcaCyEGbO13137084 = aZZlaujFvyYVhhJcaCyEGbO77444796;     aZZlaujFvyYVhhJcaCyEGbO77444796 = aZZlaujFvyYVhhJcaCyEGbO10627722;     aZZlaujFvyYVhhJcaCyEGbO10627722 = aZZlaujFvyYVhhJcaCyEGbO42313288;     aZZlaujFvyYVhhJcaCyEGbO42313288 = aZZlaujFvyYVhhJcaCyEGbO84730629;     aZZlaujFvyYVhhJcaCyEGbO84730629 = aZZlaujFvyYVhhJcaCyEGbO7553426;     aZZlaujFvyYVhhJcaCyEGbO7553426 = aZZlaujFvyYVhhJcaCyEGbO32858618;     aZZlaujFvyYVhhJcaCyEGbO32858618 = aZZlaujFvyYVhhJcaCyEGbO81902054;     aZZlaujFvyYVhhJcaCyEGbO81902054 = aZZlaujFvyYVhhJcaCyEGbO43517743;     aZZlaujFvyYVhhJcaCyEGbO43517743 = aZZlaujFvyYVhhJcaCyEGbO66683717;     aZZlaujFvyYVhhJcaCyEGbO66683717 = aZZlaujFvyYVhhJcaCyEGbO61050959;     aZZlaujFvyYVhhJcaCyEGbO61050959 = aZZlaujFvyYVhhJcaCyEGbO67699268;     aZZlaujFvyYVhhJcaCyEGbO67699268 = aZZlaujFvyYVhhJcaCyEGbO95028344;     aZZlaujFvyYVhhJcaCyEGbO95028344 = aZZlaujFvyYVhhJcaCyEGbO56919648;     aZZlaujFvyYVhhJcaCyEGbO56919648 = aZZlaujFvyYVhhJcaCyEGbO49595043;}



void KSQEuhihMPMkmeoEUPbwyOFIPB17110691() {     float QxbDVkXNpUqFwBoZXZcNhTX33318561 = -511623906;    float QxbDVkXNpUqFwBoZXZcNhTX99458256 = -206170229;    float QxbDVkXNpUqFwBoZXZcNhTX60232405 = -937344645;    float QxbDVkXNpUqFwBoZXZcNhTX5021768 = -570794921;    float QxbDVkXNpUqFwBoZXZcNhTX80415983 = -238920336;    float QxbDVkXNpUqFwBoZXZcNhTX10470554 = 81211660;    float QxbDVkXNpUqFwBoZXZcNhTX4291310 = -665267812;    float QxbDVkXNpUqFwBoZXZcNhTX77676622 = -458174246;    float QxbDVkXNpUqFwBoZXZcNhTX90316999 = 84278911;    float QxbDVkXNpUqFwBoZXZcNhTX82162674 = -865410122;    float QxbDVkXNpUqFwBoZXZcNhTX46178053 = 24064271;    float QxbDVkXNpUqFwBoZXZcNhTX26761336 = -616027163;    float QxbDVkXNpUqFwBoZXZcNhTX49003579 = -776693651;    float QxbDVkXNpUqFwBoZXZcNhTX83055065 = 4800342;    float QxbDVkXNpUqFwBoZXZcNhTX79864490 = -447869108;    float QxbDVkXNpUqFwBoZXZcNhTX75816937 = -172273976;    float QxbDVkXNpUqFwBoZXZcNhTX96750294 = -930768822;    float QxbDVkXNpUqFwBoZXZcNhTX17597929 = -123295163;    float QxbDVkXNpUqFwBoZXZcNhTX58133470 = -387726793;    float QxbDVkXNpUqFwBoZXZcNhTX81556688 = -586942027;    float QxbDVkXNpUqFwBoZXZcNhTX34724227 = -964301395;    float QxbDVkXNpUqFwBoZXZcNhTX44292514 = -962011706;    float QxbDVkXNpUqFwBoZXZcNhTX95482702 = -897052119;    float QxbDVkXNpUqFwBoZXZcNhTX1268139 = -563974467;    float QxbDVkXNpUqFwBoZXZcNhTX53582241 = -740953624;    float QxbDVkXNpUqFwBoZXZcNhTX70188308 = -151839686;    float QxbDVkXNpUqFwBoZXZcNhTX53876263 = 99138377;    float QxbDVkXNpUqFwBoZXZcNhTX93367756 = -169809500;    float QxbDVkXNpUqFwBoZXZcNhTX32072160 = -828173190;    float QxbDVkXNpUqFwBoZXZcNhTX27781994 = 59227237;    float QxbDVkXNpUqFwBoZXZcNhTX33231604 = -436994965;    float QxbDVkXNpUqFwBoZXZcNhTX50384756 = -888888104;    float QxbDVkXNpUqFwBoZXZcNhTX77670962 = 7448576;    float QxbDVkXNpUqFwBoZXZcNhTX11015573 = -209622084;    float QxbDVkXNpUqFwBoZXZcNhTX16221214 = -827341647;    float QxbDVkXNpUqFwBoZXZcNhTX30145187 = -33456230;    float QxbDVkXNpUqFwBoZXZcNhTX78837860 = -167844183;    float QxbDVkXNpUqFwBoZXZcNhTX74134075 = -278277177;    float QxbDVkXNpUqFwBoZXZcNhTX26176871 = 63864583;    float QxbDVkXNpUqFwBoZXZcNhTX49553571 = -905599807;    float QxbDVkXNpUqFwBoZXZcNhTX48093428 = -109548381;    float QxbDVkXNpUqFwBoZXZcNhTX64573206 = -523798091;    float QxbDVkXNpUqFwBoZXZcNhTX48363219 = -482273101;    float QxbDVkXNpUqFwBoZXZcNhTX26413770 = -819669687;    float QxbDVkXNpUqFwBoZXZcNhTX62604449 = -624917438;    float QxbDVkXNpUqFwBoZXZcNhTX93488200 = 3893124;    float QxbDVkXNpUqFwBoZXZcNhTX10154350 = 95303180;    float QxbDVkXNpUqFwBoZXZcNhTX72529793 = -655160306;    float QxbDVkXNpUqFwBoZXZcNhTX88737947 = -276689752;    float QxbDVkXNpUqFwBoZXZcNhTX66168137 = -805173943;    float QxbDVkXNpUqFwBoZXZcNhTX20908189 = -660362551;    float QxbDVkXNpUqFwBoZXZcNhTX21851258 = -568048651;    float QxbDVkXNpUqFwBoZXZcNhTX57836786 = -668162860;    float QxbDVkXNpUqFwBoZXZcNhTX32034071 = -560748289;    float QxbDVkXNpUqFwBoZXZcNhTX82386463 = -300775938;    float QxbDVkXNpUqFwBoZXZcNhTX89026047 = -549612200;    float QxbDVkXNpUqFwBoZXZcNhTX3975555 = -309118110;    float QxbDVkXNpUqFwBoZXZcNhTX58964267 = -273370179;    float QxbDVkXNpUqFwBoZXZcNhTX51439526 = -829841298;    float QxbDVkXNpUqFwBoZXZcNhTX10227676 = 12919350;    float QxbDVkXNpUqFwBoZXZcNhTX56594291 = 82073283;    float QxbDVkXNpUqFwBoZXZcNhTX10923553 = -395458312;    float QxbDVkXNpUqFwBoZXZcNhTX45604462 = -630001056;    float QxbDVkXNpUqFwBoZXZcNhTX62535005 = -974948326;    float QxbDVkXNpUqFwBoZXZcNhTX48931071 = -328415158;    float QxbDVkXNpUqFwBoZXZcNhTX95793297 = -87047625;    float QxbDVkXNpUqFwBoZXZcNhTX49090373 = -523475740;    float QxbDVkXNpUqFwBoZXZcNhTX37988007 = -467071567;    float QxbDVkXNpUqFwBoZXZcNhTX66833851 = -167858011;    float QxbDVkXNpUqFwBoZXZcNhTX49719303 = -314412879;    float QxbDVkXNpUqFwBoZXZcNhTX96979076 = 95570207;    float QxbDVkXNpUqFwBoZXZcNhTX22616220 = -552491646;    float QxbDVkXNpUqFwBoZXZcNhTX91421058 = -87159747;    float QxbDVkXNpUqFwBoZXZcNhTX8579900 = -482126986;    float QxbDVkXNpUqFwBoZXZcNhTX33463261 = -377393647;    float QxbDVkXNpUqFwBoZXZcNhTX70151020 = -340503304;    float QxbDVkXNpUqFwBoZXZcNhTX95929295 = -379738606;    float QxbDVkXNpUqFwBoZXZcNhTX69068933 = 22617567;    float QxbDVkXNpUqFwBoZXZcNhTX38663690 = -939057029;    float QxbDVkXNpUqFwBoZXZcNhTX60094041 = -644846748;    float QxbDVkXNpUqFwBoZXZcNhTX60033958 = -147142867;    float QxbDVkXNpUqFwBoZXZcNhTX81346470 = -245701318;    float QxbDVkXNpUqFwBoZXZcNhTX4629810 = -893119748;    float QxbDVkXNpUqFwBoZXZcNhTX65904022 = 77000752;    float QxbDVkXNpUqFwBoZXZcNhTX6873805 = -280410212;    float QxbDVkXNpUqFwBoZXZcNhTX11380347 = -868946314;    float QxbDVkXNpUqFwBoZXZcNhTX92547969 = -120725245;    float QxbDVkXNpUqFwBoZXZcNhTX45636892 = -431803136;    float QxbDVkXNpUqFwBoZXZcNhTX28629109 = -908846147;    float QxbDVkXNpUqFwBoZXZcNhTX27195167 = -177729448;    float QxbDVkXNpUqFwBoZXZcNhTX26169633 = -724338120;    float QxbDVkXNpUqFwBoZXZcNhTX19873594 = -894474005;    float QxbDVkXNpUqFwBoZXZcNhTX22694549 = -448435880;    float QxbDVkXNpUqFwBoZXZcNhTX15949195 = -949054767;    float QxbDVkXNpUqFwBoZXZcNhTX92959280 = -887673091;    float QxbDVkXNpUqFwBoZXZcNhTX37169875 = -714090069;    float QxbDVkXNpUqFwBoZXZcNhTX18968745 = -893797036;    float QxbDVkXNpUqFwBoZXZcNhTX85828213 = -507324775;    float QxbDVkXNpUqFwBoZXZcNhTX77482698 = -391254530;    float QxbDVkXNpUqFwBoZXZcNhTX66811151 = -511623906;     QxbDVkXNpUqFwBoZXZcNhTX33318561 = QxbDVkXNpUqFwBoZXZcNhTX99458256;     QxbDVkXNpUqFwBoZXZcNhTX99458256 = QxbDVkXNpUqFwBoZXZcNhTX60232405;     QxbDVkXNpUqFwBoZXZcNhTX60232405 = QxbDVkXNpUqFwBoZXZcNhTX5021768;     QxbDVkXNpUqFwBoZXZcNhTX5021768 = QxbDVkXNpUqFwBoZXZcNhTX80415983;     QxbDVkXNpUqFwBoZXZcNhTX80415983 = QxbDVkXNpUqFwBoZXZcNhTX10470554;     QxbDVkXNpUqFwBoZXZcNhTX10470554 = QxbDVkXNpUqFwBoZXZcNhTX4291310;     QxbDVkXNpUqFwBoZXZcNhTX4291310 = QxbDVkXNpUqFwBoZXZcNhTX77676622;     QxbDVkXNpUqFwBoZXZcNhTX77676622 = QxbDVkXNpUqFwBoZXZcNhTX90316999;     QxbDVkXNpUqFwBoZXZcNhTX90316999 = QxbDVkXNpUqFwBoZXZcNhTX82162674;     QxbDVkXNpUqFwBoZXZcNhTX82162674 = QxbDVkXNpUqFwBoZXZcNhTX46178053;     QxbDVkXNpUqFwBoZXZcNhTX46178053 = QxbDVkXNpUqFwBoZXZcNhTX26761336;     QxbDVkXNpUqFwBoZXZcNhTX26761336 = QxbDVkXNpUqFwBoZXZcNhTX49003579;     QxbDVkXNpUqFwBoZXZcNhTX49003579 = QxbDVkXNpUqFwBoZXZcNhTX83055065;     QxbDVkXNpUqFwBoZXZcNhTX83055065 = QxbDVkXNpUqFwBoZXZcNhTX79864490;     QxbDVkXNpUqFwBoZXZcNhTX79864490 = QxbDVkXNpUqFwBoZXZcNhTX75816937;     QxbDVkXNpUqFwBoZXZcNhTX75816937 = QxbDVkXNpUqFwBoZXZcNhTX96750294;     QxbDVkXNpUqFwBoZXZcNhTX96750294 = QxbDVkXNpUqFwBoZXZcNhTX17597929;     QxbDVkXNpUqFwBoZXZcNhTX17597929 = QxbDVkXNpUqFwBoZXZcNhTX58133470;     QxbDVkXNpUqFwBoZXZcNhTX58133470 = QxbDVkXNpUqFwBoZXZcNhTX81556688;     QxbDVkXNpUqFwBoZXZcNhTX81556688 = QxbDVkXNpUqFwBoZXZcNhTX34724227;     QxbDVkXNpUqFwBoZXZcNhTX34724227 = QxbDVkXNpUqFwBoZXZcNhTX44292514;     QxbDVkXNpUqFwBoZXZcNhTX44292514 = QxbDVkXNpUqFwBoZXZcNhTX95482702;     QxbDVkXNpUqFwBoZXZcNhTX95482702 = QxbDVkXNpUqFwBoZXZcNhTX1268139;     QxbDVkXNpUqFwBoZXZcNhTX1268139 = QxbDVkXNpUqFwBoZXZcNhTX53582241;     QxbDVkXNpUqFwBoZXZcNhTX53582241 = QxbDVkXNpUqFwBoZXZcNhTX70188308;     QxbDVkXNpUqFwBoZXZcNhTX70188308 = QxbDVkXNpUqFwBoZXZcNhTX53876263;     QxbDVkXNpUqFwBoZXZcNhTX53876263 = QxbDVkXNpUqFwBoZXZcNhTX93367756;     QxbDVkXNpUqFwBoZXZcNhTX93367756 = QxbDVkXNpUqFwBoZXZcNhTX32072160;     QxbDVkXNpUqFwBoZXZcNhTX32072160 = QxbDVkXNpUqFwBoZXZcNhTX27781994;     QxbDVkXNpUqFwBoZXZcNhTX27781994 = QxbDVkXNpUqFwBoZXZcNhTX33231604;     QxbDVkXNpUqFwBoZXZcNhTX33231604 = QxbDVkXNpUqFwBoZXZcNhTX50384756;     QxbDVkXNpUqFwBoZXZcNhTX50384756 = QxbDVkXNpUqFwBoZXZcNhTX77670962;     QxbDVkXNpUqFwBoZXZcNhTX77670962 = QxbDVkXNpUqFwBoZXZcNhTX11015573;     QxbDVkXNpUqFwBoZXZcNhTX11015573 = QxbDVkXNpUqFwBoZXZcNhTX16221214;     QxbDVkXNpUqFwBoZXZcNhTX16221214 = QxbDVkXNpUqFwBoZXZcNhTX30145187;     QxbDVkXNpUqFwBoZXZcNhTX30145187 = QxbDVkXNpUqFwBoZXZcNhTX78837860;     QxbDVkXNpUqFwBoZXZcNhTX78837860 = QxbDVkXNpUqFwBoZXZcNhTX74134075;     QxbDVkXNpUqFwBoZXZcNhTX74134075 = QxbDVkXNpUqFwBoZXZcNhTX26176871;     QxbDVkXNpUqFwBoZXZcNhTX26176871 = QxbDVkXNpUqFwBoZXZcNhTX49553571;     QxbDVkXNpUqFwBoZXZcNhTX49553571 = QxbDVkXNpUqFwBoZXZcNhTX48093428;     QxbDVkXNpUqFwBoZXZcNhTX48093428 = QxbDVkXNpUqFwBoZXZcNhTX64573206;     QxbDVkXNpUqFwBoZXZcNhTX64573206 = QxbDVkXNpUqFwBoZXZcNhTX48363219;     QxbDVkXNpUqFwBoZXZcNhTX48363219 = QxbDVkXNpUqFwBoZXZcNhTX26413770;     QxbDVkXNpUqFwBoZXZcNhTX26413770 = QxbDVkXNpUqFwBoZXZcNhTX62604449;     QxbDVkXNpUqFwBoZXZcNhTX62604449 = QxbDVkXNpUqFwBoZXZcNhTX93488200;     QxbDVkXNpUqFwBoZXZcNhTX93488200 = QxbDVkXNpUqFwBoZXZcNhTX10154350;     QxbDVkXNpUqFwBoZXZcNhTX10154350 = QxbDVkXNpUqFwBoZXZcNhTX72529793;     QxbDVkXNpUqFwBoZXZcNhTX72529793 = QxbDVkXNpUqFwBoZXZcNhTX88737947;     QxbDVkXNpUqFwBoZXZcNhTX88737947 = QxbDVkXNpUqFwBoZXZcNhTX66168137;     QxbDVkXNpUqFwBoZXZcNhTX66168137 = QxbDVkXNpUqFwBoZXZcNhTX20908189;     QxbDVkXNpUqFwBoZXZcNhTX20908189 = QxbDVkXNpUqFwBoZXZcNhTX21851258;     QxbDVkXNpUqFwBoZXZcNhTX21851258 = QxbDVkXNpUqFwBoZXZcNhTX57836786;     QxbDVkXNpUqFwBoZXZcNhTX57836786 = QxbDVkXNpUqFwBoZXZcNhTX32034071;     QxbDVkXNpUqFwBoZXZcNhTX32034071 = QxbDVkXNpUqFwBoZXZcNhTX82386463;     QxbDVkXNpUqFwBoZXZcNhTX82386463 = QxbDVkXNpUqFwBoZXZcNhTX89026047;     QxbDVkXNpUqFwBoZXZcNhTX89026047 = QxbDVkXNpUqFwBoZXZcNhTX3975555;     QxbDVkXNpUqFwBoZXZcNhTX3975555 = QxbDVkXNpUqFwBoZXZcNhTX58964267;     QxbDVkXNpUqFwBoZXZcNhTX58964267 = QxbDVkXNpUqFwBoZXZcNhTX51439526;     QxbDVkXNpUqFwBoZXZcNhTX51439526 = QxbDVkXNpUqFwBoZXZcNhTX10227676;     QxbDVkXNpUqFwBoZXZcNhTX10227676 = QxbDVkXNpUqFwBoZXZcNhTX56594291;     QxbDVkXNpUqFwBoZXZcNhTX56594291 = QxbDVkXNpUqFwBoZXZcNhTX10923553;     QxbDVkXNpUqFwBoZXZcNhTX10923553 = QxbDVkXNpUqFwBoZXZcNhTX45604462;     QxbDVkXNpUqFwBoZXZcNhTX45604462 = QxbDVkXNpUqFwBoZXZcNhTX62535005;     QxbDVkXNpUqFwBoZXZcNhTX62535005 = QxbDVkXNpUqFwBoZXZcNhTX48931071;     QxbDVkXNpUqFwBoZXZcNhTX48931071 = QxbDVkXNpUqFwBoZXZcNhTX95793297;     QxbDVkXNpUqFwBoZXZcNhTX95793297 = QxbDVkXNpUqFwBoZXZcNhTX49090373;     QxbDVkXNpUqFwBoZXZcNhTX49090373 = QxbDVkXNpUqFwBoZXZcNhTX37988007;     QxbDVkXNpUqFwBoZXZcNhTX37988007 = QxbDVkXNpUqFwBoZXZcNhTX66833851;     QxbDVkXNpUqFwBoZXZcNhTX66833851 = QxbDVkXNpUqFwBoZXZcNhTX49719303;     QxbDVkXNpUqFwBoZXZcNhTX49719303 = QxbDVkXNpUqFwBoZXZcNhTX96979076;     QxbDVkXNpUqFwBoZXZcNhTX96979076 = QxbDVkXNpUqFwBoZXZcNhTX22616220;     QxbDVkXNpUqFwBoZXZcNhTX22616220 = QxbDVkXNpUqFwBoZXZcNhTX91421058;     QxbDVkXNpUqFwBoZXZcNhTX91421058 = QxbDVkXNpUqFwBoZXZcNhTX8579900;     QxbDVkXNpUqFwBoZXZcNhTX8579900 = QxbDVkXNpUqFwBoZXZcNhTX33463261;     QxbDVkXNpUqFwBoZXZcNhTX33463261 = QxbDVkXNpUqFwBoZXZcNhTX70151020;     QxbDVkXNpUqFwBoZXZcNhTX70151020 = QxbDVkXNpUqFwBoZXZcNhTX95929295;     QxbDVkXNpUqFwBoZXZcNhTX95929295 = QxbDVkXNpUqFwBoZXZcNhTX69068933;     QxbDVkXNpUqFwBoZXZcNhTX69068933 = QxbDVkXNpUqFwBoZXZcNhTX38663690;     QxbDVkXNpUqFwBoZXZcNhTX38663690 = QxbDVkXNpUqFwBoZXZcNhTX60094041;     QxbDVkXNpUqFwBoZXZcNhTX60094041 = QxbDVkXNpUqFwBoZXZcNhTX60033958;     QxbDVkXNpUqFwBoZXZcNhTX60033958 = QxbDVkXNpUqFwBoZXZcNhTX81346470;     QxbDVkXNpUqFwBoZXZcNhTX81346470 = QxbDVkXNpUqFwBoZXZcNhTX4629810;     QxbDVkXNpUqFwBoZXZcNhTX4629810 = QxbDVkXNpUqFwBoZXZcNhTX65904022;     QxbDVkXNpUqFwBoZXZcNhTX65904022 = QxbDVkXNpUqFwBoZXZcNhTX6873805;     QxbDVkXNpUqFwBoZXZcNhTX6873805 = QxbDVkXNpUqFwBoZXZcNhTX11380347;     QxbDVkXNpUqFwBoZXZcNhTX11380347 = QxbDVkXNpUqFwBoZXZcNhTX92547969;     QxbDVkXNpUqFwBoZXZcNhTX92547969 = QxbDVkXNpUqFwBoZXZcNhTX45636892;     QxbDVkXNpUqFwBoZXZcNhTX45636892 = QxbDVkXNpUqFwBoZXZcNhTX28629109;     QxbDVkXNpUqFwBoZXZcNhTX28629109 = QxbDVkXNpUqFwBoZXZcNhTX27195167;     QxbDVkXNpUqFwBoZXZcNhTX27195167 = QxbDVkXNpUqFwBoZXZcNhTX26169633;     QxbDVkXNpUqFwBoZXZcNhTX26169633 = QxbDVkXNpUqFwBoZXZcNhTX19873594;     QxbDVkXNpUqFwBoZXZcNhTX19873594 = QxbDVkXNpUqFwBoZXZcNhTX22694549;     QxbDVkXNpUqFwBoZXZcNhTX22694549 = QxbDVkXNpUqFwBoZXZcNhTX15949195;     QxbDVkXNpUqFwBoZXZcNhTX15949195 = QxbDVkXNpUqFwBoZXZcNhTX92959280;     QxbDVkXNpUqFwBoZXZcNhTX92959280 = QxbDVkXNpUqFwBoZXZcNhTX37169875;     QxbDVkXNpUqFwBoZXZcNhTX37169875 = QxbDVkXNpUqFwBoZXZcNhTX18968745;     QxbDVkXNpUqFwBoZXZcNhTX18968745 = QxbDVkXNpUqFwBoZXZcNhTX85828213;     QxbDVkXNpUqFwBoZXZcNhTX85828213 = QxbDVkXNpUqFwBoZXZcNhTX77482698;     QxbDVkXNpUqFwBoZXZcNhTX77482698 = QxbDVkXNpUqFwBoZXZcNhTX66811151;     QxbDVkXNpUqFwBoZXZcNhTX66811151 = QxbDVkXNpUqFwBoZXZcNhTX33318561;}



void hysYfaBQZkxXZxfhfcKjhUhMBJ2173529() {     float lMyafbsYVPMOBEyMQfsXqFT17042079 = -861645973;    float lMyafbsYVPMOBEyMQfsXqFT97056352 = -9822081;    float lMyafbsYVPMOBEyMQfsXqFT48818522 = -805652336;    float lMyafbsYVPMOBEyMQfsXqFT2169721 = -575676850;    float lMyafbsYVPMOBEyMQfsXqFT59977320 = -636868527;    float lMyafbsYVPMOBEyMQfsXqFT21810072 = -22109009;    float lMyafbsYVPMOBEyMQfsXqFT41171872 = -686781950;    float lMyafbsYVPMOBEyMQfsXqFT21016705 = 21371168;    float lMyafbsYVPMOBEyMQfsXqFT40536528 = -613203785;    float lMyafbsYVPMOBEyMQfsXqFT28268263 = 11548863;    float lMyafbsYVPMOBEyMQfsXqFT89067088 = -916220987;    float lMyafbsYVPMOBEyMQfsXqFT16973107 = -545166434;    float lMyafbsYVPMOBEyMQfsXqFT57431 = -619525895;    float lMyafbsYVPMOBEyMQfsXqFT77428210 = -344882521;    float lMyafbsYVPMOBEyMQfsXqFT84043749 = -373566413;    float lMyafbsYVPMOBEyMQfsXqFT47630966 = -96401627;    float lMyafbsYVPMOBEyMQfsXqFT96615705 = 10351315;    float lMyafbsYVPMOBEyMQfsXqFT31675198 = -834146737;    float lMyafbsYVPMOBEyMQfsXqFT99109950 = -176376031;    float lMyafbsYVPMOBEyMQfsXqFT55664333 = -203234944;    float lMyafbsYVPMOBEyMQfsXqFT2063737 = -538767915;    float lMyafbsYVPMOBEyMQfsXqFT45294585 = -875166993;    float lMyafbsYVPMOBEyMQfsXqFT64658568 = -926446856;    float lMyafbsYVPMOBEyMQfsXqFT2410834 = -103207120;    float lMyafbsYVPMOBEyMQfsXqFT90184333 = -819284385;    float lMyafbsYVPMOBEyMQfsXqFT23181066 = -594806714;    float lMyafbsYVPMOBEyMQfsXqFT75468202 = -344737046;    float lMyafbsYVPMOBEyMQfsXqFT35966957 = 43749012;    float lMyafbsYVPMOBEyMQfsXqFT3990302 = -252369091;    float lMyafbsYVPMOBEyMQfsXqFT63330321 = -613379137;    float lMyafbsYVPMOBEyMQfsXqFT14596027 = -656092985;    float lMyafbsYVPMOBEyMQfsXqFT75178044 = -338085327;    float lMyafbsYVPMOBEyMQfsXqFT91795663 = -657765515;    float lMyafbsYVPMOBEyMQfsXqFT46740286 = -613718732;    float lMyafbsYVPMOBEyMQfsXqFT83824539 = -561632255;    float lMyafbsYVPMOBEyMQfsXqFT6421 = -11852707;    float lMyafbsYVPMOBEyMQfsXqFT78601450 = -488185479;    float lMyafbsYVPMOBEyMQfsXqFT24515867 = -177420393;    float lMyafbsYVPMOBEyMQfsXqFT86792589 = -241694298;    float lMyafbsYVPMOBEyMQfsXqFT88742686 = -852246687;    float lMyafbsYVPMOBEyMQfsXqFT12860949 = -859588507;    float lMyafbsYVPMOBEyMQfsXqFT93912933 = -129823760;    float lMyafbsYVPMOBEyMQfsXqFT81163365 = -134677355;    float lMyafbsYVPMOBEyMQfsXqFT73609289 = -398613419;    float lMyafbsYVPMOBEyMQfsXqFT90591699 = -950931516;    float lMyafbsYVPMOBEyMQfsXqFT37755082 = -711138568;    float lMyafbsYVPMOBEyMQfsXqFT43333319 = 73657273;    float lMyafbsYVPMOBEyMQfsXqFT11271641 = -417282203;    float lMyafbsYVPMOBEyMQfsXqFT22612161 = 23526097;    float lMyafbsYVPMOBEyMQfsXqFT2041468 = -337189379;    float lMyafbsYVPMOBEyMQfsXqFT60999020 = -826134953;    float lMyafbsYVPMOBEyMQfsXqFT73356977 = -320101438;    float lMyafbsYVPMOBEyMQfsXqFT3219189 = -680095225;    float lMyafbsYVPMOBEyMQfsXqFT77966676 = -37457476;    float lMyafbsYVPMOBEyMQfsXqFT109792 = -617502883;    float lMyafbsYVPMOBEyMQfsXqFT71747494 = -986478981;    float lMyafbsYVPMOBEyMQfsXqFT32397785 = -83375225;    float lMyafbsYVPMOBEyMQfsXqFT46407689 = -602445217;    float lMyafbsYVPMOBEyMQfsXqFT11985387 = -756392465;    float lMyafbsYVPMOBEyMQfsXqFT36796255 = 57938186;    float lMyafbsYVPMOBEyMQfsXqFT46341869 = -677371963;    float lMyafbsYVPMOBEyMQfsXqFT5204916 = -630530962;    float lMyafbsYVPMOBEyMQfsXqFT17026404 = -726259742;    float lMyafbsYVPMOBEyMQfsXqFT77206207 = -999824648;    float lMyafbsYVPMOBEyMQfsXqFT13672237 = -332358153;    float lMyafbsYVPMOBEyMQfsXqFT13889045 = -478135661;    float lMyafbsYVPMOBEyMQfsXqFT25177443 = -887400920;    float lMyafbsYVPMOBEyMQfsXqFT53317144 = 94192837;    float lMyafbsYVPMOBEyMQfsXqFT93603670 = -783250266;    float lMyafbsYVPMOBEyMQfsXqFT84037328 = -261713707;    float lMyafbsYVPMOBEyMQfsXqFT69029515 = -608216148;    float lMyafbsYVPMOBEyMQfsXqFT72099839 = -812228292;    float lMyafbsYVPMOBEyMQfsXqFT44882609 = -492452440;    float lMyafbsYVPMOBEyMQfsXqFT10367264 = -324129345;    float lMyafbsYVPMOBEyMQfsXqFT42803384 = -343646437;    float lMyafbsYVPMOBEyMQfsXqFT8150804 = -308944155;    float lMyafbsYVPMOBEyMQfsXqFT64131220 = -640489638;    float lMyafbsYVPMOBEyMQfsXqFT91049278 = -427833438;    float lMyafbsYVPMOBEyMQfsXqFT11819134 = -152275604;    float lMyafbsYVPMOBEyMQfsXqFT52429252 = -8145818;    float lMyafbsYVPMOBEyMQfsXqFT79847746 = -568463987;    float lMyafbsYVPMOBEyMQfsXqFT64196562 = -927454843;    float lMyafbsYVPMOBEyMQfsXqFT13354796 = -979777085;    float lMyafbsYVPMOBEyMQfsXqFT1948835 = -915179713;    float lMyafbsYVPMOBEyMQfsXqFT2331301 = -787244185;    float lMyafbsYVPMOBEyMQfsXqFT41239050 = -235991548;    float lMyafbsYVPMOBEyMQfsXqFT71958855 = -657990102;    float lMyafbsYVPMOBEyMQfsXqFT13828988 = -520308039;    float lMyafbsYVPMOBEyMQfsXqFT46630495 = -996215849;    float lMyafbsYVPMOBEyMQfsXqFT12077046 = -575153275;    float lMyafbsYVPMOBEyMQfsXqFT67608636 = -928477483;    float lMyafbsYVPMOBEyMQfsXqFT32193762 = -885740263;    float lMyafbsYVPMOBEyMQfsXqFT12530480 = -421027929;    float lMyafbsYVPMOBEyMQfsXqFT49996335 = -199632484;    float lMyafbsYVPMOBEyMQfsXqFT42400818 = -74874724;    float lMyafbsYVPMOBEyMQfsXqFT7656033 = -129057546;    float lMyafbsYVPMOBEyMQfsXqFT76886529 = -403564019;    float lMyafbsYVPMOBEyMQfsXqFT3957159 = -134852707;    float lMyafbsYVPMOBEyMQfsXqFT59937053 = 33744733;    float lMyafbsYVPMOBEyMQfsXqFT76702655 = -861645973;     lMyafbsYVPMOBEyMQfsXqFT17042079 = lMyafbsYVPMOBEyMQfsXqFT97056352;     lMyafbsYVPMOBEyMQfsXqFT97056352 = lMyafbsYVPMOBEyMQfsXqFT48818522;     lMyafbsYVPMOBEyMQfsXqFT48818522 = lMyafbsYVPMOBEyMQfsXqFT2169721;     lMyafbsYVPMOBEyMQfsXqFT2169721 = lMyafbsYVPMOBEyMQfsXqFT59977320;     lMyafbsYVPMOBEyMQfsXqFT59977320 = lMyafbsYVPMOBEyMQfsXqFT21810072;     lMyafbsYVPMOBEyMQfsXqFT21810072 = lMyafbsYVPMOBEyMQfsXqFT41171872;     lMyafbsYVPMOBEyMQfsXqFT41171872 = lMyafbsYVPMOBEyMQfsXqFT21016705;     lMyafbsYVPMOBEyMQfsXqFT21016705 = lMyafbsYVPMOBEyMQfsXqFT40536528;     lMyafbsYVPMOBEyMQfsXqFT40536528 = lMyafbsYVPMOBEyMQfsXqFT28268263;     lMyafbsYVPMOBEyMQfsXqFT28268263 = lMyafbsYVPMOBEyMQfsXqFT89067088;     lMyafbsYVPMOBEyMQfsXqFT89067088 = lMyafbsYVPMOBEyMQfsXqFT16973107;     lMyafbsYVPMOBEyMQfsXqFT16973107 = lMyafbsYVPMOBEyMQfsXqFT57431;     lMyafbsYVPMOBEyMQfsXqFT57431 = lMyafbsYVPMOBEyMQfsXqFT77428210;     lMyafbsYVPMOBEyMQfsXqFT77428210 = lMyafbsYVPMOBEyMQfsXqFT84043749;     lMyafbsYVPMOBEyMQfsXqFT84043749 = lMyafbsYVPMOBEyMQfsXqFT47630966;     lMyafbsYVPMOBEyMQfsXqFT47630966 = lMyafbsYVPMOBEyMQfsXqFT96615705;     lMyafbsYVPMOBEyMQfsXqFT96615705 = lMyafbsYVPMOBEyMQfsXqFT31675198;     lMyafbsYVPMOBEyMQfsXqFT31675198 = lMyafbsYVPMOBEyMQfsXqFT99109950;     lMyafbsYVPMOBEyMQfsXqFT99109950 = lMyafbsYVPMOBEyMQfsXqFT55664333;     lMyafbsYVPMOBEyMQfsXqFT55664333 = lMyafbsYVPMOBEyMQfsXqFT2063737;     lMyafbsYVPMOBEyMQfsXqFT2063737 = lMyafbsYVPMOBEyMQfsXqFT45294585;     lMyafbsYVPMOBEyMQfsXqFT45294585 = lMyafbsYVPMOBEyMQfsXqFT64658568;     lMyafbsYVPMOBEyMQfsXqFT64658568 = lMyafbsYVPMOBEyMQfsXqFT2410834;     lMyafbsYVPMOBEyMQfsXqFT2410834 = lMyafbsYVPMOBEyMQfsXqFT90184333;     lMyafbsYVPMOBEyMQfsXqFT90184333 = lMyafbsYVPMOBEyMQfsXqFT23181066;     lMyafbsYVPMOBEyMQfsXqFT23181066 = lMyafbsYVPMOBEyMQfsXqFT75468202;     lMyafbsYVPMOBEyMQfsXqFT75468202 = lMyafbsYVPMOBEyMQfsXqFT35966957;     lMyafbsYVPMOBEyMQfsXqFT35966957 = lMyafbsYVPMOBEyMQfsXqFT3990302;     lMyafbsYVPMOBEyMQfsXqFT3990302 = lMyafbsYVPMOBEyMQfsXqFT63330321;     lMyafbsYVPMOBEyMQfsXqFT63330321 = lMyafbsYVPMOBEyMQfsXqFT14596027;     lMyafbsYVPMOBEyMQfsXqFT14596027 = lMyafbsYVPMOBEyMQfsXqFT75178044;     lMyafbsYVPMOBEyMQfsXqFT75178044 = lMyafbsYVPMOBEyMQfsXqFT91795663;     lMyafbsYVPMOBEyMQfsXqFT91795663 = lMyafbsYVPMOBEyMQfsXqFT46740286;     lMyafbsYVPMOBEyMQfsXqFT46740286 = lMyafbsYVPMOBEyMQfsXqFT83824539;     lMyafbsYVPMOBEyMQfsXqFT83824539 = lMyafbsYVPMOBEyMQfsXqFT6421;     lMyafbsYVPMOBEyMQfsXqFT6421 = lMyafbsYVPMOBEyMQfsXqFT78601450;     lMyafbsYVPMOBEyMQfsXqFT78601450 = lMyafbsYVPMOBEyMQfsXqFT24515867;     lMyafbsYVPMOBEyMQfsXqFT24515867 = lMyafbsYVPMOBEyMQfsXqFT86792589;     lMyafbsYVPMOBEyMQfsXqFT86792589 = lMyafbsYVPMOBEyMQfsXqFT88742686;     lMyafbsYVPMOBEyMQfsXqFT88742686 = lMyafbsYVPMOBEyMQfsXqFT12860949;     lMyafbsYVPMOBEyMQfsXqFT12860949 = lMyafbsYVPMOBEyMQfsXqFT93912933;     lMyafbsYVPMOBEyMQfsXqFT93912933 = lMyafbsYVPMOBEyMQfsXqFT81163365;     lMyafbsYVPMOBEyMQfsXqFT81163365 = lMyafbsYVPMOBEyMQfsXqFT73609289;     lMyafbsYVPMOBEyMQfsXqFT73609289 = lMyafbsYVPMOBEyMQfsXqFT90591699;     lMyafbsYVPMOBEyMQfsXqFT90591699 = lMyafbsYVPMOBEyMQfsXqFT37755082;     lMyafbsYVPMOBEyMQfsXqFT37755082 = lMyafbsYVPMOBEyMQfsXqFT43333319;     lMyafbsYVPMOBEyMQfsXqFT43333319 = lMyafbsYVPMOBEyMQfsXqFT11271641;     lMyafbsYVPMOBEyMQfsXqFT11271641 = lMyafbsYVPMOBEyMQfsXqFT22612161;     lMyafbsYVPMOBEyMQfsXqFT22612161 = lMyafbsYVPMOBEyMQfsXqFT2041468;     lMyafbsYVPMOBEyMQfsXqFT2041468 = lMyafbsYVPMOBEyMQfsXqFT60999020;     lMyafbsYVPMOBEyMQfsXqFT60999020 = lMyafbsYVPMOBEyMQfsXqFT73356977;     lMyafbsYVPMOBEyMQfsXqFT73356977 = lMyafbsYVPMOBEyMQfsXqFT3219189;     lMyafbsYVPMOBEyMQfsXqFT3219189 = lMyafbsYVPMOBEyMQfsXqFT77966676;     lMyafbsYVPMOBEyMQfsXqFT77966676 = lMyafbsYVPMOBEyMQfsXqFT109792;     lMyafbsYVPMOBEyMQfsXqFT109792 = lMyafbsYVPMOBEyMQfsXqFT71747494;     lMyafbsYVPMOBEyMQfsXqFT71747494 = lMyafbsYVPMOBEyMQfsXqFT32397785;     lMyafbsYVPMOBEyMQfsXqFT32397785 = lMyafbsYVPMOBEyMQfsXqFT46407689;     lMyafbsYVPMOBEyMQfsXqFT46407689 = lMyafbsYVPMOBEyMQfsXqFT11985387;     lMyafbsYVPMOBEyMQfsXqFT11985387 = lMyafbsYVPMOBEyMQfsXqFT36796255;     lMyafbsYVPMOBEyMQfsXqFT36796255 = lMyafbsYVPMOBEyMQfsXqFT46341869;     lMyafbsYVPMOBEyMQfsXqFT46341869 = lMyafbsYVPMOBEyMQfsXqFT5204916;     lMyafbsYVPMOBEyMQfsXqFT5204916 = lMyafbsYVPMOBEyMQfsXqFT17026404;     lMyafbsYVPMOBEyMQfsXqFT17026404 = lMyafbsYVPMOBEyMQfsXqFT77206207;     lMyafbsYVPMOBEyMQfsXqFT77206207 = lMyafbsYVPMOBEyMQfsXqFT13672237;     lMyafbsYVPMOBEyMQfsXqFT13672237 = lMyafbsYVPMOBEyMQfsXqFT13889045;     lMyafbsYVPMOBEyMQfsXqFT13889045 = lMyafbsYVPMOBEyMQfsXqFT25177443;     lMyafbsYVPMOBEyMQfsXqFT25177443 = lMyafbsYVPMOBEyMQfsXqFT53317144;     lMyafbsYVPMOBEyMQfsXqFT53317144 = lMyafbsYVPMOBEyMQfsXqFT93603670;     lMyafbsYVPMOBEyMQfsXqFT93603670 = lMyafbsYVPMOBEyMQfsXqFT84037328;     lMyafbsYVPMOBEyMQfsXqFT84037328 = lMyafbsYVPMOBEyMQfsXqFT69029515;     lMyafbsYVPMOBEyMQfsXqFT69029515 = lMyafbsYVPMOBEyMQfsXqFT72099839;     lMyafbsYVPMOBEyMQfsXqFT72099839 = lMyafbsYVPMOBEyMQfsXqFT44882609;     lMyafbsYVPMOBEyMQfsXqFT44882609 = lMyafbsYVPMOBEyMQfsXqFT10367264;     lMyafbsYVPMOBEyMQfsXqFT10367264 = lMyafbsYVPMOBEyMQfsXqFT42803384;     lMyafbsYVPMOBEyMQfsXqFT42803384 = lMyafbsYVPMOBEyMQfsXqFT8150804;     lMyafbsYVPMOBEyMQfsXqFT8150804 = lMyafbsYVPMOBEyMQfsXqFT64131220;     lMyafbsYVPMOBEyMQfsXqFT64131220 = lMyafbsYVPMOBEyMQfsXqFT91049278;     lMyafbsYVPMOBEyMQfsXqFT91049278 = lMyafbsYVPMOBEyMQfsXqFT11819134;     lMyafbsYVPMOBEyMQfsXqFT11819134 = lMyafbsYVPMOBEyMQfsXqFT52429252;     lMyafbsYVPMOBEyMQfsXqFT52429252 = lMyafbsYVPMOBEyMQfsXqFT79847746;     lMyafbsYVPMOBEyMQfsXqFT79847746 = lMyafbsYVPMOBEyMQfsXqFT64196562;     lMyafbsYVPMOBEyMQfsXqFT64196562 = lMyafbsYVPMOBEyMQfsXqFT13354796;     lMyafbsYVPMOBEyMQfsXqFT13354796 = lMyafbsYVPMOBEyMQfsXqFT1948835;     lMyafbsYVPMOBEyMQfsXqFT1948835 = lMyafbsYVPMOBEyMQfsXqFT2331301;     lMyafbsYVPMOBEyMQfsXqFT2331301 = lMyafbsYVPMOBEyMQfsXqFT41239050;     lMyafbsYVPMOBEyMQfsXqFT41239050 = lMyafbsYVPMOBEyMQfsXqFT71958855;     lMyafbsYVPMOBEyMQfsXqFT71958855 = lMyafbsYVPMOBEyMQfsXqFT13828988;     lMyafbsYVPMOBEyMQfsXqFT13828988 = lMyafbsYVPMOBEyMQfsXqFT46630495;     lMyafbsYVPMOBEyMQfsXqFT46630495 = lMyafbsYVPMOBEyMQfsXqFT12077046;     lMyafbsYVPMOBEyMQfsXqFT12077046 = lMyafbsYVPMOBEyMQfsXqFT67608636;     lMyafbsYVPMOBEyMQfsXqFT67608636 = lMyafbsYVPMOBEyMQfsXqFT32193762;     lMyafbsYVPMOBEyMQfsXqFT32193762 = lMyafbsYVPMOBEyMQfsXqFT12530480;     lMyafbsYVPMOBEyMQfsXqFT12530480 = lMyafbsYVPMOBEyMQfsXqFT49996335;     lMyafbsYVPMOBEyMQfsXqFT49996335 = lMyafbsYVPMOBEyMQfsXqFT42400818;     lMyafbsYVPMOBEyMQfsXqFT42400818 = lMyafbsYVPMOBEyMQfsXqFT7656033;     lMyafbsYVPMOBEyMQfsXqFT7656033 = lMyafbsYVPMOBEyMQfsXqFT76886529;     lMyafbsYVPMOBEyMQfsXqFT76886529 = lMyafbsYVPMOBEyMQfsXqFT3957159;     lMyafbsYVPMOBEyMQfsXqFT3957159 = lMyafbsYVPMOBEyMQfsXqFT59937053;     lMyafbsYVPMOBEyMQfsXqFT59937053 = lMyafbsYVPMOBEyMQfsXqFT76702655;     lMyafbsYVPMOBEyMQfsXqFT76702655 = lMyafbsYVPMOBEyMQfsXqFT17042079;}



void fwWeUVIyOvdHGKfkhLCHlNBpzn87236366() {     float BwNofGPSqfqqIFMYqydOxMF765598 = -111668040;    float BwNofGPSqfqqIFMYqydOxMF94654448 = -913473932;    float BwNofGPSqfqqIFMYqydOxMF37404639 = -673960027;    float BwNofGPSqfqqIFMYqydOxMF99317673 = -580558779;    float BwNofGPSqfqqIFMYqydOxMF39538657 = 65183281;    float BwNofGPSqfqqIFMYqydOxMF33149589 = -125429677;    float BwNofGPSqfqqIFMYqydOxMF78052435 = -708296088;    float BwNofGPSqfqqIFMYqydOxMF64356788 = -599083418;    float BwNofGPSqfqqIFMYqydOxMF90756056 = -210686482;    float BwNofGPSqfqqIFMYqydOxMF74373851 = -211492153;    float BwNofGPSqfqqIFMYqydOxMF31956125 = -756506245;    float BwNofGPSqfqqIFMYqydOxMF7184878 = -474305705;    float BwNofGPSqfqqIFMYqydOxMF51111283 = -462358138;    float BwNofGPSqfqqIFMYqydOxMF71801354 = -694565383;    float BwNofGPSqfqqIFMYqydOxMF88223008 = -299263718;    float BwNofGPSqfqqIFMYqydOxMF19444995 = -20529279;    float BwNofGPSqfqqIFMYqydOxMF96481116 = -148528548;    float BwNofGPSqfqqIFMYqydOxMF45752468 = -444998311;    float BwNofGPSqfqqIFMYqydOxMF40086432 = 34974731;    float BwNofGPSqfqqIFMYqydOxMF29771978 = -919527861;    float BwNofGPSqfqqIFMYqydOxMF69403247 = -113234436;    float BwNofGPSqfqqIFMYqydOxMF46296656 = -788322279;    float BwNofGPSqfqqIFMYqydOxMF33834433 = -955841593;    float BwNofGPSqfqqIFMYqydOxMF3553529 = -742439773;    float BwNofGPSqfqqIFMYqydOxMF26786427 = -897615147;    float BwNofGPSqfqqIFMYqydOxMF76173823 = 62226258;    float BwNofGPSqfqqIFMYqydOxMF97060142 = -788612469;    float BwNofGPSqfqqIFMYqydOxMF78566156 = -842692477;    float BwNofGPSqfqqIFMYqydOxMF75908443 = -776564991;    float BwNofGPSqfqqIFMYqydOxMF98878648 = -185985512;    float BwNofGPSqfqqIFMYqydOxMF95960449 = -875191006;    float BwNofGPSqfqqIFMYqydOxMF99971332 = -887282549;    float BwNofGPSqfqqIFMYqydOxMF5920366 = -222979607;    float BwNofGPSqfqqIFMYqydOxMF82465000 = 82184620;    float BwNofGPSqfqqIFMYqydOxMF51427864 = -295922863;    float BwNofGPSqfqqIFMYqydOxMF69867654 = 9750815;    float BwNofGPSqfqqIFMYqydOxMF78365041 = -808526776;    float BwNofGPSqfqqIFMYqydOxMF74897657 = -76563610;    float BwNofGPSqfqqIFMYqydOxMF47408309 = -547253179;    float BwNofGPSqfqqIFMYqydOxMF27931803 = -798893566;    float BwNofGPSqfqqIFMYqydOxMF77628469 = -509628634;    float BwNofGPSqfqqIFMYqydOxMF23252660 = -835849430;    float BwNofGPSqfqqIFMYqydOxMF13963512 = -887081609;    float BwNofGPSqfqqIFMYqydOxMF20804809 = 22442848;    float BwNofGPSqfqqIFMYqydOxMF18578951 = -176945595;    float BwNofGPSqfqqIFMYqydOxMF82021963 = -326170260;    float BwNofGPSqfqqIFMYqydOxMF76512288 = 52011366;    float BwNofGPSqfqqIFMYqydOxMF50013488 = -179404101;    float BwNofGPSqfqqIFMYqydOxMF56486374 = -776258054;    float BwNofGPSqfqqIFMYqydOxMF37914797 = -969204814;    float BwNofGPSqfqqIFMYqydOxMF1089852 = -991907354;    float BwNofGPSqfqqIFMYqydOxMF24862697 = -72154224;    float BwNofGPSqfqqIFMYqydOxMF48601591 = -692027591;    float BwNofGPSqfqqIFMYqydOxMF23899283 = -614166664;    float BwNofGPSqfqqIFMYqydOxMF17833119 = -934229828;    float BwNofGPSqfqqIFMYqydOxMF54468941 = -323345762;    float BwNofGPSqfqqIFMYqydOxMF60820015 = -957632339;    float BwNofGPSqfqqIFMYqydOxMF33851111 = -931520254;    float BwNofGPSqfqqIFMYqydOxMF72531247 = -682943632;    float BwNofGPSqfqqIFMYqydOxMF63364833 = -997042978;    float BwNofGPSqfqqIFMYqydOxMF36089447 = -336817209;    float BwNofGPSqfqqIFMYqydOxMF99486278 = -865603611;    float BwNofGPSqfqqIFMYqydOxMF88448344 = -822518428;    float BwNofGPSqfqqIFMYqydOxMF91877408 = 75299030;    float BwNofGPSqfqqIFMYqydOxMF78413401 = -336301148;    float BwNofGPSqfqqIFMYqydOxMF31984793 = -869223696;    float BwNofGPSqfqqIFMYqydOxMF1264512 = -151326099;    float BwNofGPSqfqqIFMYqydOxMF68646282 = -444542759;    float BwNofGPSqfqqIFMYqydOxMF20373490 = -298642521;    float BwNofGPSqfqqIFMYqydOxMF18355354 = -209014534;    float BwNofGPSqfqqIFMYqydOxMF41079954 = -212002503;    float BwNofGPSqfqqIFMYqydOxMF21583459 = 28035062;    float BwNofGPSqfqqIFMYqydOxMF98344159 = -897745132;    float BwNofGPSqfqqIFMYqydOxMF12154629 = -166131703;    float BwNofGPSqfqqIFMYqydOxMF52143508 = -309899228;    float BwNofGPSqfqqIFMYqydOxMF46150587 = -277385007;    float BwNofGPSqfqqIFMYqydOxMF32333145 = -901240670;    float BwNofGPSqfqqIFMYqydOxMF13029625 = -878284442;    float BwNofGPSqfqqIFMYqydOxMF84974578 = -465494179;    float BwNofGPSqfqqIFMYqydOxMF44764464 = -471444888;    float BwNofGPSqfqqIFMYqydOxMF99661534 = -989785108;    float BwNofGPSqfqqIFMYqydOxMF47046654 = -509208368;    float BwNofGPSqfqqIFMYqydOxMF22079783 = 33565577;    float BwNofGPSqfqqIFMYqydOxMF37993646 = -807360177;    float BwNofGPSqfqqIFMYqydOxMF97788796 = -194078158;    float BwNofGPSqfqqIFMYqydOxMF71097752 = -703036782;    float BwNofGPSqfqqIFMYqydOxMF51369741 = -95254959;    float BwNofGPSqfqqIFMYqydOxMF82021082 = -608812943;    float BwNofGPSqfqqIFMYqydOxMF64631881 = 16414448;    float BwNofGPSqfqqIFMYqydOxMF96958923 = -972577102;    float BwNofGPSqfqqIFMYqydOxMF9047640 = -32616846;    float BwNofGPSqfqqIFMYqydOxMF44513930 = -877006522;    float BwNofGPSqfqqIFMYqydOxMF2366411 = -393619978;    float BwNofGPSqfqqIFMYqydOxMF84043475 = -550210202;    float BwNofGPSqfqqIFMYqydOxMF91842355 = -362076358;    float BwNofGPSqfqqIFMYqydOxMF78142191 = -644025023;    float BwNofGPSqfqqIFMYqydOxMF34804315 = 86668997;    float BwNofGPSqfqqIFMYqydOxMF22086104 = -862380640;    float BwNofGPSqfqqIFMYqydOxMF42391407 = -641256005;    float BwNofGPSqfqqIFMYqydOxMF86594158 = -111668040;     BwNofGPSqfqqIFMYqydOxMF765598 = BwNofGPSqfqqIFMYqydOxMF94654448;     BwNofGPSqfqqIFMYqydOxMF94654448 = BwNofGPSqfqqIFMYqydOxMF37404639;     BwNofGPSqfqqIFMYqydOxMF37404639 = BwNofGPSqfqqIFMYqydOxMF99317673;     BwNofGPSqfqqIFMYqydOxMF99317673 = BwNofGPSqfqqIFMYqydOxMF39538657;     BwNofGPSqfqqIFMYqydOxMF39538657 = BwNofGPSqfqqIFMYqydOxMF33149589;     BwNofGPSqfqqIFMYqydOxMF33149589 = BwNofGPSqfqqIFMYqydOxMF78052435;     BwNofGPSqfqqIFMYqydOxMF78052435 = BwNofGPSqfqqIFMYqydOxMF64356788;     BwNofGPSqfqqIFMYqydOxMF64356788 = BwNofGPSqfqqIFMYqydOxMF90756056;     BwNofGPSqfqqIFMYqydOxMF90756056 = BwNofGPSqfqqIFMYqydOxMF74373851;     BwNofGPSqfqqIFMYqydOxMF74373851 = BwNofGPSqfqqIFMYqydOxMF31956125;     BwNofGPSqfqqIFMYqydOxMF31956125 = BwNofGPSqfqqIFMYqydOxMF7184878;     BwNofGPSqfqqIFMYqydOxMF7184878 = BwNofGPSqfqqIFMYqydOxMF51111283;     BwNofGPSqfqqIFMYqydOxMF51111283 = BwNofGPSqfqqIFMYqydOxMF71801354;     BwNofGPSqfqqIFMYqydOxMF71801354 = BwNofGPSqfqqIFMYqydOxMF88223008;     BwNofGPSqfqqIFMYqydOxMF88223008 = BwNofGPSqfqqIFMYqydOxMF19444995;     BwNofGPSqfqqIFMYqydOxMF19444995 = BwNofGPSqfqqIFMYqydOxMF96481116;     BwNofGPSqfqqIFMYqydOxMF96481116 = BwNofGPSqfqqIFMYqydOxMF45752468;     BwNofGPSqfqqIFMYqydOxMF45752468 = BwNofGPSqfqqIFMYqydOxMF40086432;     BwNofGPSqfqqIFMYqydOxMF40086432 = BwNofGPSqfqqIFMYqydOxMF29771978;     BwNofGPSqfqqIFMYqydOxMF29771978 = BwNofGPSqfqqIFMYqydOxMF69403247;     BwNofGPSqfqqIFMYqydOxMF69403247 = BwNofGPSqfqqIFMYqydOxMF46296656;     BwNofGPSqfqqIFMYqydOxMF46296656 = BwNofGPSqfqqIFMYqydOxMF33834433;     BwNofGPSqfqqIFMYqydOxMF33834433 = BwNofGPSqfqqIFMYqydOxMF3553529;     BwNofGPSqfqqIFMYqydOxMF3553529 = BwNofGPSqfqqIFMYqydOxMF26786427;     BwNofGPSqfqqIFMYqydOxMF26786427 = BwNofGPSqfqqIFMYqydOxMF76173823;     BwNofGPSqfqqIFMYqydOxMF76173823 = BwNofGPSqfqqIFMYqydOxMF97060142;     BwNofGPSqfqqIFMYqydOxMF97060142 = BwNofGPSqfqqIFMYqydOxMF78566156;     BwNofGPSqfqqIFMYqydOxMF78566156 = BwNofGPSqfqqIFMYqydOxMF75908443;     BwNofGPSqfqqIFMYqydOxMF75908443 = BwNofGPSqfqqIFMYqydOxMF98878648;     BwNofGPSqfqqIFMYqydOxMF98878648 = BwNofGPSqfqqIFMYqydOxMF95960449;     BwNofGPSqfqqIFMYqydOxMF95960449 = BwNofGPSqfqqIFMYqydOxMF99971332;     BwNofGPSqfqqIFMYqydOxMF99971332 = BwNofGPSqfqqIFMYqydOxMF5920366;     BwNofGPSqfqqIFMYqydOxMF5920366 = BwNofGPSqfqqIFMYqydOxMF82465000;     BwNofGPSqfqqIFMYqydOxMF82465000 = BwNofGPSqfqqIFMYqydOxMF51427864;     BwNofGPSqfqqIFMYqydOxMF51427864 = BwNofGPSqfqqIFMYqydOxMF69867654;     BwNofGPSqfqqIFMYqydOxMF69867654 = BwNofGPSqfqqIFMYqydOxMF78365041;     BwNofGPSqfqqIFMYqydOxMF78365041 = BwNofGPSqfqqIFMYqydOxMF74897657;     BwNofGPSqfqqIFMYqydOxMF74897657 = BwNofGPSqfqqIFMYqydOxMF47408309;     BwNofGPSqfqqIFMYqydOxMF47408309 = BwNofGPSqfqqIFMYqydOxMF27931803;     BwNofGPSqfqqIFMYqydOxMF27931803 = BwNofGPSqfqqIFMYqydOxMF77628469;     BwNofGPSqfqqIFMYqydOxMF77628469 = BwNofGPSqfqqIFMYqydOxMF23252660;     BwNofGPSqfqqIFMYqydOxMF23252660 = BwNofGPSqfqqIFMYqydOxMF13963512;     BwNofGPSqfqqIFMYqydOxMF13963512 = BwNofGPSqfqqIFMYqydOxMF20804809;     BwNofGPSqfqqIFMYqydOxMF20804809 = BwNofGPSqfqqIFMYqydOxMF18578951;     BwNofGPSqfqqIFMYqydOxMF18578951 = BwNofGPSqfqqIFMYqydOxMF82021963;     BwNofGPSqfqqIFMYqydOxMF82021963 = BwNofGPSqfqqIFMYqydOxMF76512288;     BwNofGPSqfqqIFMYqydOxMF76512288 = BwNofGPSqfqqIFMYqydOxMF50013488;     BwNofGPSqfqqIFMYqydOxMF50013488 = BwNofGPSqfqqIFMYqydOxMF56486374;     BwNofGPSqfqqIFMYqydOxMF56486374 = BwNofGPSqfqqIFMYqydOxMF37914797;     BwNofGPSqfqqIFMYqydOxMF37914797 = BwNofGPSqfqqIFMYqydOxMF1089852;     BwNofGPSqfqqIFMYqydOxMF1089852 = BwNofGPSqfqqIFMYqydOxMF24862697;     BwNofGPSqfqqIFMYqydOxMF24862697 = BwNofGPSqfqqIFMYqydOxMF48601591;     BwNofGPSqfqqIFMYqydOxMF48601591 = BwNofGPSqfqqIFMYqydOxMF23899283;     BwNofGPSqfqqIFMYqydOxMF23899283 = BwNofGPSqfqqIFMYqydOxMF17833119;     BwNofGPSqfqqIFMYqydOxMF17833119 = BwNofGPSqfqqIFMYqydOxMF54468941;     BwNofGPSqfqqIFMYqydOxMF54468941 = BwNofGPSqfqqIFMYqydOxMF60820015;     BwNofGPSqfqqIFMYqydOxMF60820015 = BwNofGPSqfqqIFMYqydOxMF33851111;     BwNofGPSqfqqIFMYqydOxMF33851111 = BwNofGPSqfqqIFMYqydOxMF72531247;     BwNofGPSqfqqIFMYqydOxMF72531247 = BwNofGPSqfqqIFMYqydOxMF63364833;     BwNofGPSqfqqIFMYqydOxMF63364833 = BwNofGPSqfqqIFMYqydOxMF36089447;     BwNofGPSqfqqIFMYqydOxMF36089447 = BwNofGPSqfqqIFMYqydOxMF99486278;     BwNofGPSqfqqIFMYqydOxMF99486278 = BwNofGPSqfqqIFMYqydOxMF88448344;     BwNofGPSqfqqIFMYqydOxMF88448344 = BwNofGPSqfqqIFMYqydOxMF91877408;     BwNofGPSqfqqIFMYqydOxMF91877408 = BwNofGPSqfqqIFMYqydOxMF78413401;     BwNofGPSqfqqIFMYqydOxMF78413401 = BwNofGPSqfqqIFMYqydOxMF31984793;     BwNofGPSqfqqIFMYqydOxMF31984793 = BwNofGPSqfqqIFMYqydOxMF1264512;     BwNofGPSqfqqIFMYqydOxMF1264512 = BwNofGPSqfqqIFMYqydOxMF68646282;     BwNofGPSqfqqIFMYqydOxMF68646282 = BwNofGPSqfqqIFMYqydOxMF20373490;     BwNofGPSqfqqIFMYqydOxMF20373490 = BwNofGPSqfqqIFMYqydOxMF18355354;     BwNofGPSqfqqIFMYqydOxMF18355354 = BwNofGPSqfqqIFMYqydOxMF41079954;     BwNofGPSqfqqIFMYqydOxMF41079954 = BwNofGPSqfqqIFMYqydOxMF21583459;     BwNofGPSqfqqIFMYqydOxMF21583459 = BwNofGPSqfqqIFMYqydOxMF98344159;     BwNofGPSqfqqIFMYqydOxMF98344159 = BwNofGPSqfqqIFMYqydOxMF12154629;     BwNofGPSqfqqIFMYqydOxMF12154629 = BwNofGPSqfqqIFMYqydOxMF52143508;     BwNofGPSqfqqIFMYqydOxMF52143508 = BwNofGPSqfqqIFMYqydOxMF46150587;     BwNofGPSqfqqIFMYqydOxMF46150587 = BwNofGPSqfqqIFMYqydOxMF32333145;     BwNofGPSqfqqIFMYqydOxMF32333145 = BwNofGPSqfqqIFMYqydOxMF13029625;     BwNofGPSqfqqIFMYqydOxMF13029625 = BwNofGPSqfqqIFMYqydOxMF84974578;     BwNofGPSqfqqIFMYqydOxMF84974578 = BwNofGPSqfqqIFMYqydOxMF44764464;     BwNofGPSqfqqIFMYqydOxMF44764464 = BwNofGPSqfqqIFMYqydOxMF99661534;     BwNofGPSqfqqIFMYqydOxMF99661534 = BwNofGPSqfqqIFMYqydOxMF47046654;     BwNofGPSqfqqIFMYqydOxMF47046654 = BwNofGPSqfqqIFMYqydOxMF22079783;     BwNofGPSqfqqIFMYqydOxMF22079783 = BwNofGPSqfqqIFMYqydOxMF37993646;     BwNofGPSqfqqIFMYqydOxMF37993646 = BwNofGPSqfqqIFMYqydOxMF97788796;     BwNofGPSqfqqIFMYqydOxMF97788796 = BwNofGPSqfqqIFMYqydOxMF71097752;     BwNofGPSqfqqIFMYqydOxMF71097752 = BwNofGPSqfqqIFMYqydOxMF51369741;     BwNofGPSqfqqIFMYqydOxMF51369741 = BwNofGPSqfqqIFMYqydOxMF82021082;     BwNofGPSqfqqIFMYqydOxMF82021082 = BwNofGPSqfqqIFMYqydOxMF64631881;     BwNofGPSqfqqIFMYqydOxMF64631881 = BwNofGPSqfqqIFMYqydOxMF96958923;     BwNofGPSqfqqIFMYqydOxMF96958923 = BwNofGPSqfqqIFMYqydOxMF9047640;     BwNofGPSqfqqIFMYqydOxMF9047640 = BwNofGPSqfqqIFMYqydOxMF44513930;     BwNofGPSqfqqIFMYqydOxMF44513930 = BwNofGPSqfqqIFMYqydOxMF2366411;     BwNofGPSqfqqIFMYqydOxMF2366411 = BwNofGPSqfqqIFMYqydOxMF84043475;     BwNofGPSqfqqIFMYqydOxMF84043475 = BwNofGPSqfqqIFMYqydOxMF91842355;     BwNofGPSqfqqIFMYqydOxMF91842355 = BwNofGPSqfqqIFMYqydOxMF78142191;     BwNofGPSqfqqIFMYqydOxMF78142191 = BwNofGPSqfqqIFMYqydOxMF34804315;     BwNofGPSqfqqIFMYqydOxMF34804315 = BwNofGPSqfqqIFMYqydOxMF22086104;     BwNofGPSqfqqIFMYqydOxMF22086104 = BwNofGPSqfqqIFMYqydOxMF42391407;     BwNofGPSqfqqIFMYqydOxMF42391407 = BwNofGPSqfqqIFMYqydOxMF86594158;     BwNofGPSqfqqIFMYqydOxMF86594158 = BwNofGPSqfqqIFMYqydOxMF765598;}



void SigCSZCmXXlltneCmOSAMTFPpL72299204() {     float prJcSQYNFLiKmwERVMUIepn84489115 = -461690107;    float prJcSQYNFLiKmwERVMUIepn92252543 = -717125783;    float prJcSQYNFLiKmwERVMUIepn25990757 = -542267717;    float prJcSQYNFLiKmwERVMUIepn96465626 = -585440708;    float prJcSQYNFLiKmwERVMUIepn19099994 = -332764910;    float prJcSQYNFLiKmwERVMUIepn44489107 = -228750346;    float prJcSQYNFLiKmwERVMUIepn14932999 = -729810226;    float prJcSQYNFLiKmwERVMUIepn7696871 = -119538004;    float prJcSQYNFLiKmwERVMUIepn40975585 = -908169178;    float prJcSQYNFLiKmwERVMUIepn20479440 = -434533168;    float prJcSQYNFLiKmwERVMUIepn74845160 = -596791502;    float prJcSQYNFLiKmwERVMUIepn97396647 = -403444977;    float prJcSQYNFLiKmwERVMUIepn2165135 = -305190382;    float prJcSQYNFLiKmwERVMUIepn66174499 = 55751755;    float prJcSQYNFLiKmwERVMUIepn92402266 = -224961024;    float prJcSQYNFLiKmwERVMUIepn91259022 = 55343070;    float prJcSQYNFLiKmwERVMUIepn96346527 = -307408410;    float prJcSQYNFLiKmwERVMUIepn59829737 = -55849885;    float prJcSQYNFLiKmwERVMUIepn81062912 = -853674507;    float prJcSQYNFLiKmwERVMUIepn3879622 = -535820779;    float prJcSQYNFLiKmwERVMUIepn36742758 = -787700957;    float prJcSQYNFLiKmwERVMUIepn47298728 = -701477565;    float prJcSQYNFLiKmwERVMUIepn3010299 = -985236330;    float prJcSQYNFLiKmwERVMUIepn4696224 = -281672426;    float prJcSQYNFLiKmwERVMUIepn63388519 = -975945909;    float prJcSQYNFLiKmwERVMUIepn29166581 = -380740769;    float prJcSQYNFLiKmwERVMUIepn18652082 = -132487892;    float prJcSQYNFLiKmwERVMUIepn21165357 = -629133965;    float prJcSQYNFLiKmwERVMUIepn47826585 = -200760891;    float prJcSQYNFLiKmwERVMUIepn34426975 = -858591887;    float prJcSQYNFLiKmwERVMUIepn77324872 = 5710974;    float prJcSQYNFLiKmwERVMUIepn24764621 = -336479772;    float prJcSQYNFLiKmwERVMUIepn20045067 = -888193698;    float prJcSQYNFLiKmwERVMUIepn18189715 = -321912027;    float prJcSQYNFLiKmwERVMUIepn19031190 = -30213470;    float prJcSQYNFLiKmwERVMUIepn39728888 = 31354338;    float prJcSQYNFLiKmwERVMUIepn78128631 = -28868072;    float prJcSQYNFLiKmwERVMUIepn25279449 = 24293173;    float prJcSQYNFLiKmwERVMUIepn8024028 = -852812060;    float prJcSQYNFLiKmwERVMUIepn67120918 = -745540446;    float prJcSQYNFLiKmwERVMUIepn42395990 = -159668761;    float prJcSQYNFLiKmwERVMUIepn52592386 = -441875099;    float prJcSQYNFLiKmwERVMUIepn46763658 = -539485864;    float prJcSQYNFLiKmwERVMUIepn68000328 = -656500884;    float prJcSQYNFLiKmwERVMUIepn46566201 = -502959673;    float prJcSQYNFLiKmwERVMUIepn26288845 = 58798048;    float prJcSQYNFLiKmwERVMUIepn9691258 = 30365459;    float prJcSQYNFLiKmwERVMUIepn88755334 = 58474001;    float prJcSQYNFLiKmwERVMUIepn90360587 = -476042206;    float prJcSQYNFLiKmwERVMUIepn73788127 = -501220249;    float prJcSQYNFLiKmwERVMUIepn41180684 = -57679756;    float prJcSQYNFLiKmwERVMUIepn76368416 = -924207010;    float prJcSQYNFLiKmwERVMUIepn93983993 = -703959957;    float prJcSQYNFLiKmwERVMUIepn69831888 = -90875852;    float prJcSQYNFLiKmwERVMUIepn35556447 = -150956773;    float prJcSQYNFLiKmwERVMUIepn37190388 = -760212542;    float prJcSQYNFLiKmwERVMUIepn89242245 = -731889453;    float prJcSQYNFLiKmwERVMUIepn21294533 = -160595292;    float prJcSQYNFLiKmwERVMUIepn33077107 = -609494800;    float prJcSQYNFLiKmwERVMUIepn89933412 = -952024141;    float prJcSQYNFLiKmwERVMUIepn25837026 = 3737545;    float prJcSQYNFLiKmwERVMUIepn93767641 = -676261;    float prJcSQYNFLiKmwERVMUIepn59870286 = -918777113;    float prJcSQYNFLiKmwERVMUIepn6548610 = 50422708;    float prJcSQYNFLiKmwERVMUIepn43154567 = -340244143;    float prJcSQYNFLiKmwERVMUIepn50080540 = -160311731;    float prJcSQYNFLiKmwERVMUIepn77351581 = -515251279;    float prJcSQYNFLiKmwERVMUIepn83975420 = -983278355;    float prJcSQYNFLiKmwERVMUIepn47143309 = -914034776;    float prJcSQYNFLiKmwERVMUIepn52673379 = -156315362;    float prJcSQYNFLiKmwERVMUIepn13130392 = -915788858;    float prJcSQYNFLiKmwERVMUIepn71067078 = -231701584;    float prJcSQYNFLiKmwERVMUIepn51805710 = -203037825;    float prJcSQYNFLiKmwERVMUIepn13941994 = -8134062;    float prJcSQYNFLiKmwERVMUIepn61483632 = -276152018;    float prJcSQYNFLiKmwERVMUIepn84150371 = -245825858;    float prJcSQYNFLiKmwERVMUIepn535070 = -61991702;    float prJcSQYNFLiKmwERVMUIepn35009970 = -228735446;    float prJcSQYNFLiKmwERVMUIepn58130022 = -778712754;    float prJcSQYNFLiKmwERVMUIepn37099675 = -934743957;    float prJcSQYNFLiKmwERVMUIepn19475324 = -311106229;    float prJcSQYNFLiKmwERVMUIepn29896747 = -90961894;    float prJcSQYNFLiKmwERVMUIepn30804770 = -53091760;    float prJcSQYNFLiKmwERVMUIepn74038457 = -699540642;    float prJcSQYNFLiKmwERVMUIepn93246291 = -700912131;    float prJcSQYNFLiKmwERVMUIepn956456 = -70082017;    float prJcSQYNFLiKmwERVMUIepn30780627 = -632519815;    float prJcSQYNFLiKmwERVMUIepn50213178 = -697317847;    float prJcSQYNFLiKmwERVMUIepn82633268 = -70955255;    float prJcSQYNFLiKmwERVMUIepn81840802 = -270000928;    float prJcSQYNFLiKmwERVMUIepn50486643 = -236756209;    float prJcSQYNFLiKmwERVMUIepn56834098 = -868272781;    float prJcSQYNFLiKmwERVMUIepn92202341 = -366212028;    float prJcSQYNFLiKmwERVMUIepn18090616 = -900787920;    float prJcSQYNFLiKmwERVMUIepn41283893 = -649277992;    float prJcSQYNFLiKmwERVMUIepn48628349 = -58992500;    float prJcSQYNFLiKmwERVMUIepn92722100 = -523097986;    float prJcSQYNFLiKmwERVMUIepn40215049 = -489908572;    float prJcSQYNFLiKmwERVMUIepn24845761 = -216256742;    float prJcSQYNFLiKmwERVMUIepn96485661 = -461690107;     prJcSQYNFLiKmwERVMUIepn84489115 = prJcSQYNFLiKmwERVMUIepn92252543;     prJcSQYNFLiKmwERVMUIepn92252543 = prJcSQYNFLiKmwERVMUIepn25990757;     prJcSQYNFLiKmwERVMUIepn25990757 = prJcSQYNFLiKmwERVMUIepn96465626;     prJcSQYNFLiKmwERVMUIepn96465626 = prJcSQYNFLiKmwERVMUIepn19099994;     prJcSQYNFLiKmwERVMUIepn19099994 = prJcSQYNFLiKmwERVMUIepn44489107;     prJcSQYNFLiKmwERVMUIepn44489107 = prJcSQYNFLiKmwERVMUIepn14932999;     prJcSQYNFLiKmwERVMUIepn14932999 = prJcSQYNFLiKmwERVMUIepn7696871;     prJcSQYNFLiKmwERVMUIepn7696871 = prJcSQYNFLiKmwERVMUIepn40975585;     prJcSQYNFLiKmwERVMUIepn40975585 = prJcSQYNFLiKmwERVMUIepn20479440;     prJcSQYNFLiKmwERVMUIepn20479440 = prJcSQYNFLiKmwERVMUIepn74845160;     prJcSQYNFLiKmwERVMUIepn74845160 = prJcSQYNFLiKmwERVMUIepn97396647;     prJcSQYNFLiKmwERVMUIepn97396647 = prJcSQYNFLiKmwERVMUIepn2165135;     prJcSQYNFLiKmwERVMUIepn2165135 = prJcSQYNFLiKmwERVMUIepn66174499;     prJcSQYNFLiKmwERVMUIepn66174499 = prJcSQYNFLiKmwERVMUIepn92402266;     prJcSQYNFLiKmwERVMUIepn92402266 = prJcSQYNFLiKmwERVMUIepn91259022;     prJcSQYNFLiKmwERVMUIepn91259022 = prJcSQYNFLiKmwERVMUIepn96346527;     prJcSQYNFLiKmwERVMUIepn96346527 = prJcSQYNFLiKmwERVMUIepn59829737;     prJcSQYNFLiKmwERVMUIepn59829737 = prJcSQYNFLiKmwERVMUIepn81062912;     prJcSQYNFLiKmwERVMUIepn81062912 = prJcSQYNFLiKmwERVMUIepn3879622;     prJcSQYNFLiKmwERVMUIepn3879622 = prJcSQYNFLiKmwERVMUIepn36742758;     prJcSQYNFLiKmwERVMUIepn36742758 = prJcSQYNFLiKmwERVMUIepn47298728;     prJcSQYNFLiKmwERVMUIepn47298728 = prJcSQYNFLiKmwERVMUIepn3010299;     prJcSQYNFLiKmwERVMUIepn3010299 = prJcSQYNFLiKmwERVMUIepn4696224;     prJcSQYNFLiKmwERVMUIepn4696224 = prJcSQYNFLiKmwERVMUIepn63388519;     prJcSQYNFLiKmwERVMUIepn63388519 = prJcSQYNFLiKmwERVMUIepn29166581;     prJcSQYNFLiKmwERVMUIepn29166581 = prJcSQYNFLiKmwERVMUIepn18652082;     prJcSQYNFLiKmwERVMUIepn18652082 = prJcSQYNFLiKmwERVMUIepn21165357;     prJcSQYNFLiKmwERVMUIepn21165357 = prJcSQYNFLiKmwERVMUIepn47826585;     prJcSQYNFLiKmwERVMUIepn47826585 = prJcSQYNFLiKmwERVMUIepn34426975;     prJcSQYNFLiKmwERVMUIepn34426975 = prJcSQYNFLiKmwERVMUIepn77324872;     prJcSQYNFLiKmwERVMUIepn77324872 = prJcSQYNFLiKmwERVMUIepn24764621;     prJcSQYNFLiKmwERVMUIepn24764621 = prJcSQYNFLiKmwERVMUIepn20045067;     prJcSQYNFLiKmwERVMUIepn20045067 = prJcSQYNFLiKmwERVMUIepn18189715;     prJcSQYNFLiKmwERVMUIepn18189715 = prJcSQYNFLiKmwERVMUIepn19031190;     prJcSQYNFLiKmwERVMUIepn19031190 = prJcSQYNFLiKmwERVMUIepn39728888;     prJcSQYNFLiKmwERVMUIepn39728888 = prJcSQYNFLiKmwERVMUIepn78128631;     prJcSQYNFLiKmwERVMUIepn78128631 = prJcSQYNFLiKmwERVMUIepn25279449;     prJcSQYNFLiKmwERVMUIepn25279449 = prJcSQYNFLiKmwERVMUIepn8024028;     prJcSQYNFLiKmwERVMUIepn8024028 = prJcSQYNFLiKmwERVMUIepn67120918;     prJcSQYNFLiKmwERVMUIepn67120918 = prJcSQYNFLiKmwERVMUIepn42395990;     prJcSQYNFLiKmwERVMUIepn42395990 = prJcSQYNFLiKmwERVMUIepn52592386;     prJcSQYNFLiKmwERVMUIepn52592386 = prJcSQYNFLiKmwERVMUIepn46763658;     prJcSQYNFLiKmwERVMUIepn46763658 = prJcSQYNFLiKmwERVMUIepn68000328;     prJcSQYNFLiKmwERVMUIepn68000328 = prJcSQYNFLiKmwERVMUIepn46566201;     prJcSQYNFLiKmwERVMUIepn46566201 = prJcSQYNFLiKmwERVMUIepn26288845;     prJcSQYNFLiKmwERVMUIepn26288845 = prJcSQYNFLiKmwERVMUIepn9691258;     prJcSQYNFLiKmwERVMUIepn9691258 = prJcSQYNFLiKmwERVMUIepn88755334;     prJcSQYNFLiKmwERVMUIepn88755334 = prJcSQYNFLiKmwERVMUIepn90360587;     prJcSQYNFLiKmwERVMUIepn90360587 = prJcSQYNFLiKmwERVMUIepn73788127;     prJcSQYNFLiKmwERVMUIepn73788127 = prJcSQYNFLiKmwERVMUIepn41180684;     prJcSQYNFLiKmwERVMUIepn41180684 = prJcSQYNFLiKmwERVMUIepn76368416;     prJcSQYNFLiKmwERVMUIepn76368416 = prJcSQYNFLiKmwERVMUIepn93983993;     prJcSQYNFLiKmwERVMUIepn93983993 = prJcSQYNFLiKmwERVMUIepn69831888;     prJcSQYNFLiKmwERVMUIepn69831888 = prJcSQYNFLiKmwERVMUIepn35556447;     prJcSQYNFLiKmwERVMUIepn35556447 = prJcSQYNFLiKmwERVMUIepn37190388;     prJcSQYNFLiKmwERVMUIepn37190388 = prJcSQYNFLiKmwERVMUIepn89242245;     prJcSQYNFLiKmwERVMUIepn89242245 = prJcSQYNFLiKmwERVMUIepn21294533;     prJcSQYNFLiKmwERVMUIepn21294533 = prJcSQYNFLiKmwERVMUIepn33077107;     prJcSQYNFLiKmwERVMUIepn33077107 = prJcSQYNFLiKmwERVMUIepn89933412;     prJcSQYNFLiKmwERVMUIepn89933412 = prJcSQYNFLiKmwERVMUIepn25837026;     prJcSQYNFLiKmwERVMUIepn25837026 = prJcSQYNFLiKmwERVMUIepn93767641;     prJcSQYNFLiKmwERVMUIepn93767641 = prJcSQYNFLiKmwERVMUIepn59870286;     prJcSQYNFLiKmwERVMUIepn59870286 = prJcSQYNFLiKmwERVMUIepn6548610;     prJcSQYNFLiKmwERVMUIepn6548610 = prJcSQYNFLiKmwERVMUIepn43154567;     prJcSQYNFLiKmwERVMUIepn43154567 = prJcSQYNFLiKmwERVMUIepn50080540;     prJcSQYNFLiKmwERVMUIepn50080540 = prJcSQYNFLiKmwERVMUIepn77351581;     prJcSQYNFLiKmwERVMUIepn77351581 = prJcSQYNFLiKmwERVMUIepn83975420;     prJcSQYNFLiKmwERVMUIepn83975420 = prJcSQYNFLiKmwERVMUIepn47143309;     prJcSQYNFLiKmwERVMUIepn47143309 = prJcSQYNFLiKmwERVMUIepn52673379;     prJcSQYNFLiKmwERVMUIepn52673379 = prJcSQYNFLiKmwERVMUIepn13130392;     prJcSQYNFLiKmwERVMUIepn13130392 = prJcSQYNFLiKmwERVMUIepn71067078;     prJcSQYNFLiKmwERVMUIepn71067078 = prJcSQYNFLiKmwERVMUIepn51805710;     prJcSQYNFLiKmwERVMUIepn51805710 = prJcSQYNFLiKmwERVMUIepn13941994;     prJcSQYNFLiKmwERVMUIepn13941994 = prJcSQYNFLiKmwERVMUIepn61483632;     prJcSQYNFLiKmwERVMUIepn61483632 = prJcSQYNFLiKmwERVMUIepn84150371;     prJcSQYNFLiKmwERVMUIepn84150371 = prJcSQYNFLiKmwERVMUIepn535070;     prJcSQYNFLiKmwERVMUIepn535070 = prJcSQYNFLiKmwERVMUIepn35009970;     prJcSQYNFLiKmwERVMUIepn35009970 = prJcSQYNFLiKmwERVMUIepn58130022;     prJcSQYNFLiKmwERVMUIepn58130022 = prJcSQYNFLiKmwERVMUIepn37099675;     prJcSQYNFLiKmwERVMUIepn37099675 = prJcSQYNFLiKmwERVMUIepn19475324;     prJcSQYNFLiKmwERVMUIepn19475324 = prJcSQYNFLiKmwERVMUIepn29896747;     prJcSQYNFLiKmwERVMUIepn29896747 = prJcSQYNFLiKmwERVMUIepn30804770;     prJcSQYNFLiKmwERVMUIepn30804770 = prJcSQYNFLiKmwERVMUIepn74038457;     prJcSQYNFLiKmwERVMUIepn74038457 = prJcSQYNFLiKmwERVMUIepn93246291;     prJcSQYNFLiKmwERVMUIepn93246291 = prJcSQYNFLiKmwERVMUIepn956456;     prJcSQYNFLiKmwERVMUIepn956456 = prJcSQYNFLiKmwERVMUIepn30780627;     prJcSQYNFLiKmwERVMUIepn30780627 = prJcSQYNFLiKmwERVMUIepn50213178;     prJcSQYNFLiKmwERVMUIepn50213178 = prJcSQYNFLiKmwERVMUIepn82633268;     prJcSQYNFLiKmwERVMUIepn82633268 = prJcSQYNFLiKmwERVMUIepn81840802;     prJcSQYNFLiKmwERVMUIepn81840802 = prJcSQYNFLiKmwERVMUIepn50486643;     prJcSQYNFLiKmwERVMUIepn50486643 = prJcSQYNFLiKmwERVMUIepn56834098;     prJcSQYNFLiKmwERVMUIepn56834098 = prJcSQYNFLiKmwERVMUIepn92202341;     prJcSQYNFLiKmwERVMUIepn92202341 = prJcSQYNFLiKmwERVMUIepn18090616;     prJcSQYNFLiKmwERVMUIepn18090616 = prJcSQYNFLiKmwERVMUIepn41283893;     prJcSQYNFLiKmwERVMUIepn41283893 = prJcSQYNFLiKmwERVMUIepn48628349;     prJcSQYNFLiKmwERVMUIepn48628349 = prJcSQYNFLiKmwERVMUIepn92722100;     prJcSQYNFLiKmwERVMUIepn92722100 = prJcSQYNFLiKmwERVMUIepn40215049;     prJcSQYNFLiKmwERVMUIepn40215049 = prJcSQYNFLiKmwERVMUIepn24845761;     prJcSQYNFLiKmwERVMUIepn24845761 = prJcSQYNFLiKmwERVMUIepn96485661;     prJcSQYNFLiKmwERVMUIepn96485661 = prJcSQYNFLiKmwERVMUIepn84489115;}



void mTXzXqtNYyrMPBIBtznoaBmjpY57362042() {     float BbnTKoHgKXdDtRAJfIBPvSM68212633 = -811712174;    float BbnTKoHgKXdDtRAJfIBPvSM89850639 = -520777634;    float BbnTKoHgKXdDtRAJfIBPvSM14576874 = -410575408;    float BbnTKoHgKXdDtRAJfIBPvSM93613579 = -590322637;    float BbnTKoHgKXdDtRAJfIBPvSM98661329 = -730713102;    float BbnTKoHgKXdDtRAJfIBPvSM55828625 = -332071015;    float BbnTKoHgKXdDtRAJfIBPvSM51813561 = -751324364;    float BbnTKoHgKXdDtRAJfIBPvSM51036953 = -739992590;    float BbnTKoHgKXdDtRAJfIBPvSM91195113 = -505651875;    float BbnTKoHgKXdDtRAJfIBPvSM66585028 = -657574184;    float BbnTKoHgKXdDtRAJfIBPvSM17734197 = -437076760;    float BbnTKoHgKXdDtRAJfIBPvSM87608418 = -332584248;    float BbnTKoHgKXdDtRAJfIBPvSM53218986 = -148022625;    float BbnTKoHgKXdDtRAJfIBPvSM60547643 = -293931108;    float BbnTKoHgKXdDtRAJfIBPvSM96581525 = -150658329;    float BbnTKoHgKXdDtRAJfIBPvSM63073051 = -968784582;    float BbnTKoHgKXdDtRAJfIBPvSM96211938 = -466288273;    float BbnTKoHgKXdDtRAJfIBPvSM73907007 = -766701459;    float BbnTKoHgKXdDtRAJfIBPvSM22039393 = -642323746;    float BbnTKoHgKXdDtRAJfIBPvSM77987266 = -152113696;    float BbnTKoHgKXdDtRAJfIBPvSM4082268 = -362167477;    float BbnTKoHgKXdDtRAJfIBPvSM48300799 = -614632851;    float BbnTKoHgKXdDtRAJfIBPvSM72186163 = 85368933;    float BbnTKoHgKXdDtRAJfIBPvSM5838919 = -920905079;    float BbnTKoHgKXdDtRAJfIBPvSM99990612 = 45723330;    float BbnTKoHgKXdDtRAJfIBPvSM82159339 = -823707797;    float BbnTKoHgKXdDtRAJfIBPvSM40244021 = -576363315;    float BbnTKoHgKXdDtRAJfIBPvSM63764557 = -415575453;    float BbnTKoHgKXdDtRAJfIBPvSM19744726 = -724956791;    float BbnTKoHgKXdDtRAJfIBPvSM69975302 = -431198261;    float BbnTKoHgKXdDtRAJfIBPvSM58689295 = -213387047;    float BbnTKoHgKXdDtRAJfIBPvSM49557909 = -885676995;    float BbnTKoHgKXdDtRAJfIBPvSM34169768 = -453407789;    float BbnTKoHgKXdDtRAJfIBPvSM53914429 = -726008675;    float BbnTKoHgKXdDtRAJfIBPvSM86634515 = -864504078;    float BbnTKoHgKXdDtRAJfIBPvSM9590122 = 52957861;    float BbnTKoHgKXdDtRAJfIBPvSM77892221 = -349209369;    float BbnTKoHgKXdDtRAJfIBPvSM75661240 = -974850044;    float BbnTKoHgKXdDtRAJfIBPvSM68639747 = -58370942;    float BbnTKoHgKXdDtRAJfIBPvSM6310035 = -692187325;    float BbnTKoHgKXdDtRAJfIBPvSM7163511 = -909708887;    float BbnTKoHgKXdDtRAJfIBPvSM81932113 = -47900769;    float BbnTKoHgKXdDtRAJfIBPvSM79563804 = -191890118;    float BbnTKoHgKXdDtRAJfIBPvSM15195848 = -235444617;    float BbnTKoHgKXdDtRAJfIBPvSM74553452 = -828973751;    float BbnTKoHgKXdDtRAJfIBPvSM70555726 = -656233643;    float BbnTKoHgKXdDtRAJfIBPvSM42870227 = 8719552;    float BbnTKoHgKXdDtRAJfIBPvSM27497182 = -803647897;    float BbnTKoHgKXdDtRAJfIBPvSM24234801 = -175826357;    float BbnTKoHgKXdDtRAJfIBPvSM9661458 = -33235685;    float BbnTKoHgKXdDtRAJfIBPvSM81271515 = -223452157;    float BbnTKoHgKXdDtRAJfIBPvSM27874137 = -676259797;    float BbnTKoHgKXdDtRAJfIBPvSM39366396 = -715892323;    float BbnTKoHgKXdDtRAJfIBPvSM15764494 = -667585039;    float BbnTKoHgKXdDtRAJfIBPvSM53279774 = -467683718;    float BbnTKoHgKXdDtRAJfIBPvSM19911835 = -97079323;    float BbnTKoHgKXdDtRAJfIBPvSM17664476 = -506146568;    float BbnTKoHgKXdDtRAJfIBPvSM8737956 = -489670329;    float BbnTKoHgKXdDtRAJfIBPvSM93622967 = -536045967;    float BbnTKoHgKXdDtRAJfIBPvSM16501991 = -907005305;    float BbnTKoHgKXdDtRAJfIBPvSM15584604 = -755707701;    float BbnTKoHgKXdDtRAJfIBPvSM88049004 = -235748911;    float BbnTKoHgKXdDtRAJfIBPvSM31292227 = 84964201;    float BbnTKoHgKXdDtRAJfIBPvSM21219811 = 25546386;    float BbnTKoHgKXdDtRAJfIBPvSM7895733 = -344187138;    float BbnTKoHgKXdDtRAJfIBPvSM68176288 = -551399766;    float BbnTKoHgKXdDtRAJfIBPvSM53438651 = -879176459;    float BbnTKoHgKXdDtRAJfIBPvSM99304557 = -422013951;    float BbnTKoHgKXdDtRAJfIBPvSM73913128 = -429427030;    float BbnTKoHgKXdDtRAJfIBPvSM86991403 = -103616190;    float BbnTKoHgKXdDtRAJfIBPvSM85180830 = -519575213;    float BbnTKoHgKXdDtRAJfIBPvSM20550699 = -491438230;    float BbnTKoHgKXdDtRAJfIBPvSM5267261 = -608330518;    float BbnTKoHgKXdDtRAJfIBPvSM15729359 = -950136421;    float BbnTKoHgKXdDtRAJfIBPvSM70823755 = -242404809;    float BbnTKoHgKXdDtRAJfIBPvSM22150155 = -214266709;    float BbnTKoHgKXdDtRAJfIBPvSM68736994 = -322742734;    float BbnTKoHgKXdDtRAJfIBPvSM56990316 = -679186450;    float BbnTKoHgKXdDtRAJfIBPvSM31285467 = 8068671;    float BbnTKoHgKXdDtRAJfIBPvSM29434886 = -298043027;    float BbnTKoHgKXdDtRAJfIBPvSM39289112 = -732427350;    float BbnTKoHgKXdDtRAJfIBPvSM12746839 = -772715419;    float BbnTKoHgKXdDtRAJfIBPvSM39529757 = -139749097;    float BbnTKoHgKXdDtRAJfIBPvSM10083269 = -591721107;    float BbnTKoHgKXdDtRAJfIBPvSM88703787 = -107746104;    float BbnTKoHgKXdDtRAJfIBPvSM30815159 = -537127251;    float BbnTKoHgKXdDtRAJfIBPvSM10191513 = -69784672;    float BbnTKoHgKXdDtRAJfIBPvSM18405274 = -785822750;    float BbnTKoHgKXdDtRAJfIBPvSM634655 = -158324958;    float BbnTKoHgKXdDtRAJfIBPvSM66722681 = -667424755;    float BbnTKoHgKXdDtRAJfIBPvSM91925646 = -440895572;    float BbnTKoHgKXdDtRAJfIBPvSM69154266 = -859539040;    float BbnTKoHgKXdDtRAJfIBPvSM82038272 = -338804077;    float BbnTKoHgKXdDtRAJfIBPvSM52137756 = -151365637;    float BbnTKoHgKXdDtRAJfIBPvSM90725430 = -936479625;    float BbnTKoHgKXdDtRAJfIBPvSM19114507 = -573959977;    float BbnTKoHgKXdDtRAJfIBPvSM50639886 = -32864970;    float BbnTKoHgKXdDtRAJfIBPvSM58343994 = -117436504;    float BbnTKoHgKXdDtRAJfIBPvSM7300116 = -891257480;    float BbnTKoHgKXdDtRAJfIBPvSM6377165 = -811712174;     BbnTKoHgKXdDtRAJfIBPvSM68212633 = BbnTKoHgKXdDtRAJfIBPvSM89850639;     BbnTKoHgKXdDtRAJfIBPvSM89850639 = BbnTKoHgKXdDtRAJfIBPvSM14576874;     BbnTKoHgKXdDtRAJfIBPvSM14576874 = BbnTKoHgKXdDtRAJfIBPvSM93613579;     BbnTKoHgKXdDtRAJfIBPvSM93613579 = BbnTKoHgKXdDtRAJfIBPvSM98661329;     BbnTKoHgKXdDtRAJfIBPvSM98661329 = BbnTKoHgKXdDtRAJfIBPvSM55828625;     BbnTKoHgKXdDtRAJfIBPvSM55828625 = BbnTKoHgKXdDtRAJfIBPvSM51813561;     BbnTKoHgKXdDtRAJfIBPvSM51813561 = BbnTKoHgKXdDtRAJfIBPvSM51036953;     BbnTKoHgKXdDtRAJfIBPvSM51036953 = BbnTKoHgKXdDtRAJfIBPvSM91195113;     BbnTKoHgKXdDtRAJfIBPvSM91195113 = BbnTKoHgKXdDtRAJfIBPvSM66585028;     BbnTKoHgKXdDtRAJfIBPvSM66585028 = BbnTKoHgKXdDtRAJfIBPvSM17734197;     BbnTKoHgKXdDtRAJfIBPvSM17734197 = BbnTKoHgKXdDtRAJfIBPvSM87608418;     BbnTKoHgKXdDtRAJfIBPvSM87608418 = BbnTKoHgKXdDtRAJfIBPvSM53218986;     BbnTKoHgKXdDtRAJfIBPvSM53218986 = BbnTKoHgKXdDtRAJfIBPvSM60547643;     BbnTKoHgKXdDtRAJfIBPvSM60547643 = BbnTKoHgKXdDtRAJfIBPvSM96581525;     BbnTKoHgKXdDtRAJfIBPvSM96581525 = BbnTKoHgKXdDtRAJfIBPvSM63073051;     BbnTKoHgKXdDtRAJfIBPvSM63073051 = BbnTKoHgKXdDtRAJfIBPvSM96211938;     BbnTKoHgKXdDtRAJfIBPvSM96211938 = BbnTKoHgKXdDtRAJfIBPvSM73907007;     BbnTKoHgKXdDtRAJfIBPvSM73907007 = BbnTKoHgKXdDtRAJfIBPvSM22039393;     BbnTKoHgKXdDtRAJfIBPvSM22039393 = BbnTKoHgKXdDtRAJfIBPvSM77987266;     BbnTKoHgKXdDtRAJfIBPvSM77987266 = BbnTKoHgKXdDtRAJfIBPvSM4082268;     BbnTKoHgKXdDtRAJfIBPvSM4082268 = BbnTKoHgKXdDtRAJfIBPvSM48300799;     BbnTKoHgKXdDtRAJfIBPvSM48300799 = BbnTKoHgKXdDtRAJfIBPvSM72186163;     BbnTKoHgKXdDtRAJfIBPvSM72186163 = BbnTKoHgKXdDtRAJfIBPvSM5838919;     BbnTKoHgKXdDtRAJfIBPvSM5838919 = BbnTKoHgKXdDtRAJfIBPvSM99990612;     BbnTKoHgKXdDtRAJfIBPvSM99990612 = BbnTKoHgKXdDtRAJfIBPvSM82159339;     BbnTKoHgKXdDtRAJfIBPvSM82159339 = BbnTKoHgKXdDtRAJfIBPvSM40244021;     BbnTKoHgKXdDtRAJfIBPvSM40244021 = BbnTKoHgKXdDtRAJfIBPvSM63764557;     BbnTKoHgKXdDtRAJfIBPvSM63764557 = BbnTKoHgKXdDtRAJfIBPvSM19744726;     BbnTKoHgKXdDtRAJfIBPvSM19744726 = BbnTKoHgKXdDtRAJfIBPvSM69975302;     BbnTKoHgKXdDtRAJfIBPvSM69975302 = BbnTKoHgKXdDtRAJfIBPvSM58689295;     BbnTKoHgKXdDtRAJfIBPvSM58689295 = BbnTKoHgKXdDtRAJfIBPvSM49557909;     BbnTKoHgKXdDtRAJfIBPvSM49557909 = BbnTKoHgKXdDtRAJfIBPvSM34169768;     BbnTKoHgKXdDtRAJfIBPvSM34169768 = BbnTKoHgKXdDtRAJfIBPvSM53914429;     BbnTKoHgKXdDtRAJfIBPvSM53914429 = BbnTKoHgKXdDtRAJfIBPvSM86634515;     BbnTKoHgKXdDtRAJfIBPvSM86634515 = BbnTKoHgKXdDtRAJfIBPvSM9590122;     BbnTKoHgKXdDtRAJfIBPvSM9590122 = BbnTKoHgKXdDtRAJfIBPvSM77892221;     BbnTKoHgKXdDtRAJfIBPvSM77892221 = BbnTKoHgKXdDtRAJfIBPvSM75661240;     BbnTKoHgKXdDtRAJfIBPvSM75661240 = BbnTKoHgKXdDtRAJfIBPvSM68639747;     BbnTKoHgKXdDtRAJfIBPvSM68639747 = BbnTKoHgKXdDtRAJfIBPvSM6310035;     BbnTKoHgKXdDtRAJfIBPvSM6310035 = BbnTKoHgKXdDtRAJfIBPvSM7163511;     BbnTKoHgKXdDtRAJfIBPvSM7163511 = BbnTKoHgKXdDtRAJfIBPvSM81932113;     BbnTKoHgKXdDtRAJfIBPvSM81932113 = BbnTKoHgKXdDtRAJfIBPvSM79563804;     BbnTKoHgKXdDtRAJfIBPvSM79563804 = BbnTKoHgKXdDtRAJfIBPvSM15195848;     BbnTKoHgKXdDtRAJfIBPvSM15195848 = BbnTKoHgKXdDtRAJfIBPvSM74553452;     BbnTKoHgKXdDtRAJfIBPvSM74553452 = BbnTKoHgKXdDtRAJfIBPvSM70555726;     BbnTKoHgKXdDtRAJfIBPvSM70555726 = BbnTKoHgKXdDtRAJfIBPvSM42870227;     BbnTKoHgKXdDtRAJfIBPvSM42870227 = BbnTKoHgKXdDtRAJfIBPvSM27497182;     BbnTKoHgKXdDtRAJfIBPvSM27497182 = BbnTKoHgKXdDtRAJfIBPvSM24234801;     BbnTKoHgKXdDtRAJfIBPvSM24234801 = BbnTKoHgKXdDtRAJfIBPvSM9661458;     BbnTKoHgKXdDtRAJfIBPvSM9661458 = BbnTKoHgKXdDtRAJfIBPvSM81271515;     BbnTKoHgKXdDtRAJfIBPvSM81271515 = BbnTKoHgKXdDtRAJfIBPvSM27874137;     BbnTKoHgKXdDtRAJfIBPvSM27874137 = BbnTKoHgKXdDtRAJfIBPvSM39366396;     BbnTKoHgKXdDtRAJfIBPvSM39366396 = BbnTKoHgKXdDtRAJfIBPvSM15764494;     BbnTKoHgKXdDtRAJfIBPvSM15764494 = BbnTKoHgKXdDtRAJfIBPvSM53279774;     BbnTKoHgKXdDtRAJfIBPvSM53279774 = BbnTKoHgKXdDtRAJfIBPvSM19911835;     BbnTKoHgKXdDtRAJfIBPvSM19911835 = BbnTKoHgKXdDtRAJfIBPvSM17664476;     BbnTKoHgKXdDtRAJfIBPvSM17664476 = BbnTKoHgKXdDtRAJfIBPvSM8737956;     BbnTKoHgKXdDtRAJfIBPvSM8737956 = BbnTKoHgKXdDtRAJfIBPvSM93622967;     BbnTKoHgKXdDtRAJfIBPvSM93622967 = BbnTKoHgKXdDtRAJfIBPvSM16501991;     BbnTKoHgKXdDtRAJfIBPvSM16501991 = BbnTKoHgKXdDtRAJfIBPvSM15584604;     BbnTKoHgKXdDtRAJfIBPvSM15584604 = BbnTKoHgKXdDtRAJfIBPvSM88049004;     BbnTKoHgKXdDtRAJfIBPvSM88049004 = BbnTKoHgKXdDtRAJfIBPvSM31292227;     BbnTKoHgKXdDtRAJfIBPvSM31292227 = BbnTKoHgKXdDtRAJfIBPvSM21219811;     BbnTKoHgKXdDtRAJfIBPvSM21219811 = BbnTKoHgKXdDtRAJfIBPvSM7895733;     BbnTKoHgKXdDtRAJfIBPvSM7895733 = BbnTKoHgKXdDtRAJfIBPvSM68176288;     BbnTKoHgKXdDtRAJfIBPvSM68176288 = BbnTKoHgKXdDtRAJfIBPvSM53438651;     BbnTKoHgKXdDtRAJfIBPvSM53438651 = BbnTKoHgKXdDtRAJfIBPvSM99304557;     BbnTKoHgKXdDtRAJfIBPvSM99304557 = BbnTKoHgKXdDtRAJfIBPvSM73913128;     BbnTKoHgKXdDtRAJfIBPvSM73913128 = BbnTKoHgKXdDtRAJfIBPvSM86991403;     BbnTKoHgKXdDtRAJfIBPvSM86991403 = BbnTKoHgKXdDtRAJfIBPvSM85180830;     BbnTKoHgKXdDtRAJfIBPvSM85180830 = BbnTKoHgKXdDtRAJfIBPvSM20550699;     BbnTKoHgKXdDtRAJfIBPvSM20550699 = BbnTKoHgKXdDtRAJfIBPvSM5267261;     BbnTKoHgKXdDtRAJfIBPvSM5267261 = BbnTKoHgKXdDtRAJfIBPvSM15729359;     BbnTKoHgKXdDtRAJfIBPvSM15729359 = BbnTKoHgKXdDtRAJfIBPvSM70823755;     BbnTKoHgKXdDtRAJfIBPvSM70823755 = BbnTKoHgKXdDtRAJfIBPvSM22150155;     BbnTKoHgKXdDtRAJfIBPvSM22150155 = BbnTKoHgKXdDtRAJfIBPvSM68736994;     BbnTKoHgKXdDtRAJfIBPvSM68736994 = BbnTKoHgKXdDtRAJfIBPvSM56990316;     BbnTKoHgKXdDtRAJfIBPvSM56990316 = BbnTKoHgKXdDtRAJfIBPvSM31285467;     BbnTKoHgKXdDtRAJfIBPvSM31285467 = BbnTKoHgKXdDtRAJfIBPvSM29434886;     BbnTKoHgKXdDtRAJfIBPvSM29434886 = BbnTKoHgKXdDtRAJfIBPvSM39289112;     BbnTKoHgKXdDtRAJfIBPvSM39289112 = BbnTKoHgKXdDtRAJfIBPvSM12746839;     BbnTKoHgKXdDtRAJfIBPvSM12746839 = BbnTKoHgKXdDtRAJfIBPvSM39529757;     BbnTKoHgKXdDtRAJfIBPvSM39529757 = BbnTKoHgKXdDtRAJfIBPvSM10083269;     BbnTKoHgKXdDtRAJfIBPvSM10083269 = BbnTKoHgKXdDtRAJfIBPvSM88703787;     BbnTKoHgKXdDtRAJfIBPvSM88703787 = BbnTKoHgKXdDtRAJfIBPvSM30815159;     BbnTKoHgKXdDtRAJfIBPvSM30815159 = BbnTKoHgKXdDtRAJfIBPvSM10191513;     BbnTKoHgKXdDtRAJfIBPvSM10191513 = BbnTKoHgKXdDtRAJfIBPvSM18405274;     BbnTKoHgKXdDtRAJfIBPvSM18405274 = BbnTKoHgKXdDtRAJfIBPvSM634655;     BbnTKoHgKXdDtRAJfIBPvSM634655 = BbnTKoHgKXdDtRAJfIBPvSM66722681;     BbnTKoHgKXdDtRAJfIBPvSM66722681 = BbnTKoHgKXdDtRAJfIBPvSM91925646;     BbnTKoHgKXdDtRAJfIBPvSM91925646 = BbnTKoHgKXdDtRAJfIBPvSM69154266;     BbnTKoHgKXdDtRAJfIBPvSM69154266 = BbnTKoHgKXdDtRAJfIBPvSM82038272;     BbnTKoHgKXdDtRAJfIBPvSM82038272 = BbnTKoHgKXdDtRAJfIBPvSM52137756;     BbnTKoHgKXdDtRAJfIBPvSM52137756 = BbnTKoHgKXdDtRAJfIBPvSM90725430;     BbnTKoHgKXdDtRAJfIBPvSM90725430 = BbnTKoHgKXdDtRAJfIBPvSM19114507;     BbnTKoHgKXdDtRAJfIBPvSM19114507 = BbnTKoHgKXdDtRAJfIBPvSM50639886;     BbnTKoHgKXdDtRAJfIBPvSM50639886 = BbnTKoHgKXdDtRAJfIBPvSM58343994;     BbnTKoHgKXdDtRAJfIBPvSM58343994 = BbnTKoHgKXdDtRAJfIBPvSM7300116;     BbnTKoHgKXdDtRAJfIBPvSM7300116 = BbnTKoHgKXdDtRAJfIBPvSM6377165;     BbnTKoHgKXdDtRAJfIBPvSM6377165 = BbnTKoHgKXdDtRAJfIBPvSM68212633;}



void xignieSeasRoKGJuRRttDdOJtI42424880() {     float MyyqPnMNATaIiGyPpqtfKth51936151 = -61734241;    float MyyqPnMNATaIiGyPpqtfKth87448734 = -324429485;    float MyyqPnMNATaIiGyPpqtfKth3162991 = -278883099;    float MyyqPnMNATaIiGyPpqtfKth90761532 = -595204566;    float MyyqPnMNATaIiGyPpqtfKth78222666 = -28661293;    float MyyqPnMNATaIiGyPpqtfKth67168142 = -435391684;    float MyyqPnMNATaIiGyPpqtfKth88694124 = -772838502;    float MyyqPnMNATaIiGyPpqtfKth94377036 = -260447176;    float MyyqPnMNATaIiGyPpqtfKth41414642 = -103134571;    float MyyqPnMNATaIiGyPpqtfKth12690616 = -880615200;    float MyyqPnMNATaIiGyPpqtfKth60623232 = -277362018;    float MyyqPnMNATaIiGyPpqtfKth77820189 = -261723519;    float MyyqPnMNATaIiGyPpqtfKth4272839 = 9145131;    float MyyqPnMNATaIiGyPpqtfKth54920788 = -643613970;    float MyyqPnMNATaIiGyPpqtfKth760785 = -76355634;    float MyyqPnMNATaIiGyPpqtfKth34887080 = -892912233;    float MyyqPnMNATaIiGyPpqtfKth96077349 = -625168136;    float MyyqPnMNATaIiGyPpqtfKth87984276 = -377553033;    float MyyqPnMNATaIiGyPpqtfKth63015873 = -430972984;    float MyyqPnMNATaIiGyPpqtfKth52094911 = -868406613;    float MyyqPnMNATaIiGyPpqtfKth71421778 = 63366002;    float MyyqPnMNATaIiGyPpqtfKth49302870 = -527788138;    float MyyqPnMNATaIiGyPpqtfKth41362029 = 55974196;    float MyyqPnMNATaIiGyPpqtfKth6981614 = -460137732;    float MyyqPnMNATaIiGyPpqtfKth36592705 = -32607432;    float MyyqPnMNATaIiGyPpqtfKth35152097 = -166674825;    float MyyqPnMNATaIiGyPpqtfKth61835960 = 79761262;    float MyyqPnMNATaIiGyPpqtfKth6363757 = -202016942;    float MyyqPnMNATaIiGyPpqtfKth91662867 = -149152692;    float MyyqPnMNATaIiGyPpqtfKth5523630 = -3804636;    float MyyqPnMNATaIiGyPpqtfKth40053719 = -432485068;    float MyyqPnMNATaIiGyPpqtfKth74351197 = -334874217;    float MyyqPnMNATaIiGyPpqtfKth48294469 = -18621881;    float MyyqPnMNATaIiGyPpqtfKth89639142 = -30105323;    float MyyqPnMNATaIiGyPpqtfKth54237841 = -598794686;    float MyyqPnMNATaIiGyPpqtfKth79451355 = 74561384;    float MyyqPnMNATaIiGyPpqtfKth77655811 = -669550665;    float MyyqPnMNATaIiGyPpqtfKth26043031 = -873993260;    float MyyqPnMNATaIiGyPpqtfKth29255466 = -363929823;    float MyyqPnMNATaIiGyPpqtfKth45499150 = -638834205;    float MyyqPnMNATaIiGyPpqtfKth71931031 = -559749014;    float MyyqPnMNATaIiGyPpqtfKth11271840 = -753926438;    float MyyqPnMNATaIiGyPpqtfKth12363951 = -944294372;    float MyyqPnMNATaIiGyPpqtfKth62391367 = -914388349;    float MyyqPnMNATaIiGyPpqtfKth2540703 = -54987829;    float MyyqPnMNATaIiGyPpqtfKth14822608 = -271265335;    float MyyqPnMNATaIiGyPpqtfKth76049196 = -12926355;    float MyyqPnMNATaIiGyPpqtfKth66239029 = -565769795;    float MyyqPnMNATaIiGyPpqtfKth58109014 = -975610508;    float MyyqPnMNATaIiGyPpqtfKth45534787 = -665251120;    float MyyqPnMNATaIiGyPpqtfKth21362347 = -389224559;    float MyyqPnMNATaIiGyPpqtfKth79379856 = -428312583;    float MyyqPnMNATaIiGyPpqtfKth84748798 = -727824689;    float MyyqPnMNATaIiGyPpqtfKth61697100 = -144294227;    float MyyqPnMNATaIiGyPpqtfKth71003102 = -784410663;    float MyyqPnMNATaIiGyPpqtfKth2633282 = -533946104;    float MyyqPnMNATaIiGyPpqtfKth46086706 = -280403682;    float MyyqPnMNATaIiGyPpqtfKth96181377 = -818745367;    float MyyqPnMNATaIiGyPpqtfKth54168828 = -462597134;    float MyyqPnMNATaIiGyPpqtfKth43070570 = -861986469;    float MyyqPnMNATaIiGyPpqtfKth5332183 = -415152946;    float MyyqPnMNATaIiGyPpqtfKth82330367 = -470821560;    float MyyqPnMNATaIiGyPpqtfKth2714169 = -11294485;    float MyyqPnMNATaIiGyPpqtfKth35891012 = 670064;    float MyyqPnMNATaIiGyPpqtfKth72636897 = -348130133;    float MyyqPnMNATaIiGyPpqtfKth86272035 = -942487801;    float MyyqPnMNATaIiGyPpqtfKth29525720 = -143101639;    float MyyqPnMNATaIiGyPpqtfKth14633696 = -960749547;    float MyyqPnMNATaIiGyPpqtfKth682948 = 55180715;    float MyyqPnMNATaIiGyPpqtfKth21309429 = -50917018;    float MyyqPnMNATaIiGyPpqtfKth57231268 = -123361569;    float MyyqPnMNATaIiGyPpqtfKth70034318 = -751174876;    float MyyqPnMNATaIiGyPpqtfKth58728811 = 86376790;    float MyyqPnMNATaIiGyPpqtfKth17516724 = -792138780;    float MyyqPnMNATaIiGyPpqtfKth80163879 = -208657600;    float MyyqPnMNATaIiGyPpqtfKth60149938 = -182707561;    float MyyqPnMNATaIiGyPpqtfKth36938919 = -583493766;    float MyyqPnMNATaIiGyPpqtfKth78970662 = -29637455;    float MyyqPnMNATaIiGyPpqtfKth4440911 = -305149904;    float MyyqPnMNATaIiGyPpqtfKth21770098 = -761342097;    float MyyqPnMNATaIiGyPpqtfKth59102900 = -53748470;    float MyyqPnMNATaIiGyPpqtfKth95596930 = -354468944;    float MyyqPnMNATaIiGyPpqtfKth48254743 = -226406435;    float MyyqPnMNATaIiGyPpqtfKth46128080 = -483901572;    float MyyqPnMNATaIiGyPpqtfKth84161283 = -614580077;    float MyyqPnMNATaIiGyPpqtfKth60673862 = 95827515;    float MyyqPnMNATaIiGyPpqtfKth89602398 = -607049529;    float MyyqPnMNATaIiGyPpqtfKth86597369 = -874327654;    float MyyqPnMNATaIiGyPpqtfKth18636041 = -245694660;    float MyyqPnMNATaIiGyPpqtfKth51604559 = 35151418;    float MyyqPnMNATaIiGyPpqtfKth33364650 = -645034935;    float MyyqPnMNATaIiGyPpqtfKth81474434 = -850805298;    float MyyqPnMNATaIiGyPpqtfKth71874203 = -311396127;    float MyyqPnMNATaIiGyPpqtfKth86184896 = -501943355;    float MyyqPnMNATaIiGyPpqtfKth40166968 = -123681259;    float MyyqPnMNATaIiGyPpqtfKth89600664 = 11072546;    float MyyqPnMNATaIiGyPpqtfKth8557672 = -642631953;    float MyyqPnMNATaIiGyPpqtfKth76472939 = -844964437;    float MyyqPnMNATaIiGyPpqtfKth89754469 = -466258217;    float MyyqPnMNATaIiGyPpqtfKth16268668 = -61734241;     MyyqPnMNATaIiGyPpqtfKth51936151 = MyyqPnMNATaIiGyPpqtfKth87448734;     MyyqPnMNATaIiGyPpqtfKth87448734 = MyyqPnMNATaIiGyPpqtfKth3162991;     MyyqPnMNATaIiGyPpqtfKth3162991 = MyyqPnMNATaIiGyPpqtfKth90761532;     MyyqPnMNATaIiGyPpqtfKth90761532 = MyyqPnMNATaIiGyPpqtfKth78222666;     MyyqPnMNATaIiGyPpqtfKth78222666 = MyyqPnMNATaIiGyPpqtfKth67168142;     MyyqPnMNATaIiGyPpqtfKth67168142 = MyyqPnMNATaIiGyPpqtfKth88694124;     MyyqPnMNATaIiGyPpqtfKth88694124 = MyyqPnMNATaIiGyPpqtfKth94377036;     MyyqPnMNATaIiGyPpqtfKth94377036 = MyyqPnMNATaIiGyPpqtfKth41414642;     MyyqPnMNATaIiGyPpqtfKth41414642 = MyyqPnMNATaIiGyPpqtfKth12690616;     MyyqPnMNATaIiGyPpqtfKth12690616 = MyyqPnMNATaIiGyPpqtfKth60623232;     MyyqPnMNATaIiGyPpqtfKth60623232 = MyyqPnMNATaIiGyPpqtfKth77820189;     MyyqPnMNATaIiGyPpqtfKth77820189 = MyyqPnMNATaIiGyPpqtfKth4272839;     MyyqPnMNATaIiGyPpqtfKth4272839 = MyyqPnMNATaIiGyPpqtfKth54920788;     MyyqPnMNATaIiGyPpqtfKth54920788 = MyyqPnMNATaIiGyPpqtfKth760785;     MyyqPnMNATaIiGyPpqtfKth760785 = MyyqPnMNATaIiGyPpqtfKth34887080;     MyyqPnMNATaIiGyPpqtfKth34887080 = MyyqPnMNATaIiGyPpqtfKth96077349;     MyyqPnMNATaIiGyPpqtfKth96077349 = MyyqPnMNATaIiGyPpqtfKth87984276;     MyyqPnMNATaIiGyPpqtfKth87984276 = MyyqPnMNATaIiGyPpqtfKth63015873;     MyyqPnMNATaIiGyPpqtfKth63015873 = MyyqPnMNATaIiGyPpqtfKth52094911;     MyyqPnMNATaIiGyPpqtfKth52094911 = MyyqPnMNATaIiGyPpqtfKth71421778;     MyyqPnMNATaIiGyPpqtfKth71421778 = MyyqPnMNATaIiGyPpqtfKth49302870;     MyyqPnMNATaIiGyPpqtfKth49302870 = MyyqPnMNATaIiGyPpqtfKth41362029;     MyyqPnMNATaIiGyPpqtfKth41362029 = MyyqPnMNATaIiGyPpqtfKth6981614;     MyyqPnMNATaIiGyPpqtfKth6981614 = MyyqPnMNATaIiGyPpqtfKth36592705;     MyyqPnMNATaIiGyPpqtfKth36592705 = MyyqPnMNATaIiGyPpqtfKth35152097;     MyyqPnMNATaIiGyPpqtfKth35152097 = MyyqPnMNATaIiGyPpqtfKth61835960;     MyyqPnMNATaIiGyPpqtfKth61835960 = MyyqPnMNATaIiGyPpqtfKth6363757;     MyyqPnMNATaIiGyPpqtfKth6363757 = MyyqPnMNATaIiGyPpqtfKth91662867;     MyyqPnMNATaIiGyPpqtfKth91662867 = MyyqPnMNATaIiGyPpqtfKth5523630;     MyyqPnMNATaIiGyPpqtfKth5523630 = MyyqPnMNATaIiGyPpqtfKth40053719;     MyyqPnMNATaIiGyPpqtfKth40053719 = MyyqPnMNATaIiGyPpqtfKth74351197;     MyyqPnMNATaIiGyPpqtfKth74351197 = MyyqPnMNATaIiGyPpqtfKth48294469;     MyyqPnMNATaIiGyPpqtfKth48294469 = MyyqPnMNATaIiGyPpqtfKth89639142;     MyyqPnMNATaIiGyPpqtfKth89639142 = MyyqPnMNATaIiGyPpqtfKth54237841;     MyyqPnMNATaIiGyPpqtfKth54237841 = MyyqPnMNATaIiGyPpqtfKth79451355;     MyyqPnMNATaIiGyPpqtfKth79451355 = MyyqPnMNATaIiGyPpqtfKth77655811;     MyyqPnMNATaIiGyPpqtfKth77655811 = MyyqPnMNATaIiGyPpqtfKth26043031;     MyyqPnMNATaIiGyPpqtfKth26043031 = MyyqPnMNATaIiGyPpqtfKth29255466;     MyyqPnMNATaIiGyPpqtfKth29255466 = MyyqPnMNATaIiGyPpqtfKth45499150;     MyyqPnMNATaIiGyPpqtfKth45499150 = MyyqPnMNATaIiGyPpqtfKth71931031;     MyyqPnMNATaIiGyPpqtfKth71931031 = MyyqPnMNATaIiGyPpqtfKth11271840;     MyyqPnMNATaIiGyPpqtfKth11271840 = MyyqPnMNATaIiGyPpqtfKth12363951;     MyyqPnMNATaIiGyPpqtfKth12363951 = MyyqPnMNATaIiGyPpqtfKth62391367;     MyyqPnMNATaIiGyPpqtfKth62391367 = MyyqPnMNATaIiGyPpqtfKth2540703;     MyyqPnMNATaIiGyPpqtfKth2540703 = MyyqPnMNATaIiGyPpqtfKth14822608;     MyyqPnMNATaIiGyPpqtfKth14822608 = MyyqPnMNATaIiGyPpqtfKth76049196;     MyyqPnMNATaIiGyPpqtfKth76049196 = MyyqPnMNATaIiGyPpqtfKth66239029;     MyyqPnMNATaIiGyPpqtfKth66239029 = MyyqPnMNATaIiGyPpqtfKth58109014;     MyyqPnMNATaIiGyPpqtfKth58109014 = MyyqPnMNATaIiGyPpqtfKth45534787;     MyyqPnMNATaIiGyPpqtfKth45534787 = MyyqPnMNATaIiGyPpqtfKth21362347;     MyyqPnMNATaIiGyPpqtfKth21362347 = MyyqPnMNATaIiGyPpqtfKth79379856;     MyyqPnMNATaIiGyPpqtfKth79379856 = MyyqPnMNATaIiGyPpqtfKth84748798;     MyyqPnMNATaIiGyPpqtfKth84748798 = MyyqPnMNATaIiGyPpqtfKth61697100;     MyyqPnMNATaIiGyPpqtfKth61697100 = MyyqPnMNATaIiGyPpqtfKth71003102;     MyyqPnMNATaIiGyPpqtfKth71003102 = MyyqPnMNATaIiGyPpqtfKth2633282;     MyyqPnMNATaIiGyPpqtfKth2633282 = MyyqPnMNATaIiGyPpqtfKth46086706;     MyyqPnMNATaIiGyPpqtfKth46086706 = MyyqPnMNATaIiGyPpqtfKth96181377;     MyyqPnMNATaIiGyPpqtfKth96181377 = MyyqPnMNATaIiGyPpqtfKth54168828;     MyyqPnMNATaIiGyPpqtfKth54168828 = MyyqPnMNATaIiGyPpqtfKth43070570;     MyyqPnMNATaIiGyPpqtfKth43070570 = MyyqPnMNATaIiGyPpqtfKth5332183;     MyyqPnMNATaIiGyPpqtfKth5332183 = MyyqPnMNATaIiGyPpqtfKth82330367;     MyyqPnMNATaIiGyPpqtfKth82330367 = MyyqPnMNATaIiGyPpqtfKth2714169;     MyyqPnMNATaIiGyPpqtfKth2714169 = MyyqPnMNATaIiGyPpqtfKth35891012;     MyyqPnMNATaIiGyPpqtfKth35891012 = MyyqPnMNATaIiGyPpqtfKth72636897;     MyyqPnMNATaIiGyPpqtfKth72636897 = MyyqPnMNATaIiGyPpqtfKth86272035;     MyyqPnMNATaIiGyPpqtfKth86272035 = MyyqPnMNATaIiGyPpqtfKth29525720;     MyyqPnMNATaIiGyPpqtfKth29525720 = MyyqPnMNATaIiGyPpqtfKth14633696;     MyyqPnMNATaIiGyPpqtfKth14633696 = MyyqPnMNATaIiGyPpqtfKth682948;     MyyqPnMNATaIiGyPpqtfKth682948 = MyyqPnMNATaIiGyPpqtfKth21309429;     MyyqPnMNATaIiGyPpqtfKth21309429 = MyyqPnMNATaIiGyPpqtfKth57231268;     MyyqPnMNATaIiGyPpqtfKth57231268 = MyyqPnMNATaIiGyPpqtfKth70034318;     MyyqPnMNATaIiGyPpqtfKth70034318 = MyyqPnMNATaIiGyPpqtfKth58728811;     MyyqPnMNATaIiGyPpqtfKth58728811 = MyyqPnMNATaIiGyPpqtfKth17516724;     MyyqPnMNATaIiGyPpqtfKth17516724 = MyyqPnMNATaIiGyPpqtfKth80163879;     MyyqPnMNATaIiGyPpqtfKth80163879 = MyyqPnMNATaIiGyPpqtfKth60149938;     MyyqPnMNATaIiGyPpqtfKth60149938 = MyyqPnMNATaIiGyPpqtfKth36938919;     MyyqPnMNATaIiGyPpqtfKth36938919 = MyyqPnMNATaIiGyPpqtfKth78970662;     MyyqPnMNATaIiGyPpqtfKth78970662 = MyyqPnMNATaIiGyPpqtfKth4440911;     MyyqPnMNATaIiGyPpqtfKth4440911 = MyyqPnMNATaIiGyPpqtfKth21770098;     MyyqPnMNATaIiGyPpqtfKth21770098 = MyyqPnMNATaIiGyPpqtfKth59102900;     MyyqPnMNATaIiGyPpqtfKth59102900 = MyyqPnMNATaIiGyPpqtfKth95596930;     MyyqPnMNATaIiGyPpqtfKth95596930 = MyyqPnMNATaIiGyPpqtfKth48254743;     MyyqPnMNATaIiGyPpqtfKth48254743 = MyyqPnMNATaIiGyPpqtfKth46128080;     MyyqPnMNATaIiGyPpqtfKth46128080 = MyyqPnMNATaIiGyPpqtfKth84161283;     MyyqPnMNATaIiGyPpqtfKth84161283 = MyyqPnMNATaIiGyPpqtfKth60673862;     MyyqPnMNATaIiGyPpqtfKth60673862 = MyyqPnMNATaIiGyPpqtfKth89602398;     MyyqPnMNATaIiGyPpqtfKth89602398 = MyyqPnMNATaIiGyPpqtfKth86597369;     MyyqPnMNATaIiGyPpqtfKth86597369 = MyyqPnMNATaIiGyPpqtfKth18636041;     MyyqPnMNATaIiGyPpqtfKth18636041 = MyyqPnMNATaIiGyPpqtfKth51604559;     MyyqPnMNATaIiGyPpqtfKth51604559 = MyyqPnMNATaIiGyPpqtfKth33364650;     MyyqPnMNATaIiGyPpqtfKth33364650 = MyyqPnMNATaIiGyPpqtfKth81474434;     MyyqPnMNATaIiGyPpqtfKth81474434 = MyyqPnMNATaIiGyPpqtfKth71874203;     MyyqPnMNATaIiGyPpqtfKth71874203 = MyyqPnMNATaIiGyPpqtfKth86184896;     MyyqPnMNATaIiGyPpqtfKth86184896 = MyyqPnMNATaIiGyPpqtfKth40166968;     MyyqPnMNATaIiGyPpqtfKth40166968 = MyyqPnMNATaIiGyPpqtfKth89600664;     MyyqPnMNATaIiGyPpqtfKth89600664 = MyyqPnMNATaIiGyPpqtfKth8557672;     MyyqPnMNATaIiGyPpqtfKth8557672 = MyyqPnMNATaIiGyPpqtfKth76472939;     MyyqPnMNATaIiGyPpqtfKth76472939 = MyyqPnMNATaIiGyPpqtfKth89754469;     MyyqPnMNATaIiGyPpqtfKth89754469 = MyyqPnMNATaIiGyPpqtfKth16268668;     MyyqPnMNATaIiGyPpqtfKth16268668 = MyyqPnMNATaIiGyPpqtfKth51936151;}



void mtAClKecFhyonGQGWhYfWnvKEy27487718() {     float pkjovVDQrkAaGDlcxenifvG35659669 = -411756308;    float pkjovVDQrkAaGDlcxenifvG85046830 = -128081336;    float pkjovVDQrkAaGDlcxenifvG91749107 = -147190790;    float pkjovVDQrkAaGDlcxenifvG87909485 = -600086494;    float pkjovVDQrkAaGDlcxenifvG57784003 = -426609485;    float pkjovVDQrkAaGDlcxenifvG78507660 = -538712353;    float pkjovVDQrkAaGDlcxenifvG25574687 = -794352640;    float pkjovVDQrkAaGDlcxenifvG37717119 = -880901762;    float pkjovVDQrkAaGDlcxenifvG91634169 = -800617267;    float pkjovVDQrkAaGDlcxenifvG58796204 = -3656215;    float pkjovVDQrkAaGDlcxenifvG3512269 = -117647276;    float pkjovVDQrkAaGDlcxenifvG68031959 = -190862790;    float pkjovVDQrkAaGDlcxenifvG55326690 = -933687112;    float pkjovVDQrkAaGDlcxenifvG49293933 = -993296833;    float pkjovVDQrkAaGDlcxenifvG4940043 = -2052939;    float pkjovVDQrkAaGDlcxenifvG6701109 = -817039884;    float pkjovVDQrkAaGDlcxenifvG95942759 = -784047999;    float pkjovVDQrkAaGDlcxenifvG2061547 = 11595394;    float pkjovVDQrkAaGDlcxenifvG3992355 = -219622222;    float pkjovVDQrkAaGDlcxenifvG26202555 = -484699530;    float pkjovVDQrkAaGDlcxenifvG38761288 = -611100519;    float pkjovVDQrkAaGDlcxenifvG50304941 = -440943424;    float pkjovVDQrkAaGDlcxenifvG10537894 = 26579460;    float pkjovVDQrkAaGDlcxenifvG8124309 = 629615;    float pkjovVDQrkAaGDlcxenifvG73194798 = -110938193;    float pkjovVDQrkAaGDlcxenifvG88144854 = -609641853;    float pkjovVDQrkAaGDlcxenifvG83427899 = -364114161;    float pkjovVDQrkAaGDlcxenifvG48962957 = 11541570;    float pkjovVDQrkAaGDlcxenifvG63581009 = -673348592;    float pkjovVDQrkAaGDlcxenifvG41071957 = -676411010;    float pkjovVDQrkAaGDlcxenifvG21418142 = -651583088;    float pkjovVDQrkAaGDlcxenifvG99144485 = -884071440;    float pkjovVDQrkAaGDlcxenifvG62419170 = -683835972;    float pkjovVDQrkAaGDlcxenifvG25363857 = -434201970;    float pkjovVDQrkAaGDlcxenifvG21841166 = -333085293;    float pkjovVDQrkAaGDlcxenifvG49312589 = 96164906;    float pkjovVDQrkAaGDlcxenifvG77419401 = -989891961;    float pkjovVDQrkAaGDlcxenifvG76424822 = -773136477;    float pkjovVDQrkAaGDlcxenifvG89871185 = -669488704;    float pkjovVDQrkAaGDlcxenifvG84688266 = -585481084;    float pkjovVDQrkAaGDlcxenifvG36698552 = -209789140;    float pkjovVDQrkAaGDlcxenifvG40611567 = -359952107;    float pkjovVDQrkAaGDlcxenifvG45164097 = -596698626;    float pkjovVDQrkAaGDlcxenifvG9586887 = -493332082;    float pkjovVDQrkAaGDlcxenifvG30527954 = -381001907;    float pkjovVDQrkAaGDlcxenifvG59089489 = -986297027;    float pkjovVDQrkAaGDlcxenifvG9228167 = -34572262;    float pkjovVDQrkAaGDlcxenifvG4980877 = -327891692;    float pkjovVDQrkAaGDlcxenifvG91983227 = -675394659;    float pkjovVDQrkAaGDlcxenifvG81408117 = -197266556;    float pkjovVDQrkAaGDlcxenifvG61453178 = -554996960;    float pkjovVDQrkAaGDlcxenifvG30885576 = -180365369;    float pkjovVDQrkAaGDlcxenifvG30131201 = -739757055;    float pkjovVDQrkAaGDlcxenifvG7629706 = -721003415;    float pkjovVDQrkAaGDlcxenifvG88726429 = -1137608;    float pkjovVDQrkAaGDlcxenifvG85354728 = -970812885;    float pkjovVDQrkAaGDlcxenifvG74508936 = -54660797;    float pkjovVDQrkAaGDlcxenifvG83624799 = -47820405;    float pkjovVDQrkAaGDlcxenifvG14714688 = -389148302;    float pkjovVDQrkAaGDlcxenifvG69639148 = -816967633;    float pkjovVDQrkAaGDlcxenifvG95079760 = -74598192;    float pkjovVDQrkAaGDlcxenifvG76611730 = -705894210;    float pkjovVDQrkAaGDlcxenifvG74136109 = -107553171;    float pkjovVDQrkAaGDlcxenifvG50562213 = -24206258;    float pkjovVDQrkAaGDlcxenifvG37378063 = -352073128;    float pkjovVDQrkAaGDlcxenifvG4367783 = -233575836;    float pkjovVDQrkAaGDlcxenifvG5612790 = -507026818;    float pkjovVDQrkAaGDlcxenifvG29962833 = -399485143;    float pkjovVDQrkAaGDlcxenifvG27452767 = -560211540;    float pkjovVDQrkAaGDlcxenifvG55627454 = 1782154;    float pkjovVDQrkAaGDlcxenifvG29281707 = -827147924;    float pkjovVDQrkAaGDlcxenifvG19517938 = 89088478;    float pkjovVDQrkAaGDlcxenifvG12190362 = -318915903;    float pkjovVDQrkAaGDlcxenifvG19304088 = -634141139;    float pkjovVDQrkAaGDlcxenifvG89504003 = -174910390;    float pkjovVDQrkAaGDlcxenifvG98149721 = -151148412;    float pkjovVDQrkAaGDlcxenifvG5140845 = -844244798;    float pkjovVDQrkAaGDlcxenifvG951008 = -480088459;    float pkjovVDQrkAaGDlcxenifvG77596355 = -618368478;    float pkjovVDQrkAaGDlcxenifvG14105309 = -124641167;    float pkjovVDQrkAaGDlcxenifvG78916688 = -475069591;    float pkjovVDQrkAaGDlcxenifvG78447022 = 63777530;    float pkjovVDQrkAaGDlcxenifvG56979730 = -313063772;    float pkjovVDQrkAaGDlcxenifvG82172892 = -376082037;    float pkjovVDQrkAaGDlcxenifvG79618778 = -21414050;    float pkjovVDQrkAaGDlcxenifvG90532565 = -371217719;    float pkjovVDQrkAaGDlcxenifvG69013285 = -44314386;    float pkjovVDQrkAaGDlcxenifvG54789464 = -962832558;    float pkjovVDQrkAaGDlcxenifvG36637428 = -333064363;    float pkjovVDQrkAaGDlcxenifvG36486438 = -362272409;    float pkjovVDQrkAaGDlcxenifvG74803653 = -849174298;    float pkjovVDQrkAaGDlcxenifvG93794602 = -842071557;    float pkjovVDQrkAaGDlcxenifvG61710134 = -283988176;    float pkjovVDQrkAaGDlcxenifvG20232037 = -852521072;    float pkjovVDQrkAaGDlcxenifvG89608505 = -410882893;    float pkjovVDQrkAaGDlcxenifvG60086822 = -503894931;    float pkjovVDQrkAaGDlcxenifvG66475457 = -152398937;    float pkjovVDQrkAaGDlcxenifvG94601884 = -472492369;    float pkjovVDQrkAaGDlcxenifvG72208823 = -41258955;    float pkjovVDQrkAaGDlcxenifvG26160171 = -411756308;     pkjovVDQrkAaGDlcxenifvG35659669 = pkjovVDQrkAaGDlcxenifvG85046830;     pkjovVDQrkAaGDlcxenifvG85046830 = pkjovVDQrkAaGDlcxenifvG91749107;     pkjovVDQrkAaGDlcxenifvG91749107 = pkjovVDQrkAaGDlcxenifvG87909485;     pkjovVDQrkAaGDlcxenifvG87909485 = pkjovVDQrkAaGDlcxenifvG57784003;     pkjovVDQrkAaGDlcxenifvG57784003 = pkjovVDQrkAaGDlcxenifvG78507660;     pkjovVDQrkAaGDlcxenifvG78507660 = pkjovVDQrkAaGDlcxenifvG25574687;     pkjovVDQrkAaGDlcxenifvG25574687 = pkjovVDQrkAaGDlcxenifvG37717119;     pkjovVDQrkAaGDlcxenifvG37717119 = pkjovVDQrkAaGDlcxenifvG91634169;     pkjovVDQrkAaGDlcxenifvG91634169 = pkjovVDQrkAaGDlcxenifvG58796204;     pkjovVDQrkAaGDlcxenifvG58796204 = pkjovVDQrkAaGDlcxenifvG3512269;     pkjovVDQrkAaGDlcxenifvG3512269 = pkjovVDQrkAaGDlcxenifvG68031959;     pkjovVDQrkAaGDlcxenifvG68031959 = pkjovVDQrkAaGDlcxenifvG55326690;     pkjovVDQrkAaGDlcxenifvG55326690 = pkjovVDQrkAaGDlcxenifvG49293933;     pkjovVDQrkAaGDlcxenifvG49293933 = pkjovVDQrkAaGDlcxenifvG4940043;     pkjovVDQrkAaGDlcxenifvG4940043 = pkjovVDQrkAaGDlcxenifvG6701109;     pkjovVDQrkAaGDlcxenifvG6701109 = pkjovVDQrkAaGDlcxenifvG95942759;     pkjovVDQrkAaGDlcxenifvG95942759 = pkjovVDQrkAaGDlcxenifvG2061547;     pkjovVDQrkAaGDlcxenifvG2061547 = pkjovVDQrkAaGDlcxenifvG3992355;     pkjovVDQrkAaGDlcxenifvG3992355 = pkjovVDQrkAaGDlcxenifvG26202555;     pkjovVDQrkAaGDlcxenifvG26202555 = pkjovVDQrkAaGDlcxenifvG38761288;     pkjovVDQrkAaGDlcxenifvG38761288 = pkjovVDQrkAaGDlcxenifvG50304941;     pkjovVDQrkAaGDlcxenifvG50304941 = pkjovVDQrkAaGDlcxenifvG10537894;     pkjovVDQrkAaGDlcxenifvG10537894 = pkjovVDQrkAaGDlcxenifvG8124309;     pkjovVDQrkAaGDlcxenifvG8124309 = pkjovVDQrkAaGDlcxenifvG73194798;     pkjovVDQrkAaGDlcxenifvG73194798 = pkjovVDQrkAaGDlcxenifvG88144854;     pkjovVDQrkAaGDlcxenifvG88144854 = pkjovVDQrkAaGDlcxenifvG83427899;     pkjovVDQrkAaGDlcxenifvG83427899 = pkjovVDQrkAaGDlcxenifvG48962957;     pkjovVDQrkAaGDlcxenifvG48962957 = pkjovVDQrkAaGDlcxenifvG63581009;     pkjovVDQrkAaGDlcxenifvG63581009 = pkjovVDQrkAaGDlcxenifvG41071957;     pkjovVDQrkAaGDlcxenifvG41071957 = pkjovVDQrkAaGDlcxenifvG21418142;     pkjovVDQrkAaGDlcxenifvG21418142 = pkjovVDQrkAaGDlcxenifvG99144485;     pkjovVDQrkAaGDlcxenifvG99144485 = pkjovVDQrkAaGDlcxenifvG62419170;     pkjovVDQrkAaGDlcxenifvG62419170 = pkjovVDQrkAaGDlcxenifvG25363857;     pkjovVDQrkAaGDlcxenifvG25363857 = pkjovVDQrkAaGDlcxenifvG21841166;     pkjovVDQrkAaGDlcxenifvG21841166 = pkjovVDQrkAaGDlcxenifvG49312589;     pkjovVDQrkAaGDlcxenifvG49312589 = pkjovVDQrkAaGDlcxenifvG77419401;     pkjovVDQrkAaGDlcxenifvG77419401 = pkjovVDQrkAaGDlcxenifvG76424822;     pkjovVDQrkAaGDlcxenifvG76424822 = pkjovVDQrkAaGDlcxenifvG89871185;     pkjovVDQrkAaGDlcxenifvG89871185 = pkjovVDQrkAaGDlcxenifvG84688266;     pkjovVDQrkAaGDlcxenifvG84688266 = pkjovVDQrkAaGDlcxenifvG36698552;     pkjovVDQrkAaGDlcxenifvG36698552 = pkjovVDQrkAaGDlcxenifvG40611567;     pkjovVDQrkAaGDlcxenifvG40611567 = pkjovVDQrkAaGDlcxenifvG45164097;     pkjovVDQrkAaGDlcxenifvG45164097 = pkjovVDQrkAaGDlcxenifvG9586887;     pkjovVDQrkAaGDlcxenifvG9586887 = pkjovVDQrkAaGDlcxenifvG30527954;     pkjovVDQrkAaGDlcxenifvG30527954 = pkjovVDQrkAaGDlcxenifvG59089489;     pkjovVDQrkAaGDlcxenifvG59089489 = pkjovVDQrkAaGDlcxenifvG9228167;     pkjovVDQrkAaGDlcxenifvG9228167 = pkjovVDQrkAaGDlcxenifvG4980877;     pkjovVDQrkAaGDlcxenifvG4980877 = pkjovVDQrkAaGDlcxenifvG91983227;     pkjovVDQrkAaGDlcxenifvG91983227 = pkjovVDQrkAaGDlcxenifvG81408117;     pkjovVDQrkAaGDlcxenifvG81408117 = pkjovVDQrkAaGDlcxenifvG61453178;     pkjovVDQrkAaGDlcxenifvG61453178 = pkjovVDQrkAaGDlcxenifvG30885576;     pkjovVDQrkAaGDlcxenifvG30885576 = pkjovVDQrkAaGDlcxenifvG30131201;     pkjovVDQrkAaGDlcxenifvG30131201 = pkjovVDQrkAaGDlcxenifvG7629706;     pkjovVDQrkAaGDlcxenifvG7629706 = pkjovVDQrkAaGDlcxenifvG88726429;     pkjovVDQrkAaGDlcxenifvG88726429 = pkjovVDQrkAaGDlcxenifvG85354728;     pkjovVDQrkAaGDlcxenifvG85354728 = pkjovVDQrkAaGDlcxenifvG74508936;     pkjovVDQrkAaGDlcxenifvG74508936 = pkjovVDQrkAaGDlcxenifvG83624799;     pkjovVDQrkAaGDlcxenifvG83624799 = pkjovVDQrkAaGDlcxenifvG14714688;     pkjovVDQrkAaGDlcxenifvG14714688 = pkjovVDQrkAaGDlcxenifvG69639148;     pkjovVDQrkAaGDlcxenifvG69639148 = pkjovVDQrkAaGDlcxenifvG95079760;     pkjovVDQrkAaGDlcxenifvG95079760 = pkjovVDQrkAaGDlcxenifvG76611730;     pkjovVDQrkAaGDlcxenifvG76611730 = pkjovVDQrkAaGDlcxenifvG74136109;     pkjovVDQrkAaGDlcxenifvG74136109 = pkjovVDQrkAaGDlcxenifvG50562213;     pkjovVDQrkAaGDlcxenifvG50562213 = pkjovVDQrkAaGDlcxenifvG37378063;     pkjovVDQrkAaGDlcxenifvG37378063 = pkjovVDQrkAaGDlcxenifvG4367783;     pkjovVDQrkAaGDlcxenifvG4367783 = pkjovVDQrkAaGDlcxenifvG5612790;     pkjovVDQrkAaGDlcxenifvG5612790 = pkjovVDQrkAaGDlcxenifvG29962833;     pkjovVDQrkAaGDlcxenifvG29962833 = pkjovVDQrkAaGDlcxenifvG27452767;     pkjovVDQrkAaGDlcxenifvG27452767 = pkjovVDQrkAaGDlcxenifvG55627454;     pkjovVDQrkAaGDlcxenifvG55627454 = pkjovVDQrkAaGDlcxenifvG29281707;     pkjovVDQrkAaGDlcxenifvG29281707 = pkjovVDQrkAaGDlcxenifvG19517938;     pkjovVDQrkAaGDlcxenifvG19517938 = pkjovVDQrkAaGDlcxenifvG12190362;     pkjovVDQrkAaGDlcxenifvG12190362 = pkjovVDQrkAaGDlcxenifvG19304088;     pkjovVDQrkAaGDlcxenifvG19304088 = pkjovVDQrkAaGDlcxenifvG89504003;     pkjovVDQrkAaGDlcxenifvG89504003 = pkjovVDQrkAaGDlcxenifvG98149721;     pkjovVDQrkAaGDlcxenifvG98149721 = pkjovVDQrkAaGDlcxenifvG5140845;     pkjovVDQrkAaGDlcxenifvG5140845 = pkjovVDQrkAaGDlcxenifvG951008;     pkjovVDQrkAaGDlcxenifvG951008 = pkjovVDQrkAaGDlcxenifvG77596355;     pkjovVDQrkAaGDlcxenifvG77596355 = pkjovVDQrkAaGDlcxenifvG14105309;     pkjovVDQrkAaGDlcxenifvG14105309 = pkjovVDQrkAaGDlcxenifvG78916688;     pkjovVDQrkAaGDlcxenifvG78916688 = pkjovVDQrkAaGDlcxenifvG78447022;     pkjovVDQrkAaGDlcxenifvG78447022 = pkjovVDQrkAaGDlcxenifvG56979730;     pkjovVDQrkAaGDlcxenifvG56979730 = pkjovVDQrkAaGDlcxenifvG82172892;     pkjovVDQrkAaGDlcxenifvG82172892 = pkjovVDQrkAaGDlcxenifvG79618778;     pkjovVDQrkAaGDlcxenifvG79618778 = pkjovVDQrkAaGDlcxenifvG90532565;     pkjovVDQrkAaGDlcxenifvG90532565 = pkjovVDQrkAaGDlcxenifvG69013285;     pkjovVDQrkAaGDlcxenifvG69013285 = pkjovVDQrkAaGDlcxenifvG54789464;     pkjovVDQrkAaGDlcxenifvG54789464 = pkjovVDQrkAaGDlcxenifvG36637428;     pkjovVDQrkAaGDlcxenifvG36637428 = pkjovVDQrkAaGDlcxenifvG36486438;     pkjovVDQrkAaGDlcxenifvG36486438 = pkjovVDQrkAaGDlcxenifvG74803653;     pkjovVDQrkAaGDlcxenifvG74803653 = pkjovVDQrkAaGDlcxenifvG93794602;     pkjovVDQrkAaGDlcxenifvG93794602 = pkjovVDQrkAaGDlcxenifvG61710134;     pkjovVDQrkAaGDlcxenifvG61710134 = pkjovVDQrkAaGDlcxenifvG20232037;     pkjovVDQrkAaGDlcxenifvG20232037 = pkjovVDQrkAaGDlcxenifvG89608505;     pkjovVDQrkAaGDlcxenifvG89608505 = pkjovVDQrkAaGDlcxenifvG60086822;     pkjovVDQrkAaGDlcxenifvG60086822 = pkjovVDQrkAaGDlcxenifvG66475457;     pkjovVDQrkAaGDlcxenifvG66475457 = pkjovVDQrkAaGDlcxenifvG94601884;     pkjovVDQrkAaGDlcxenifvG94601884 = pkjovVDQrkAaGDlcxenifvG72208823;     pkjovVDQrkAaGDlcxenifvG72208823 = pkjovVDQrkAaGDlcxenifvG26160171;     pkjovVDQrkAaGDlcxenifvG26160171 = pkjovVDQrkAaGDlcxenifvG35659669;}





























































































































































































































































































































































































































































































































































































































































































































